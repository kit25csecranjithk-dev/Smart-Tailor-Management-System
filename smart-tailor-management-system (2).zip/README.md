# Smart Tailor - Tailor Shop Management System

> **College Project**: Concept of Practices (COP) Real-World Application  
> **Department**: Computer Science & Engineering  
> **Tech Stack**: React 19, TypeScript, Vite, Tailwind CSS, Lucide Icons, LocalStorage Persistence  
> **Platform**: 100% Standalone Web Application — No external backend or API keys required  

---

## 📌 Project Overview

Traditional tailor shops and bespoke tailoring boutiques manage customer measurements, cloth cutting tickets, delivery schedules, and advance payments manually in paper notebooks. This legacy approach leads to:
- **Lost records and stained paper logs**
- **Measurement & alteration discrepancies**
- **Missed delivery deadlines and festival delivery bottlenecks**
- **Calculation errors in advance amounts, fabric charges, and balance collections**
- **Stockouts of critical materials like matching threads, collar canvasing, and zippers**

**Smart Tailor** is a standalone, client-side web application designed to digitize and automate the day-to-day operations of modern tailor shops, designer boutiques, and master cutting masters.

---

## ✨ Features Implemented

### 1. Studio Authentication & Access Control
- Login authentication with username & password validation
- Show / Hide password toggle
- One-click instant **Demo Login** buttons for **Master Tailor** and **Senior Staff**
- Secure session state persisted in `LocalStorage` with logout capability

### 2. Comprehensive Business Dashboard
- **Real-Time Key Performance Indicators (KPIs)**: Total Clients, In-Production Orders, Ready for Pickup, and Outstanding Balances (₹)
- **Garment Production Lifecycle Pipeline**: Visual count across all 6 workstations
- **Urgent Overdue Order Alerts**: High-visibility warning banner for orders past delivery date
- **Today's Customer Delivery & Trial Queue**: Quick look at orders due today
- **Low-Stock Material Alerts**: Real-time warnings for depleted threads and trims

### 3. Customer Management
- Add, Edit, Delete, and Search clients by name, 10-digit mobile number, or address
- Filter by gender (Ladies / Gents / All)
- **Customer Profile Drawer**: Shows total lifetime orders, total billed (₹), balance pending, saved measurement cards, and past order history
- Quick shortcuts: "+ Order" and "+ Measurement" directly from customer cards

### 4. Specialized Anatomical Measurement Management
- Specialized measurement templates for Indian and global garments:
  - **Saree Blouse**: Length, Bust, Upper Bust, Waist, Shoulder, Armhole, Sleeve Length, Sleeve Round, Front Neck, Back Neck, Cross Front, Cross Back, Apex Point, Cup Padding (Padded / Non-Padded)
  - **Shirt**: Length, Chest, Waist, Hip, Shoulder, Sleeve, Collar, Cuff, Bicep, Fit Style (Slim / Regular)
  - **Trousers / Pants**: Waist, Hip, Outseam Length, Inseam Length, Thigh, Knee, Bottom Hem, Front Rise, Back Rise
  - **Churidar / Salwar Kameez**: Kameez Length, Bust, Waist, Hip, Side Slit Point, Shoulder, Armhole, Sleeve, Bottom Length, Ankle Mori, Crotch Rise
  - **Men Kurta / Sherwani**: Length, Chest, Waist, Shoulder, Sleeve, Mandarin Collar, Side Slits
  - **Two-Piece Blazer / Suit**: Jacket Length, Chest, Waist, Shoulder, Sleeve, Trouser Waist, Trouser Outseam
  - **Custom Garments**: Custom tailoring specifications and notes
- Toggle between **Inches (in)** and **Centimeters (cm)**
- Copy measurement specifications to clipboard for tailor sharing
- Instant "Create Stitching Order with this Measurement" button

### 5. Stitching Work Orders
- Unique order IDs (e.g., `ORD-2026-001`)
- Garment description and silhouette categorization
- Fabric specifications: Material type, color, pattern, customer-provided vs shop-supplied, length in meters
- Schedule: Booking date, trial / basting date, target delivery date
- Priority tagging: **Standard**, **Urgent**, and **Express**
- Assigned master tailor selection

### 6. Interactive Kanban Order Pipeline Board
- 6-stage lifecycle tracking:
  1. `Order Received`
  2. `Cutting Station`
  3. `Stitching Floor`
  4. `Trial / Alteration`
  5. `Ready for Pickup`
  6. `Delivered`
- Advance or move back orders with single-click buttons
- Color-coded urgency highlights (Overdue, Due Today, On Schedule)

### 7. Billing, Advance Calculation & Printable Invoices
- Automatic fee calculator:
  $$\text{Subtotal} = \text{Stitching} + \text{Add-ons} + \text{Fabric Cost}$$
  $$\text{Total Bill} = \text{Subtotal} - \text{Discount}$$
  $$\text{Balance Due} = \text{Total Bill} - \text{Advance Paid}$$
- Support for multiple payment methods: **UPI (GPay / PhonePe)**, **Cash**, **Card**, **Bank Transfer**
- Payment receipt ledger with receipt numbers (`RCP-1001`)
- **Printable Job Invoice & Cash Memo**:
  - Formatted for standard printing (`Ctrl + P` or "Print" button)
  - Includes boutique logo, GSTIN, customer details, measurement specs, itemized charges, status stamp, terms, and signature blocks

### 8. Material & Trims Inventory Management
- Categorized stock tracking: Fabrics, Sewing Threads, Buttons & Hooks, Zippers, Linings, and Accessories
- Reorder threshold levels with visual **Low Stock Warning Badges**
- Total inventory stock valuation (₹)
- **Fast Stock Adjustment Modal**: Restock (+) or Consume (-) with audit note

### 9. Delivery & Fitting Schedule
- Chronological queue organized by: Overdue, Due Today, Next 7 Days, and All Pending
- Quick "Mark Delivered" action button with automatic date timestamp

### 10. Reports & Financial P&L Statement
- Total Billed vs Cash Collected vs Operating Expenses vs Net Realized Profit
- Income distribution breakdown: Stitching Labor vs Add-ons vs Fabric Sales
- Garment popularity distribution
- Shop operational expense tracking (Rent, Tailor wages, Electricity, Threads, Machine service)
- **Export Complete Report to CSV**: One-click download of all orders, finances, and expenses

### 11. Shop Profile & LocalStorage Database Portability
- Configurable shop name, master tailor name, phone numbers, email, GSTIN, and currency (`₹`)
- **JSON Database Backup**: Download the entire shop database as a `.json` file
- **JSON Restore**: Upload and restore previous data snapshots
- **Reset to Demo Data**: Instantly resets realistic sample data for college demonstration and viva

---

## 💻 How to Download and Run Locally in VS Code (Windows / Mac / Linux)

### Prerequisites
Make sure you have **Node.js** (v18 or higher recommended) installed on your computer.
- Download Node.js from: [https://nodejs.org/](https://nodejs.org/)
- To verify your installation, open Command Prompt or Terminal and type:
  ```bash
  node -v
  npm -v
  ```

---

### Step-by-Step Instructions

#### Step 1: Download the Project
1. In Google AI Studio, click on the **Download ZIP** or **Export to GitHub** button.
2. If downloaded as a ZIP file, extract `smart-tailor.zip` to a folder on your computer (e.g., `C:\Projects\smart-tailor` or `Desktop\smart-tailor`).

#### Step 2: Open in Visual Studio Code
1. Open **Visual Studio Code**.
2. Go to **File** > **Open Folder...** (or press `Ctrl + K, Ctrl + O` on Windows).
3. Select the extracted `smart-tailor` folder.

#### Step 3: Open the Integrated Terminal
1. In VS Code, open the terminal by pressing `` Ctrl + ` `` (Backtick) or go to **Terminal** > **New Terminal** in the top menu.

#### Step 4: Install Dependencies
Run the following command in the terminal:
```bash
npm install
```
*This installs React, Vite, Tailwind CSS, Lucide icons, and all required packages into `node_modules`.*

#### Step 5: Start the Development Server
Run:
```bash
npm run dev
```

#### Step 6: Open the Website in Your Browser
The terminal will display output similar to:
```
  VITE v8.3.0  ready in 250 ms

  ➜  Local:   http://localhost:3000/
  ➜  Network: use --host to expose
```
- Open your browser (Google Chrome, Microsoft Edge, Firefox, Brave) and navigate to:
  **`http://localhost:3000`**

---

## 🔑 Login Credentials for Testing

You can use the **"Master Tailor"** or **"Senior Staff"** quick demo buttons on the login screen, or enter the credentials manually:

| Role | Username | Password | Access Level |
| :--- | :--- | :--- | :--- |
| **Master Tailor** (Proprietor) | `admin` | `master123` | Full Studio Management, Settings & Reports |
| **Senior Staff** (Cutter) | `staff` | `staff123` | Orders, Measurements & Pipeline Operations |

---

## 📁 Project Directory Structure

```
smart-tailor/
├── index.html                   # HTML entry point with custom Google Fonts & print tags
├── package.json                 # Standard npm configuration & scripts
├── tsconfig.json                # TypeScript compiler configuration
├── vite.config.ts               # Vite build configuration with Tailwind CSS plugin
├── README.md                    # Complete project documentation
├── metadata.json                # Application metadata
└── src/
    ├── main.tsx                 # React application entry point
    ├── App.tsx                  # Root component wiring navigation, state, and modals
    ├── index.css                # Global styling, Tailwind imports, tabular fonts & print styles
    ├── types/
    │   └── index.ts             # TypeScript definitions for Customers, Orders, Measurements, etc.
    ├── services/
    │   └── storage.ts           # LocalStorage persistence service with initial seed data & CRUD
    ├── utils/
    │   ├── formatters.ts        # Currency (₹ INR), date helpers, and status badge color mapping
    │   └── measurementTemplates.ts # Anatomical measurement definitions for Blouse, Shirt, Pants, etc.
    ├── components/
    │   ├── layout/
    │   │   ├── Sidebar.tsx      # Responsive desktop/mobile navigation drawer
    │   │   └── Header.tsx       # Top bar with status indicators, date badge, and quick CTAs
    │   ├── common/
    │   │   ├── Modal.tsx        # Accessible reusable modal dialog
    │   │   ├── ConfirmModal.tsx # Safe deletion & reset confirmation dialog
    │   │   └── NotificationToast.tsx # Floating notification feedback toasts
    │   ├── customers/
    │   │   ├── CustomerModal.tsx       # Add/Edit customer profile
    │   │   └── CustomerDetailDrawer.tsx # Full customer history and measurement cards
    │   ├── measurements/
    │   │   └── MeasurementModal.tsx    # Anatomical measurements recorder
    │   ├── orders/
    │   │   └── OrderModal.tsx          # Stitching work ticket & pricing calculator
    │   ├── billing/
    │   │   ├── InvoiceModal.tsx        # Printable Tax Invoice / Cash Memo
    │   │   └── PaymentModal.tsx        # Payment receipt recorder (Cash, UPI, Card)
    │   ├── inventory/
    │   │   ├── InventoryModal.tsx      # Material item creation & threshold alerts
    │   │   └── StockAdjustModal.tsx    # Restock / Deduct stock adjustment
    │   └── expenses/
    │       └── ExpenseModal.tsx        # Workshop expense recorder
    └── pages/
        ├── LoginPage.tsx        # Authentication screen with demo logins
        ├── DashboardPage.tsx    # Studio overview, live KPIs, today queue, and alert banners
        ├── CustomersPage.tsx    # Customer directory with search & filters
        ├── MeasurementsPage.tsx # Garment measurement cards with copy & order links
        ├── OrdersPage.tsx       # Full stitching orders ledger with stage selectors
        ├── TrackingPage.tsx     # Interactive 6-stage Kanban board
        ├── BillingPage.tsx      # Invoices, balances due, and payments ledger
        ├── InventoryPage.tsx    # Materials catalog with low-stock warnings
        ├── DeliverySchedulePage.tsx # Chronological delivery & trial queue
        ├── ReportsPage.tsx      # P&L statement, income streams, and CSV export
        └── SettingsPage.tsx     # Studio identity, GST, backup & restore
```

---

## 🛠️ Build and Production Deployment

To build the project for production (generates optimized HTML, CSS, and JS in `dist/`):
```bash
npm run build
```

To preview the built production site locally:
```bash
npm run preview
```

---

## 🎓 College Viva & Evaluation FAQ

**Q1: How does data persist without a SQL server or MongoDB backend?**  
*Answer:* The application implements an isolated LocalStorage service (`src/services/storage.ts`) that manages serialized JSON state for customers, measurements, orders, inventory, and expenses. Refreshing the browser or closing the window retains all changes. Additionally, users can export and import complete database snapshots via JSON files.

**Q2: How does the application handle multiple garment measurement types?**  
*Answer:* The system uses a declarative template registry (`src/utils/measurementTemplates.ts`). Each garment silhouette (Blouse, Shirt, Pants, Churidar, Kurta, Suit) has custom anatomical fields with tailor tape placement hints. Units can be toggled between inches and centimeters dynamically.

**Q3: How are invoices printed?**  
*Answer:* The invoice modal utilizes CSS `@media print` rules defined in `src/index.css`. When the user clicks "Print Invoice", the browser's native print engine formats an A4 cash memo, hiding sidebars and buttons while preserving branding, itemized charges, and signature lines.

---

**Developed for Concept of Practices (COP) Real-World Project Evaluation.**  
*Autonomous, offline-capable, and fully functional.*
