import {
  Customer,
  MeasurementRecord,
  Order,
  InventoryItem,
  ExpenseRecord,
  PaymentRecord,
  ShopSettings,
  User,
  OrderStatus
} from '../types';

const STORAGE_KEYS = {
  CUSTOMERS: 'smart_tailor_customers',
  MEASUREMENTS: 'smart_tailor_measurements',
  ORDERS: 'smart_tailor_orders',
  INVENTORY: 'smart_tailor_inventory',
  EXPENSES: 'smart_tailor_expenses',
  PAYMENTS: 'smart_tailor_payments',
  SETTINGS: 'smart_tailor_settings',
  AUTH_USER: 'smart_tailor_user'
};

export const DEFAULT_SETTINGS: ShopSettings = {
  shopName: 'Smart Tailor & Boutique',
  tagline: 'Master Bespoke Tailoring & Designer Studio',
  ownerName: 'Master R. Senthil Kumar',
  phone: '+91 98450 12345',
  alternatePhone: '+91 80 2345 6789',
  email: 'contact@smarttailor.in',
  address: 'No. 42, Gandhi Bazaar Main Road, Basavanagudi, Bengaluru - 560004, Karnataka',
  gstin: '29AABCS1429B1Z8',
  currencySymbol: '₹',
  defaultUnit: 'inches',
  invoicePrefix: 'STB',
  invoiceFooterTerms: '1. Please collect garments within 30 days of delivery date.\n2. Trial alterations within 7 days of collection are complimentary.\n3. Goods once tailored cannot be returned or refunded.'
};

export const DEFAULT_USER: User = {
  id: 'usr-1',
  username: 'admin',
  name: 'Master Senthil Kumar',
  role: 'Master Tailor',
  isLoggedIn: true
};

const INITIAL_CUSTOMERS: Customer[] = [
  {
    id: 'CUST-001',
    name: 'Priya Sundaram',
    phone: '9845098765',
    email: 'priya.sundaram@gmail.com',
    address: '402, Green Glen Layout, Bellandur, Bengaluru',
    gender: 'female',
    notes: 'Prefers deep back neck designs with latkan dori. Regular customer for bridal sarees.',
    createdAt: '2026-09-10T10:00:00Z',
    updatedAt: '2026-10-15T12:00:00Z'
  },
  {
    id: 'CUST-002',
    name: 'Rajesh Verma',
    phone: '9880123456',
    email: 'rajesh.verma@outlook.com',
    address: 'Flat 12B, Palm Meadows, Whitefield, Bengaluru',
    gender: 'male',
    notes: 'Formal shirts with French cuffs and tailored trousers.',
    createdAt: '2026-09-15T11:30:00Z',
    updatedAt: '2026-10-20T14:20:00Z'
  },
  {
    id: 'CUST-003',
    name: 'Ananya Deshmukh',
    phone: '9900554433',
    email: 'ananya.d@yahoo.com',
    address: '77, 4th Main, Malleshwaram, Bengaluru',
    gender: 'female',
    notes: 'Anarkali and Churidar suits. Likes boat neckline.',
    createdAt: '2026-09-22T09:15:00Z',
    updatedAt: '2026-10-24T16:00:00Z'
  },
  {
    id: 'CUST-004',
    name: 'Vikramaditya Rao',
    phone: '9741223344',
    email: 'vikram.rao@fintech.co',
    address: '15, Indiranagar 100ft Road, Bengaluru',
    gender: 'male',
    notes: 'Two-piece bespoke suits and linen shirts.',
    createdAt: '2026-10-01T14:00:00Z',
    updatedAt: '2026-10-22T10:00:00Z'
  },
  {
    id: 'CUST-005',
    name: 'Kavitha Ramachandran',
    phone: '9632112233',
    email: 'kavitha.r@gmail.com',
    address: '23, Jayanagar 4th Block, Bengaluru',
    gender: 'female',
    notes: 'Aari work embroidery blouse specialist orders.',
    createdAt: '2026-10-05T16:45:00Z',
    updatedAt: '2026-10-25T11:15:00Z'
  },
  {
    id: 'CUST-006',
    name: 'Mohammed Farooq',
    phone: '9844099881',
    email: 'm.farooq@textiles.in',
    address: '56, Commercial Street, Shivaji Nagar, Bengaluru',
    gender: 'male',
    notes: 'Kurta Pyjama and Pathani suits with collar stiffening.',
    createdAt: '2026-10-12T13:20:00Z',
    updatedAt: '2026-10-26T17:00:00Z'
  }
];

const INITIAL_MEASUREMENTS: MeasurementRecord[] = [
  {
    id: 'MEAS-001',
    customerId: 'CUST-001',
    customerName: 'Priya Sundaram',
    garmentType: 'blouse',
    title: 'Bridal Kanjeevaram Silk Blouse',
    unit: 'inches',
    values: {
      length: '14.5',
      chest: '36.0',
      upperBust: '34.5',
      waist: '30.0',
      shoulder: '14.5',
      armhole: '16.5',
      sleeveLength: '11.0',
      sleeveRound: '12.0',
      frontNeck: '7.0',
      backNeck: '10.5',
      crossFront: '12.5',
      crossBack: '13.5',
      bustPoint: '9.5',
      cupPadding: 'Padded'
    },
    recordedDate: '2026-10-15',
    notes: 'Deep pot-neck back cut with double piping and hand-stitched beaded tassels'
  },
  {
    id: 'MEAS-002',
    customerId: 'CUST-002',
    customerName: 'Rajesh Verma',
    garmentType: 'shirt',
    title: 'Formal Business Shirt (Slim Fit)',
    unit: 'inches',
    values: {
      length: '29.5',
      chest: '40.0',
      waist: '35.5',
      hip: '41.0',
      shoulder: '18.0',
      sleeveLength: '25.0',
      collar: '15.5',
      cuff: '9.25',
      bicep: '14.0',
      fitType: 'Slim Fit'
    },
    recordedDate: '2026-10-18',
    notes: 'Cutaway collar with collar stays pocket, French double cuffs'
  },
  {
    id: 'MEAS-003',
    customerId: 'CUST-002',
    customerName: 'Rajesh Verma',
    garmentType: 'pants',
    title: 'Italian Wool Formal Trousers',
    unit: 'inches',
    values: {
      waist: '34.0',
      hip: '40.5',
      outseam: '41.0',
      inseam: '30.5',
      thigh: '24.5',
      knee: '18.5',
      bottomHem: '14.5',
      frontRise: '10.5',
      backRise: '14.5'
    },
    recordedDate: '2026-10-18',
    notes: 'Flat front, cross side pockets, no turn-up cuff hem'
  },
  {
    id: 'MEAS-004',
    customerId: 'CUST-003',
    customerName: 'Ananya Deshmukh',
    garmentType: 'churidar',
    title: 'Party Wear Churidar Kurti Suit',
    unit: 'inches',
    values: {
      kameezLength: '43.0',
      bust: '37.0',
      waist: '32.0',
      hip: '41.0',
      slitPoint: '21.5',
      shoulder: '14.5',
      armhole: '16.5',
      sleeveLength: '16.5',
      sleeveRound: '10.5',
      frontNeck: '6.5',
      bottomLength: '45.0',
      ankleRound: '10.0',
      crotchRise: '13.5'
    },
    recordedDate: '2026-10-20',
    notes: 'Extra gather pleats for churidar legs, boat neck with gota patti lining'
  },
  {
    id: 'MEAS-005',
    customerId: 'CUST-004',
    customerName: 'Vikramaditya Rao',
    garmentType: 'suit',
    title: 'Executive Navy Two-Piece Blazer',
    unit: 'inches',
    values: {
      jacketLength: '30.0',
      chest: '42.0',
      waist: '37.0',
      shoulder: '18.5',
      sleeveLength: '25.5',
      trouserWaist: '35.0',
      trouserLength: '41.5'
    },
    recordedDate: '2026-10-22',
    notes: 'Peak lapel, dual vents, genuine horn button fastening'
  },
  {
    id: 'MEAS-006',
    customerId: 'CUST-005',
    customerName: 'Kavitha Ramachandran',
    garmentType: 'blouse',
    title: 'Temple Border Silk Saree Blouse',
    unit: 'inches',
    values: {
      length: '14.0',
      chest: '35.0',
      upperBust: '33.5',
      waist: '29.0',
      shoulder: '14.0',
      armhole: '15.5',
      sleeveLength: '10.0',
      sleeveRound: '11.0',
      frontNeck: '6.5',
      backNeck: '9.5',
      crossFront: '12.0',
      crossBack: '13.0',
      bustPoint: '9.0',
      cupPadding: 'Non-Padded'
    },
    recordedDate: '2026-10-25',
    notes: 'Princess cut stitching with inner pure cotton lining'
  }
];

const INITIAL_ORDERS: Order[] = [
  {
    id: 'ORD-2026-001',
    customerId: 'CUST-001',
    customerName: 'Priya Sundaram',
    customerPhone: '9845098765',
    garmentType: 'blouse',
    garmentDescription: 'Bridal Kanjeevaram Blouse with Aari Gold Thread Work',
    quantity: 1,
    fabricDetails: {
      fabricType: 'Pure Mulberry Silk',
      color: 'Crimson Red & Gold Zari',
      pattern: 'Temple Motif Borders',
      customerProvided: true,
      lengthMeters: 1.0,
      notes: 'Customer brought 1 meter border cloth, shop to supply matching lining and padding'
    },
    measurementId: 'MEAS-001',
    measurementsSnapshot: {
      length: '14.5',
      chest: '36.0',
      waist: '30.0',
      shoulder: '14.5',
      sleeveLength: '11.0',
      frontNeck: '7.0',
      backNeck: '10.5'
    },
    measurementUnit: 'inches',
    status: 'stitching',
    priority: 'urgent',
    orderDate: '2026-10-20',
    trialDate: '2026-10-27',
    deliveryDate: '2026-10-30',
    charges: {
      stitchingCharge: 1200,
      addOnCharges: 800, // Aari hand embroidery work & padded cups
      fabricCharge: 250, // Premium cotton lining & dori latkans
      discount: 100,
      totalAmount: 2150,
      advancePaid: 1000,
      balanceAmount: 1150
    },
    assignedTailor: 'Master Murugan',
    notes: 'Wedding on 2nd Nov. Keep extra 1.5 inch side margins for future alteration.',
    statusHistory: [
      { status: 'received', timestamp: '2026-10-20T10:30:00Z', note: 'Order registered with silk fabric and advance payment' },
      { status: 'cutting', timestamp: '2026-10-22T14:15:00Z', note: 'Pattern cut by Master Senthil' },
      { status: 'stitching', timestamp: '2026-10-25T11:00:00Z', note: 'Handed to Master Murugan for Aari work and stitching' }
    ],
    createdAt: '2026-10-20T10:30:00Z',
    updatedAt: '2026-10-25T11:00:00Z'
  },
  {
    id: 'ORD-2026-002',
    customerId: 'CUST-002',
    customerName: 'Rajesh Verma',
    customerPhone: '9880123456',
    garmentType: 'shirt',
    garmentDescription: 'Giza Cotton Executive Shirt - Sky Blue Pinstripe',
    quantity: 2,
    fabricDetails: {
      fabricType: 'Egyptian Giza 100s Cotton',
      color: 'Sky Blue with White Hairline Stripe',
      pattern: 'Striped',
      customerProvided: false,
      lengthMeters: 3.2,
      notes: 'Provided from shop fabric bolt stock #GIZA-402'
    },
    measurementId: 'MEAS-002',
    measurementsSnapshot: {
      length: '29.5',
      chest: '40.0',
      waist: '35.5',
      shoulder: '18.0',
      sleeveLength: '25.0',
      collar: '15.5'
    },
    measurementUnit: 'inches',
    status: 'ready',
    priority: 'standard',
    orderDate: '2026-10-18',
    trialDate: '2026-10-24',
    deliveryDate: '2026-10-28', // Today!
    charges: {
      stitchingCharge: 1100, // 550 x 2
      addOnCharges: 200, // Mother-of-pearl buttons & monogram 'RV'
      fabricCharge: 1400,
      discount: 100,
      totalAmount: 2600,
      advancePaid: 1500,
      balanceAmount: 1100
    },
    assignedTailor: 'Tailor Ramesh',
    notes: 'Monogram on left cuff in navy silk thread. Ironed and packed in garment bag.',
    statusHistory: [
      { status: 'received', timestamp: '2026-10-18T12:00:00Z' },
      { status: 'cutting', timestamp: '2026-10-19T10:00:00Z' },
      { status: 'stitching', timestamp: '2026-10-22T16:00:00Z' },
      { status: 'trial', timestamp: '2026-10-24T15:00:00Z', note: 'Customer trial done, sleeve length approved' },
      { status: 'ready', timestamp: '2026-10-27T17:00:00Z', note: 'Pressed, steam sanitized, hanger bagged' }
    ],
    createdAt: '2026-10-18T12:00:00Z',
    updatedAt: '2026-10-27T17:00:00Z'
  },
  {
    id: 'ORD-2026-003',
    customerId: 'CUST-003',
    customerName: 'Ananya Deshmukh',
    customerPhone: '9900554433',
    garmentType: 'churidar',
    garmentDescription: 'Chanderi Silk Festive Churidar Kameez with Dupatta Styling',
    quantity: 1,
    fabricDetails: {
      fabricType: 'Chanderi Silk & Shantoon Bottom',
      color: 'Emerald Green & Gold',
      customerProvided: true,
      lengthMeters: 4.5,
      notes: 'Customer provided 3-piece unstitched suit material'
    },
    measurementId: 'MEAS-004',
    measurementsSnapshot: {
      kameezLength: '43.0',
      bust: '37.0',
      waist: '32.0',
      bottomLength: '45.0',
      ankleRound: '10.0'
    },
    measurementUnit: 'inches',
    status: 'trial',
    priority: 'standard',
    orderDate: '2026-10-20',
    trialDate: '2026-10-28', // Today
    deliveryDate: '2026-10-31',
    charges: {
      stitchingCharge: 950,
      addOnCharges: 250, // Shantoon inner lining & fancy neckline lace
      fabricCharge: 0,
      discount: 50,
      totalAmount: 1150,
      advancePaid: 600,
      balanceAmount: 550
    },
    assignedTailor: 'Tailor Fatima',
    notes: 'Trial scheduled for today afternoon at 4 PM.',
    statusHistory: [
      { status: 'received', timestamp: '2026-10-20T14:00:00Z' },
      { status: 'cutting', timestamp: '2026-10-22T11:00:00Z' },
      { status: 'stitching', timestamp: '2026-10-25T14:30:00Z' },
      { status: 'trial', timestamp: '2026-10-27T18:00:00Z', note: 'Basting done for trial fit' }
    ],
    createdAt: '2026-10-20T14:00:00Z',
    updatedAt: '2026-10-27T18:00:00Z'
  },
  {
    id: 'ORD-2026-004',
    customerId: 'CUST-004',
    customerName: 'Vikramaditya Rao',
    customerPhone: '9741223344',
    garmentType: 'suit',
    garmentDescription: 'Midnight Navy Two-Piece Formal Business Suit',
    quantity: 1,
    fabricDetails: {
      fabricType: 'Raymond Super 120s Wool Blend',
      color: 'Midnight Navy Blue',
      pattern: 'Solid Matte',
      customerProvided: false,
      lengthMeters: 3.5,
      notes: 'Fabric bolt Raymond Super 120s Wool #RN-99'
    },
    measurementId: 'MEAS-005',
    measurementsSnapshot: {
      jacketLength: '30.0',
      chest: '42.0',
      waist: '37.0',
      trouserWaist: '35.0',
      trouserLength: '41.5'
    },
    measurementUnit: 'inches',
    status: 'cutting',
    priority: 'standard',
    orderDate: '2026-10-22',
    trialDate: '2026-10-29',
    deliveryDate: '2026-11-05',
    charges: {
      stitchingCharge: 4500,
      addOnCharges: 600, // Canvas chest piece, horn buttons, satin lining
      fabricCharge: 3800,
      discount: 300,
      totalAmount: 8600,
      advancePaid: 4500,
      balanceAmount: 4100
    },
    assignedTailor: 'Master Senthil Kumar',
    notes: 'Premium horsehair canvas interlining cut. Ready for first fitting.',
    statusHistory: [
      { status: 'received', timestamp: '2026-10-22T15:00:00Z' },
      { status: 'cutting', timestamp: '2026-10-26T10:00:00Z', note: 'Pattern drafted and hand-sheared' }
    ],
    createdAt: '2026-10-22T15:00:00Z',
    updatedAt: '2026-10-26T10:00:00Z'
  },
  {
    id: 'ORD-2026-005',
    customerId: 'CUST-005',
    customerName: 'Kavitha Ramachandran',
    customerPhone: '9632112233',
    garmentType: 'blouse',
    garmentDescription: 'Traditional Princess Cut Kanchipuram Saree Blouse',
    quantity: 1,
    fabricDetails: {
      fabricType: 'Kanchi Pure Silk',
      color: 'Mustard Yellow with Maroon Border',
      customerProvided: true,
      lengthMeters: 0.9,
      notes: 'Customer provided'
    },
    measurementId: 'MEAS-006',
    measurementsSnapshot: {
      length: '14.0',
      chest: '35.0',
      waist: '29.0',
      frontNeck: '6.5',
      backNeck: '9.5'
    },
    measurementUnit: 'inches',
    status: 'delivered',
    priority: 'standard',
    orderDate: '2026-10-10',
    trialDate: '2026-10-18',
    deliveryDate: '2026-10-22',
    deliveredDate: '2026-10-22',
    charges: {
      stitchingCharge: 850,
      addOnCharges: 150,
      fabricCharge: 120, // Cotton lining
      discount: 0,
      totalAmount: 1120,
      advancePaid: 500,
      balanceAmount: 0 // Fully paid
    },
    assignedTailor: 'Tailor Ramesh',
    notes: 'Delivered in good condition, customer verified fit.',
    statusHistory: [
      { status: 'received', timestamp: '2026-10-10T11:00:00Z' },
      { status: 'cutting', timestamp: '2026-10-12T10:00:00Z' },
      { status: 'stitching', timestamp: '2026-10-15T15:00:00Z' },
      { status: 'ready', timestamp: '2026-10-20T17:00:00Z' },
      { status: 'delivered', timestamp: '2026-10-22T18:30:00Z', note: 'Collected by customer, final balance ₹620 paid via UPI' }
    ],
    createdAt: '2026-10-10T11:00:00Z',
    updatedAt: '2026-10-22T18:30:00Z'
  },
  {
    id: 'ORD-2026-006',
    customerId: 'CUST-006',
    customerName: 'Mohammed Farooq',
    customerPhone: '9844099881',
    garmentType: 'kurta',
    garmentDescription: 'Linen Pathani Kurta & Pyjama Set',
    quantity: 1,
    fabricDetails: {
      fabricType: 'Pure Irish Linen',
      color: 'Crisp White',
      customerProvided: true,
      lengthMeters: 4.0
    },
    measurementUnit: 'inches',
    measurementsSnapshot: {
      length: '42.0',
      chest: '40.0',
      shoulder: '18.0',
      collar: '16.0'
    },
    status: 'stitching',
    priority: 'urgent',
    orderDate: '2026-10-19',
    deliveryDate: '2026-10-25', // OVERDUE by 3 days!
    charges: {
      stitchingCharge: 1200,
      addOnCharges: 100, // Metal snap buttons
      fabricCharge: 0,
      discount: 0,
      totalAmount: 1300,
      advancePaid: 700,
      balanceAmount: 600
    },
    assignedTailor: 'Tailor Ramesh',
    notes: 'Customer needed for family engagement. OVERDUE - expedite stitching immediately.',
    statusHistory: [
      { status: 'received', timestamp: '2026-10-19T13:00:00Z' },
      { status: 'cutting', timestamp: '2026-10-21T16:00:00Z' },
      { status: 'stitching', timestamp: '2026-10-24T12:00:00Z', note: 'Delayed due to buttonhole machine service' }
    ],
    createdAt: '2026-10-19T13:00:00Z',
    updatedAt: '2026-10-24T12:00:00Z'
  },
  {
    id: 'ORD-2026-007',
    customerId: 'CUST-001',
    customerName: 'Priya Sundaram',
    customerPhone: '9845098765',
    garmentType: 'blouse',
    garmentDescription: 'Designer Velvet Sleeveless Saree Blouse',
    quantity: 1,
    fabricDetails: {
      fabricType: 'Micro Velvet & Crepe',
      color: 'Bottle Green',
      customerProvided: false,
      lengthMeters: 1.0
    },
    measurementId: 'MEAS-001',
    measurementsSnapshot: {
      length: '14.5',
      chest: '36.0',
      waist: '30.0',
      frontNeck: '7.5',
      backNeck: '11.0'
    },
    measurementUnit: 'inches',
    status: 'received',
    priority: 'standard',
    orderDate: '2026-10-26',
    deliveryDate: '2026-11-04',
    charges: {
      stitchingCharge: 950,
      addOnCharges: 300, // High density pads & side invisible zipper
      fabricCharge: 450,
      discount: 50,
      totalAmount: 1650,
      advancePaid: 800,
      balanceAmount: 850
    },
    notes: 'Side concealed zip opening, sweetheart neckline',
    statusHistory: [
      { status: 'received', timestamp: '2026-10-26T16:00:00Z', note: 'Order registered' }
    ],
    createdAt: '2026-10-26T16:00:00Z',
    updatedAt: '2026-10-26T16:00:00Z'
  }
];

const INITIAL_INVENTORY: InventoryItem[] = [
  {
    id: 'INV-001',
    name: 'Pure Cotton Blouse Voile Lining (White)',
    category: 'lining',
    color: 'Pure White',
    quantity: 48,
    unit: 'meters',
    minThreshold: 20,
    costPerUnit: 65,
    supplier: 'Lakshmi Cotton Mills, Erode',
    lastUpdated: '2026-10-25'
  },
  {
    id: 'INV-002',
    name: 'Pure Cotton Blouse Voile Lining (Black)',
    category: 'lining',
    color: 'Jet Black',
    quantity: 12, // LOW STOCK ALERT
    unit: 'meters',
    minThreshold: 20,
    costPerUnit: 65,
    supplier: 'Lakshmi Cotton Mills, Erode',
    lastUpdated: '2026-10-26'
  },
  {
    id: 'INV-003',
    name: 'Madura Coats Polyester Spun Sewing Thread (Red)',
    category: 'thread',
    color: 'Maroon / Crimson Red',
    quantity: 18,
    unit: 'spools',
    minThreshold: 10,
    costPerUnit: 35,
    supplier: 'Coats India Distributor',
    lastUpdated: '2026-10-20'
  },
  {
    id: 'INV-004',
    name: 'Madura Coats Sewing Thread (Gold Zari)',
    category: 'thread',
    color: 'Metallic Gold',
    quantity: 4, // LOW STOCK ALERT
    unit: 'spools',
    minThreshold: 8,
    costPerUnit: 120,
    supplier: 'Surat Zari Works',
    lastUpdated: '2026-10-22'
  },
  {
    id: 'INV-005',
    name: 'Mother of Pearl Formal Shirt Buttons (18L)',
    category: 'button',
    color: 'Natural Iridescent Shell',
    quantity: 350,
    unit: 'pieces',
    minThreshold: 100,
    costPerUnit: 4.5,
    supplier: 'Apex Button Trims, Mumbai',
    lastUpdated: '2026-10-18'
  },
  {
    id: 'INV-006',
    name: 'Suit Horn Buttons 4-Hole (Black)',
    category: 'button',
    color: 'Matte Charcoal Black',
    quantity: 80,
    unit: 'pieces',
    minThreshold: 50,
    costPerUnit: 15,
    supplier: 'Apex Button Trims, Mumbai',
    lastUpdated: '2026-10-15'
  },
  {
    id: 'INV-007',
    name: 'YKK Concealed Invisible Zippers 12"',
    category: 'zipper',
    color: 'Assorted (Black, White, Red, Green)',
    quantity: 8, // LOW STOCK ALERT
    unit: 'pieces',
    minThreshold: 25,
    costPerUnit: 28,
    supplier: 'YKK South Hub',
    lastUpdated: '2026-10-24'
  },
  {
    id: 'INV-008',
    name: 'Fusible Collar Canvas & Cuff Interlining',
    category: 'fabric',
    color: 'White Stiff',
    quantity: 35,
    unit: 'meters',
    minThreshold: 15,
    costPerUnit: 90,
    supplier: 'Freudenberg Interlinings',
    lastUpdated: '2026-10-10'
  },
  {
    id: 'INV-009',
    name: 'Bra Cups Foam Pads (Round & Teardrop)',
    category: 'accessory',
    color: 'Nude / White',
    quantity: 45,
    unit: 'pieces',
    minThreshold: 20,
    costPerUnit: 40,
    supplier: 'Bangalore Trims Agency',
    lastUpdated: '2026-10-21'
  },
  {
    id: 'INV-010',
    name: 'Gota Patti & Zari Fancy Border Laces',
    category: 'accessory',
    color: 'Antique Gold',
    quantity: 60,
    unit: 'meters',
    minThreshold: 25,
    costPerUnit: 45,
    supplier: 'Jaipur Crafts Bazaar',
    lastUpdated: '2026-10-14'
  }
];

const INITIAL_EXPENSES: ExpenseRecord[] = [
  {
    id: 'EXP-001',
    category: 'rent',
    description: 'Shop Monthly Rent - Basavanagudi Premises',
    amount: 18000,
    date: '2026-10-01',
    paidTo: 'Building Landlord Mr. Krishna'
  },
  {
    id: 'EXP-002',
    category: 'electricity',
    description: 'BESCOM Commercial Electricity Bill',
    amount: 3240,
    date: '2026-10-05',
    paidTo: 'BESCOM online'
  },
  {
    id: 'EXP-003',
    category: 'tailor_wages',
    description: 'Weekly Piece-rate Wages for Master Murugan & Tailor Ramesh',
    amount: 9500,
    date: '2026-10-18',
    paidTo: 'Murugan & Ramesh'
  },
  {
    id: 'EXP-004',
    category: 'machinery_maintenance',
    description: 'Juki Industrial Sewing Machine Servicing & Oil Change',
    amount: 1450,
    date: '2026-10-21',
    paidTo: 'Sree Machine Works'
  },
  {
    id: 'EXP-005',
    category: 'threads_materials',
    description: 'Bulk purchase of threads, needles, and cutting chalk',
    amount: 2800,
    date: '2026-10-22',
    paidTo: 'Coats India Agency'
  },
  {
    id: 'EXP-006',
    category: 'tea_snacks',
    description: 'Tailors daily tea and evening snacks',
    amount: 650,
    date: '2026-10-24',
    paidTo: 'Bhavani Tea Stall'
  }
];

const INITIAL_PAYMENTS: PaymentRecord[] = [
  {
    id: 'PAY-001',
    receiptNo: 'RCP-1001',
    orderId: 'ORD-2026-001',
    customerId: 'CUST-001',
    customerName: 'Priya Sundaram',
    amount: 1000,
    date: '2026-10-20',
    method: 'upi',
    notes: 'Advance booking payment via GooglePay'
  },
  {
    id: 'PAY-002',
    receiptNo: 'RCP-1002',
    orderId: 'ORD-2026-002',
    customerId: 'CUST-002',
    customerName: 'Rajesh Verma',
    amount: 1500,
    date: '2026-10-18',
    method: 'card',
    notes: 'Advance swipe on POS machine'
  },
  {
    id: 'PAY-003',
    receiptNo: 'RCP-1003',
    orderId: 'ORD-2026-003',
    customerId: 'CUST-003',
    customerName: 'Ananya Deshmukh',
    amount: 600,
    date: '2026-10-20',
    method: 'cash',
    notes: 'Cash advance at counter'
  },
  {
    id: 'PAY-004',
    receiptNo: 'RCP-1004',
    orderId: 'ORD-2026-004',
    customerId: 'CUST-004',
    customerName: 'Vikramaditya Rao',
    amount: 4500,
    date: '2026-10-22',
    method: 'bank_transfer',
    notes: 'NEFT transfer for bespoke suit advance'
  },
  {
    id: 'PAY-005',
    receiptNo: 'RCP-1005',
    orderId: 'ORD-2026-005',
    customerId: 'CUST-005',
    customerName: 'Kavitha Ramachandran',
    amount: 500,
    date: '2026-10-10',
    method: 'cash',
    notes: 'Booking advance'
  },
  {
    id: 'PAY-006',
    receiptNo: 'RCP-1006',
    orderId: 'ORD-2026-005',
    customerId: 'CUST-005',
    customerName: 'Kavitha Ramachandran',
    amount: 620,
    date: '2026-10-22',
    method: 'upi',
    notes: 'Final balance payment on collection via PhonePe'
  },
  {
    id: 'PAY-007',
    receiptNo: 'RCP-1007',
    orderId: 'ORD-2026-006',
    customerId: 'CUST-006',
    customerName: 'Mohammed Farooq',
    amount: 700,
    date: '2026-10-19',
    method: 'cash',
    notes: 'Advance payment'
  },
  {
    id: 'PAY-008',
    receiptNo: 'RCP-1008',
    orderId: 'ORD-2026-007',
    customerId: 'CUST-001',
    customerName: 'Priya Sundaram',
    amount: 800,
    date: '2026-10-26',
    method: 'upi',
    notes: 'Advance payment for velvet blouse'
  }
];

class StorageService {
  private get<T>(key: string, defaultValue: T): T {
    try {
      const item = localStorage.getItem(key);
      if (!item) return defaultValue;
      return JSON.parse(item) as T;
    } catch (e) {
      console.error(`Error loading ${key} from localStorage`, e);
      return defaultValue;
    }
  }

  private set<T>(key: string, value: T): void {
    try {
      localStorage.setItem(key, JSON.stringify(value));
    } catch (e) {
      console.error(`Error writing ${key} to localStorage`, e);
    }
  }

  // Initialization check
  init(): void {
    if (!localStorage.getItem(STORAGE_KEYS.CUSTOMERS)) {
      this.resetToDefaults();
    }
  }

  resetToDefaults(): void {
    this.set(STORAGE_KEYS.CUSTOMERS, INITIAL_CUSTOMERS);
    this.set(STORAGE_KEYS.MEASUREMENTS, INITIAL_MEASUREMENTS);
    this.set(STORAGE_KEYS.ORDERS, INITIAL_ORDERS);
    this.set(STORAGE_KEYS.INVENTORY, INITIAL_INVENTORY);
    this.set(STORAGE_KEYS.EXPENSES, INITIAL_EXPENSES);
    this.set(STORAGE_KEYS.PAYMENTS, INITIAL_PAYMENTS);
    this.set(STORAGE_KEYS.SETTINGS, DEFAULT_SETTINGS);
    this.set(STORAGE_KEYS.AUTH_USER, DEFAULT_USER);
  }

  // --- Customers ---
  getCustomers(): Customer[] {
    return this.get<Customer[]>(STORAGE_KEYS.CUSTOMERS, INITIAL_CUSTOMERS);
  }

  saveCustomer(customer: Omit<Customer, 'id' | 'createdAt' | 'updatedAt'> & { id?: string }): Customer {
    const list = this.getCustomers();
    const now = new Date().toISOString();

    if (customer.id) {
      const index = list.findIndex(c => c.id === customer.id);
      if (index !== -1) {
        const updated: Customer = {
          ...list[index],
          ...customer,
          updatedAt: now
        } as Customer;
        list[index] = updated;
        this.set(STORAGE_KEYS.CUSTOMERS, list);
        return updated;
      }
    }

    // Create new
    const nextNum = list.length + 1;
    const newCustomer: Customer = {
      ...customer,
      id: `CUST-${String(nextNum).padStart(3, '0')}`,
      createdAt: now,
      updatedAt: now
    };
    list.unshift(newCustomer);
    this.set(STORAGE_KEYS.CUSTOMERS, list);
    return newCustomer;
  }

  deleteCustomer(id: string): boolean {
    const list = this.getCustomers();
    const filtered = list.filter(c => c.id !== id);
    if (filtered.length !== list.length) {
      this.set(STORAGE_KEYS.CUSTOMERS, filtered);
      return true;
    }
    return false;
  }

  // --- Measurements ---
  getMeasurements(): MeasurementRecord[] {
    return this.get<MeasurementRecord[]>(STORAGE_KEYS.MEASUREMENTS, INITIAL_MEASUREMENTS);
  }

  getMeasurementsByCustomer(customerId: string): MeasurementRecord[] {
    return this.getMeasurements().filter(m => m.customerId === customerId);
  }

  saveMeasurement(record: Omit<MeasurementRecord, 'id' | 'recordedDate'> & { id?: string; recordedDate?: string }): MeasurementRecord {
    const list = this.getMeasurements();
    const today = new Date().toISOString().split('T')[0];

    if (record.id) {
      const index = list.findIndex(m => m.id === record.id);
      if (index !== -1) {
        const updated: MeasurementRecord = {
          ...list[index],
          ...record,
          recordedDate: record.recordedDate || list[index].recordedDate
        };
        list[index] = updated;
        this.set(STORAGE_KEYS.MEASUREMENTS, list);
        return updated;
      }
    }

    const nextNum = list.length + 1;
    const newMeasurement: MeasurementRecord = {
      ...record,
      id: `MEAS-${String(nextNum).padStart(3, '0')}`,
      recordedDate: record.recordedDate || today
    };
    list.unshift(newMeasurement);
    this.set(STORAGE_KEYS.MEASUREMENTS, list);
    return newMeasurement;
  }

  deleteMeasurement(id: string): boolean {
    const list = this.getMeasurements();
    const filtered = list.filter(m => m.id !== id);
    if (filtered.length !== list.length) {
      this.set(STORAGE_KEYS.MEASUREMENTS, filtered);
      return true;
    }
    return false;
  }

  // --- Orders ---
  getOrders(): Order[] {
    return this.get<Order[]>(STORAGE_KEYS.ORDERS, INITIAL_ORDERS);
  }

  getNextOrderId(): string {
    const orders = this.getOrders();
    const year = new Date().getFullYear();
    const nextNum = orders.length + 1;
    return `ORD-${year}-${String(nextNum).padStart(3, '0')}`;
  }

  saveOrder(orderData: Partial<Order> & { customerId: string; garmentType: any }): Order {
    const list = this.getOrders();
    const now = new Date().toISOString();

    if (orderData.id) {
      const index = list.findIndex(o => o.id === orderData.id);
      if (index !== -1) {
        const existing = list[index];
        const statusChanged = orderData.status && orderData.status !== existing.status;
        const newHistory = [...existing.statusHistory];
        
        if (statusChanged) {
          newHistory.push({
            status: orderData.status as OrderStatus,
            timestamp: now,
            note: `Status changed to ${orderData.status}`
          });
        }

        const updated: Order = {
          ...existing,
          ...orderData,
          statusHistory: orderData.statusHistory || newHistory,
          updatedAt: now
        } as Order;

        list[index] = updated;
        this.set(STORAGE_KEYS.ORDERS, list);
        return updated;
      }
    }

    // New Order
    const newId = orderData.id || this.getNextOrderId();
    const initialStatus = orderData.status || 'received';
    const newOrder: Order = {
      id: newId,
      customerId: orderData.customerId,
      customerName: orderData.customerName || 'Customer',
      customerPhone: orderData.customerPhone || '',
      garmentType: orderData.garmentType,
      garmentDescription: orderData.garmentDescription || 'Tailored Garment',
      quantity: orderData.quantity || 1,
      fabricDetails: orderData.fabricDetails || {
        fabricType: 'Standard Fabric',
        color: 'Standard',
        customerProvided: true
      },
      measurementId: orderData.measurementId,
      measurementsSnapshot: orderData.measurementsSnapshot || {},
      measurementUnit: orderData.measurementUnit || 'inches',
      status: initialStatus,
      priority: orderData.priority || 'standard',
      orderDate: orderData.orderDate || now.split('T')[0],
      trialDate: orderData.trialDate,
      deliveryDate: orderData.deliveryDate || now.split('T')[0],
      charges: orderData.charges || {
        stitchingCharge: 500,
        addOnCharges: 0,
        fabricCharge: 0,
        discount: 0,
        totalAmount: 500,
        advancePaid: 0,
        balanceAmount: 500
      },
      assignedTailor: orderData.assignedTailor,
      notes: orderData.notes,
      statusHistory: [
        {
          status: initialStatus,
          timestamp: now,
          note: 'Order created'
        }
      ],
      createdAt: now,
      updatedAt: now
    };

    list.unshift(newOrder);
    this.set(STORAGE_KEYS.ORDERS, list);

    // If advance paid > 0, automatically record payment
    if (newOrder.charges.advancePaid > 0) {
      this.recordPayment({
        orderId: newOrder.id,
        customerId: newOrder.customerId,
        customerName: newOrder.customerName,
        amount: newOrder.charges.advancePaid,
        method: 'cash',
        notes: `Advance payment for order ${newOrder.id}`
      });
    }

    return newOrder;
  }

  updateOrderStatus(orderId: string, status: OrderStatus, note?: string): Order | null {
    const list = this.getOrders();
    const index = list.findIndex(o => o.id === orderId);
    if (index === -1) return null;

    const existing = list[index];
    const now = new Date().toISOString();
    const newHistory = [...existing.statusHistory, { status, timestamp: now, note }];

    const updated: Order = {
      ...existing,
      status,
      deliveredDate: status === 'delivered' ? now.split('T')[0] : existing.deliveredDate,
      statusHistory: newHistory,
      updatedAt: now
    };

    list[index] = updated;
    this.set(STORAGE_KEYS.ORDERS, list);
    return updated;
  }

  deleteOrder(id: string): boolean {
    const list = this.getOrders();
    const filtered = list.filter(o => o.id !== id);
    if (filtered.length !== list.length) {
      this.set(STORAGE_KEYS.ORDERS, filtered);
      return true;
    }
    return false;
  }

  // --- Payments ---
  getPayments(): PaymentRecord[] {
    return this.get<PaymentRecord[]>(STORAGE_KEYS.PAYMENTS, INITIAL_PAYMENTS);
  }

  recordPayment(payment: Omit<PaymentRecord, 'id' | 'receiptNo' | 'date'> & { date?: string }): PaymentRecord {
    const list = this.getPayments();
    const today = new Date().toISOString().split('T')[0];
    const nextReceiptNum = 1000 + list.length + 1;

    const newPayment: PaymentRecord = {
      ...payment,
      id: `PAY-${String(list.length + 1).padStart(3, '0')}`,
      receiptNo: `RCP-${nextReceiptNum}`,
      date: payment.date || today
    };

    list.unshift(newPayment);
    this.set(STORAGE_KEYS.PAYMENTS, list);

    // Sync order balance
    const orders = this.getOrders();
    const orderIndex = orders.findIndex(o => o.id === payment.orderId);
    if (orderIndex !== -1) {
      const order = orders[orderIndex];
      const newAdvance = (order.charges.advancePaid || 0) + payment.amount;
      const newBalance = Math.max(0, order.charges.totalAmount - newAdvance);
      order.charges.advancePaid = newAdvance;
      order.charges.balanceAmount = newBalance;
      orders[orderIndex] = order;
      this.set(STORAGE_KEYS.ORDERS, orders);
    }

    return newPayment;
  }

  // --- Inventory ---
  getInventory(): InventoryItem[] {
    return this.get<InventoryItem[]>(STORAGE_KEYS.INVENTORY, INITIAL_INVENTORY);
  }

  saveInventoryItem(item: Omit<InventoryItem, 'id' | 'lastUpdated'> & { id?: string }): InventoryItem {
    const list = this.getInventory();
    const today = new Date().toISOString().split('T')[0];

    if (item.id) {
      const index = list.findIndex(i => i.id === item.id);
      if (index !== -1) {
        const updated: InventoryItem = {
          ...list[index],
          ...item,
          lastUpdated: today
        };
        list[index] = updated;
        this.set(STORAGE_KEYS.INVENTORY, list);
        return updated;
      }
    }

    const nextNum = list.length + 1;
    const newItem: InventoryItem = {
      ...item,
      id: `INV-${String(nextNum).padStart(3, '0')}`,
      lastUpdated: today
    };
    list.unshift(newItem);
    this.set(STORAGE_KEYS.INVENTORY, list);
    return newItem;
  }

  adjustInventoryStock(id: string, delta: number): InventoryItem | null {
    const list = this.getInventory();
    const index = list.findIndex(i => i.id === id);
    if (index === -1) return null;

    const item = list[index];
    const newQty = Math.max(0, item.quantity + delta);
    item.quantity = newQty;
    item.lastUpdated = new Date().toISOString().split('T')[0];
    list[index] = item;
    this.set(STORAGE_KEYS.INVENTORY, list);
    return item;
  }

  deleteInventoryItem(id: string): boolean {
    const list = this.getInventory();
    const filtered = list.filter(i => i.id !== id);
    if (filtered.length !== list.length) {
      this.set(STORAGE_KEYS.INVENTORY, filtered);
      return true;
    }
    return false;
  }

  // --- Expenses ---
  getExpenses(): ExpenseRecord[] {
    return this.get<ExpenseRecord[]>(STORAGE_KEYS.EXPENSES, INITIAL_EXPENSES);
  }

  saveExpense(expense: Omit<ExpenseRecord, 'id'> & { id?: string }): ExpenseRecord {
    const list = this.getExpenses();
    const today = new Date().toISOString().split('T')[0];

    if (expense.id) {
      const index = list.findIndex(e => e.id === expense.id);
      if (index !== -1) {
        const updated: ExpenseRecord = {
          ...list[index],
          ...expense
        };
        list[index] = updated;
        this.set(STORAGE_KEYS.EXPENSES, list);
        return updated;
      }
    }

    const nextNum = list.length + 1;
    const newExpense: ExpenseRecord = {
      ...expense,
      id: `EXP-${String(nextNum).padStart(3, '0')}`,
      date: expense.date || today
    };
    list.unshift(newExpense);
    this.set(STORAGE_KEYS.EXPENSES, list);
    return newExpense;
  }

  deleteExpense(id: string): boolean {
    const list = this.getExpenses();
    const filtered = list.filter(e => e.id !== id);
    if (filtered.length !== list.length) {
      this.set(STORAGE_KEYS.EXPENSES, filtered);
      return true;
    }
    return false;
  }

  // --- Settings ---
  getSettings(): ShopSettings {
    return this.get<ShopSettings>(STORAGE_KEYS.SETTINGS, DEFAULT_SETTINGS);
  }

  saveSettings(settings: ShopSettings): void {
    this.set(STORAGE_KEYS.SETTINGS, settings);
  }

  // --- Auth User ---
  getUser(): User {
    return this.get<User>(STORAGE_KEYS.AUTH_USER, DEFAULT_USER);
  }

  setUser(user: User): void {
    this.set(STORAGE_KEYS.AUTH_USER, user);
  }

  // --- Backup & Restore ---
  exportBackup(): string {
    const backup = {
      version: '1.0',
      exportedAt: new Date().toISOString(),
      shopName: this.getSettings().shopName,
      customers: this.getCustomers(),
      measurements: this.getMeasurements(),
      orders: this.getOrders(),
      inventory: this.getInventory(),
      expenses: this.getExpenses(),
      payments: this.getPayments(),
      settings: this.getSettings()
    };
    return JSON.stringify(backup, null, 2);
  }

  importBackup(jsonString: string): { success: boolean; message: string } {
    try {
      const data = JSON.parse(jsonString);
      if (data.customers) this.set(STORAGE_KEYS.CUSTOMERS, data.customers);
      if (data.measurements) this.set(STORAGE_KEYS.MEASUREMENTS, data.measurements);
      if (data.orders) this.set(STORAGE_KEYS.ORDERS, data.orders);
      if (data.inventory) this.set(STORAGE_KEYS.INVENTORY, data.inventory);
      if (data.expenses) this.set(STORAGE_KEYS.EXPENSES, data.expenses);
      if (data.payments) this.set(STORAGE_KEYS.PAYMENTS, data.payments);
      if (data.settings) this.set(STORAGE_KEYS.SETTINGS, data.settings);
      return { success: true, message: 'Database restored successfully!' };
    } catch (e: any) {
      return { success: false, message: e.message || 'Invalid backup JSON file' };
    }
  }
}

export const storageService = new StorageService();
// Initialize storage
storageService.init();
