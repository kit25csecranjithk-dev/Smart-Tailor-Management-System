import { OrderStatus, OrderPriority, GarmentType } from '../types';

export const formatINR = (amount: number = 0): string => {
  return new Intl.NumberFormat('en-IN', {
    style: 'currency',
    currency: 'INR',
    maximumFractionDigits: 0
  }).format(amount);
};

export const formatDate = (dateStr: string): string => {
  if (!dateStr) return 'N/A';
  try {
    const d = new Date(dateStr);
    if (isNaN(d.getTime())) return dateStr;
    return d.toLocaleDateString('en-IN', {
      day: '2-digit',
      month: 'short',
      year: 'numeric'
    });
  } catch {
    return dateStr;
  }
};

export const formatDateTime = (isoStr: string): string => {
  if (!isoStr) return 'N/A';
  try {
    const d = new Date(isoStr);
    if (isNaN(d.getTime())) return isoStr;
    return d.toLocaleDateString('en-IN', {
      day: '2-digit',
      month: 'short',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  } catch {
    return isoStr;
  }
};

export const isToday = (dateStr: string): boolean => {
  if (!dateStr) return false;
  const d = new Date(dateStr).toISOString().split('T')[0];
  const today = new Date().toISOString().split('T')[0];
  return d === today;
};

export const isOverdue = (deliveryDateStr: string, status: OrderStatus): boolean => {
  if (status === 'delivered') return false;
  if (!deliveryDateStr) return false;
  const delivery = new Date(deliveryDateStr).toISOString().split('T')[0];
  const today = new Date().toISOString().split('T')[0];
  return delivery < today;
};

export const getDaysRemaining = (deliveryDateStr: string): number => {
  if (!deliveryDateStr) return 0;
  const target = new Date(deliveryDateStr);
  const today = new Date();
  target.setHours(0, 0, 0, 0);
  today.setHours(0, 0, 0, 0);
  const diffTime = target.getTime() - today.getTime();
  return Math.ceil(diffTime / (1000 * 60 * 60 * 24));
};

export const getStatusLabel = (status: OrderStatus): string => {
  switch (status) {
    case 'received': return 'Order Received';
    case 'cutting': return 'Cutting';
    case 'stitching': return 'Stitching';
    case 'trial': return 'Trial / Alteration';
    case 'ready': return 'Ready for Delivery';
    case 'delivered': return 'Delivered';
    default: return status;
  }
};

export const getStatusColorClasses = (status: OrderStatus): { bg: string; text: string; border: string } => {
  switch (status) {
    case 'received':
      return { bg: 'bg-[#F4F1EA]', text: 'text-[#4A5568]', border: 'border-[#E2D9CC]' };
    case 'cutting':
      return { bg: 'bg-[#FFF7ED]', text: 'text-[#C2410C]', border: 'border-[#FED7AA]' };
    case 'stitching':
      return { bg: 'bg-[#EFF6FF]', text: 'text-[#1D4ED8]', border: 'border-[#BFDBFE]' };
    case 'trial':
      return { bg: 'bg-[#FAF5FF]', text: 'text-[#7E22CE]', border: 'border-[#E9D5FF]' };
    case 'ready':
      return { bg: 'bg-[#ECFDF5]', text: 'text-[#047857]', border: 'border-[#A7F3D0]' };
    case 'delivered':
      return { bg: 'bg-[#F8FAFC]', text: 'text-[#334155]', border: 'border-[#E2E8F0]' };
    default:
      return { bg: 'bg-stone-100', text: 'text-stone-700', border: 'border-stone-200' };
  }
};

export const getPriorityBadge = (priority: OrderPriority): { label: string; classes: string } => {
  switch (priority) {
    case 'express':
      return { label: 'Express (1-2 Days)', classes: 'text-red-700 bg-red-50 border-red-200' };
    case 'urgent':
      return { label: 'Urgent', classes: 'text-amber-800 bg-amber-50 border-amber-200' };
    case 'standard':
    default:
      return { label: 'Standard', classes: 'text-slate-700 bg-slate-50 border-slate-200' };
  }
};

export const getGarmentName = (type: GarmentType): string => {
  switch (type) {
    case 'blouse': return 'Saree Blouse';
    case 'shirt': return 'Shirt';
    case 'pants': return 'Trouser / Pants';
    case 'churidar': return 'Churidar / Salwar';
    case 'kurta': return 'Kurta';
    case 'suit': return 'Suit / Blazer';
    case 'custom': return 'Custom Stitch';
    default: return type;
  }
};
