import { GarmentType } from '../types';

export interface MeasurementField {
  key: string;
  label: string;
  placeholder: string;
  description: string;
  defaultValue?: number;
  category?: string;
}

export const MEASUREMENT_TEMPLATES: Record<GarmentType, { name: string; fields: MeasurementField[] }> = {
  blouse: {
    name: 'Blouse (Saree Blouse)',
    fields: [
      { key: 'length', label: 'Blouse Length', placeholder: '14.0', description: 'Shoulder point to desired lower edge' },
      { key: 'chest', label: 'Bust / Chest', placeholder: '36.0', description: 'Around the fullest part of bust' },
      { key: 'upperBust', label: 'Upper Bust', placeholder: '34.5', description: 'Under armpits across upper chest' },
      { key: 'waist', label: 'Blouse Waist (Underbust)', placeholder: '30.0', description: 'Around bottom rim where blouse band sits' },
      { key: 'shoulder', label: 'Shoulder Width', placeholder: '14.5', description: 'From shoulder bone to shoulder bone' },
      { key: 'armhole', label: 'Armhole Round', placeholder: '16.0', description: 'Around arm joint loosely' },
      { key: 'sleeveLength', label: 'Sleeve Length', placeholder: '10.5', description: 'Shoulder tip to sleeve end (elbow/short/long)' },
      { key: 'sleeveRound', label: 'Sleeve Hem Round', placeholder: '11.5', description: 'Circumference at sleeve bottom edge' },
      { key: 'frontNeck', label: 'Front Neck Depth', placeholder: '6.5', description: 'Shoulder top diagonally to front neckline' },
      { key: 'backNeck', label: 'Back Neck Depth', placeholder: '9.0', description: 'Shoulder top down to back neck cutout' },
      { key: 'crossFront', label: 'Cross Front', placeholder: '12.5', description: 'Between arm creases across upper chest' },
      { key: 'crossBack', label: 'Cross Back', placeholder: '13.5', description: 'Across shoulder blades' },
      { key: 'bustPoint', label: 'Apex / Bust Point', placeholder: '9.5', description: 'Shoulder point down to bust nipple apex' },
      { key: 'cupPadding', label: 'Padding Type', placeholder: 'Padded / Non-Padded', description: 'Select cup padding style' },
    ]
  },
  shirt: {
    name: 'Formal / Casual Shirt',
    fields: [
      { key: 'length', label: 'Shirt Length', placeholder: '29.0', description: 'Collar seam straight down to bottom hem' },
      { key: 'chest', label: 'Chest Round', placeholder: '40.0', description: 'Around the fullest point of chest under arms' },
      { key: 'waist', label: 'Shirt Waist', placeholder: '36.0', description: 'Natural waistline / midsection round' },
      { key: 'hip', label: 'Bottom / Hip', placeholder: '41.0', description: 'Circumference at shirt lower hem' },
      { key: 'shoulder', label: 'Shoulder Width', placeholder: '18.0', description: 'Shoulder seam to shoulder seam across back' },
      { key: 'sleeveLength', label: 'Sleeve Length', placeholder: '25.0', description: 'Shoulder edge to wrist cuff end' },
      { key: 'collar', label: 'Collar / Neck', placeholder: '15.5', description: 'Base of neck plus one finger ease' },
      { key: 'cuff', label: 'Cuff Round', placeholder: '9.0', description: 'Around wrist circumference + ease' },
      { key: 'bicep', label: 'Bicep / Arm Round', placeholder: '14.0', description: 'Widest circumference of bicep' },
      { key: 'fitType', label: 'Fit Style', placeholder: 'Slim / Regular / Comfort', description: 'Desired silhouette' }
    ]
  },
  pants: {
    name: 'Trousers / Formal Pants',
    fields: [
      { key: 'waist', label: 'Pants Waist', placeholder: '34.0', description: 'Where trouser waistband sits comfortably' },
      { key: 'hip', label: 'Seat / Hip', placeholder: '40.0', description: 'Around fullest part of buttocks/seat' },
      { key: 'outseam', label: 'Full Length (Outseam)', placeholder: '40.5', description: 'Waistband top to ankle shoe line' },
      { key: 'inseam', label: 'Inseam Length', placeholder: '30.0', description: 'From crotch seam to bottom hem' },
      { key: 'thigh', label: 'Thigh Round', placeholder: '24.0', description: 'Around upper thigh 1 inch below crotch' },
      { key: 'knee', label: 'Knee Round', placeholder: '18.0', description: 'Circumference around knee' },
      { key: 'bottomHem', label: 'Bottom / Hem Opening', placeholder: '14.5', description: 'Width of trouser bottom cuff' },
      { key: 'frontRise', label: 'Front Rise', placeholder: '10.5', description: 'Waist front down through crotch join' },
      { key: 'backRise', label: 'Back Rise', placeholder: '14.5', description: 'Waist back down through crotch join' }
    ]
  },
  churidar: {
    name: 'Churidar / Salwar Kameez',
    fields: [
      { key: 'kameezLength', label: 'Kurti / Kameez Length', placeholder: '42.0', description: 'Shoulder to desired knee or calf hem' },
      { key: 'bust', label: 'Bust Round', placeholder: '38.0', description: 'Around fullest part of bust' },
      { key: 'waist', label: 'Waist Round', placeholder: '33.0', description: 'At natural waistline' },
      { key: 'hip', label: 'Hip Round', placeholder: '42.0', description: 'Around fullest part of hips/slits start' },
      { key: 'slitPoint', label: 'Side Slit Opening Point', placeholder: '21.0', description: 'Shoulder down to start of side slit' },
      { key: 'shoulder', label: 'Shoulder Width', placeholder: '15.0', description: 'Across back shoulder to shoulder' },
      { key: 'armhole', label: 'Armhole Round', placeholder: '17.0', description: 'Around armpit' },
      { key: 'sleeveLength', label: 'Sleeve Length', placeholder: '16.0', description: '3/4th, full or short sleeve' },
      { key: 'sleeveRound', label: 'Sleeve Hem Round', placeholder: '10.5', description: 'Circumference at sleeve hem' },
      { key: 'frontNeck', label: 'Front Neck Depth', placeholder: '7.0', description: 'Neckline drop at front' },
      { key: 'bottomLength', label: 'Salwar / Churidar Length', placeholder: '44.0', description: 'Waist to ankle (extra length for gathers/churis)' },
      { key: 'ankleRound', label: 'Ankle / Mori Round', placeholder: '10.0', description: 'Tightness at ankle opening' },
      { key: 'crotchRise', label: 'Crotch / Fork Rise', placeholder: '13.0', description: 'Waistband to crotch bend' }
    ]
  },
  kurta: {
    name: 'Men Kurta / Sherwani',
    fields: [
      { key: 'length', label: 'Kurta Length', placeholder: '42.0', description: 'Collar to bottom hem' },
      { key: 'chest', label: 'Chest Round', placeholder: '40.0', description: 'Chest measurement' },
      { key: 'waist', label: 'Waist Round', placeholder: '36.0', description: 'Waist measurement' },
      { key: 'hip', label: 'Hip Round', placeholder: '42.0', description: 'Hip measurement' },
      { key: 'shoulder', label: 'Shoulder Width', placeholder: '18.0', description: 'Shoulder to shoulder' },
      { key: 'sleeveLength', label: 'Sleeve Length', placeholder: '25.0', description: 'Shoulder to wrist' },
      { key: 'collar', label: 'Mandarin Collar', placeholder: '16.0', description: 'Base of neck' },
      { key: 'slit', label: 'Side Slit Length', placeholder: '18.0', description: 'Side opening' }
    ]
  },
  suit: {
    name: 'Blazer / Two-Piece Suit',
    fields: [
      { key: 'jacketLength', label: 'Jacket Length', placeholder: '30.0', description: 'Base of collar to jacket hem' },
      { key: 'chest', label: 'Chest Round', placeholder: '42.0', description: 'Around chest' },
      { key: 'waist', label: 'Stomach / Waist', placeholder: '38.0', description: 'Midsection' },
      { key: 'shoulder', label: 'Shoulder Width', placeholder: '18.5', description: 'Across back' },
      { key: 'sleeveLength', label: 'Sleeve Length', placeholder: '25.5', description: 'Shoulder point to cuff edge' },
      { key: 'trouserWaist', label: 'Trouser Waist', placeholder: '36.0', description: 'Trouser waistband' },
      { key: 'trouserLength', label: 'Trouser Length', placeholder: '41.0', description: 'Trouser outseam' }
    ]
  },
  custom: {
    name: 'Custom Tailored Garment',
    fields: [
      { key: 'length', label: 'Garment Length', placeholder: '35.0', description: 'Total length of garment' },
      { key: 'chest', label: 'Chest / Bust', placeholder: '38.0', description: 'Chest circumference' },
      { key: 'waist', label: 'Waist', placeholder: '32.0', description: 'Waist circumference' },
      { key: 'shoulder', label: 'Shoulder', placeholder: '16.0', description: 'Shoulder width' },
      { key: 'sleeve', label: 'Sleeve Length', placeholder: '15.0', description: 'Sleeve measurement' },
      { key: 'customNotes', label: 'Special Fitting Notes', placeholder: 'Pleats, gathers, lining style', description: 'Any custom notes or alterations' }
    ]
  }
};
