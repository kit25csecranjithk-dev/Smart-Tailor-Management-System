import React, { useState, useEffect } from 'react';
import { InventoryCategory, InventoryItem } from '../../types';
import { Modal } from '../common/Modal';

interface InventoryModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (item: Omit<InventoryItem, 'id' | 'lastUpdated'> & { id?: string }) => void;
  item?: InventoryItem | null;
}

export const InventoryModal: React.FC<InventoryModalProps> = ({
  isOpen,
  onClose,
  onSave,
  item
}) => {
  const [name, setName] = useState('');
  const [category, setCategory] = useState<InventoryCategory>('thread');
  const [color, setColor] = useState('');
  const [quantity, setQuantity] = useState<number>(10);
  const [unit, setUnit] = useState<InventoryItem['unit']>('meters');
  const [minThreshold, setMinThreshold] = useState<number>(5);
  const [costPerUnit, setCostPerUnit] = useState<number>(50);
  const [supplier, setSupplier] = useState('');
  const [errors, setErrors] = useState<Record<string, string>>({});

  useEffect(() => {
    if (item) {
      setName(item.name);
      setCategory(item.category);
      setColor(item.color || '');
      setQuantity(item.quantity);
      setUnit(item.unit);
      setMinThreshold(item.minThreshold);
      setCostPerUnit(item.costPerUnit);
      setSupplier(item.supplier || '');
    } else {
      setName('');
      setCategory('thread');
      setColor('');
      setQuantity(10);
      setUnit('spools');
      setMinThreshold(5);
      setCostPerUnit(40);
      setSupplier('');
    }
    setErrors({});
  }, [item, isOpen]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const newErrors: Record<string, string> = {};

    if (!name.trim()) newErrors.name = 'Material / item name is required';
    if (quantity < 0) newErrors.quantity = 'Quantity cannot be negative';

    if (Object.keys(newErrors).length > 0) {
      setErrors(newErrors);
      return;
    }

    onSave({
      id: item?.id,
      name: name.trim(),
      category,
      color: color.trim() || undefined,
      quantity: Number(quantity) || 0,
      unit,
      minThreshold: Number(minThreshold) || 5,
      costPerUnit: Number(costPerUnit) || 0,
      supplier: supplier.trim() || undefined
    });
    onClose();
  };

  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      title={item ? 'Edit Inventory Item' : 'Add Material / Trim to Stock'}
      subtitle="Track fabric bolts, threads, buttons, zippers, linings and trims"
      maxWidth="md"
    >
      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <label className="block text-xs font-semibold text-stone-700 mb-1">
            Material / Item Name <span className="text-red-500">*</span>
          </label>
          <input
            type="text"
            value={name}
            onChange={(e) => setName(e.target.value)}
            placeholder="e.g. Coats Spun Polyester Thread, YKK Concealed Zipper"
            className="w-full px-3 py-2 text-xs bg-white border border-[#D5C9B3] rounded-lg focus:outline-none focus:ring-2 focus:ring-[#C85A32]/30 focus:border-[#C85A32]"
          />
          {errors.name && <p className="text-[11px] text-red-600 mt-1">{errors.name}</p>}
        </div>

        <div className="grid grid-cols-2 gap-3">
          <div>
            <label className="block text-xs font-semibold text-stone-700 mb-1">
              Category
            </label>
            <select
              value={category}
              onChange={(e) => setCategory(e.target.value as InventoryCategory)}
              className="w-full px-3 py-2 text-xs bg-white border border-[#D5C9B3] rounded-lg"
            >
              <option value="fabric">Fabric / Cloth Bolt</option>
              <option value="thread">Sewing / Embroidery Thread</option>
              <option value="button">Buttons & Hooks</option>
              <option value="zipper">Zippers & Sliders</option>
              <option value="lining">Voile / Cotton Lining</option>
              <option value="accessory">Laces, Pads & Latkans</option>
            </select>
          </div>

          <div>
            <label className="block text-xs font-semibold text-stone-700 mb-1">
              Color / Shade Specification
            </label>
            <input
              type="text"
              value={color}
              onChange={(e) => setColor(e.target.value)}
              placeholder="e.g. Crimson Red #102, Antique Gold"
              className="w-full px-3 py-2 text-xs bg-white border border-[#D5C9B3] rounded-lg"
            />
          </div>
        </div>

        <div className="grid grid-cols-2 gap-3">
          <div>
            <label className="block text-xs font-semibold text-stone-700 mb-1">
              Initial Quantity in Stock
            </label>
            <input
              type="number"
              min="0"
              value={quantity}
              onChange={(e) => setQuantity(parseFloat(e.target.value) || 0)}
              className="w-full px-3 py-2 text-xs bg-white border border-[#D5C9B3] rounded-lg font-mono-data"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-stone-700 mb-1">
              Stock Unit
            </label>
            <select
              value={unit}
              onChange={(e) => setUnit(e.target.value as any)}
              className="w-full px-3 py-2 text-xs bg-white border border-[#D5C9B3] rounded-lg"
            >
              <option value="meters">Meters</option>
              <option value="spools">Spools</option>
              <option value="pieces">Pieces</option>
              <option value="packets">Packets</option>
              <option value="rolls">Rolls</option>
            </select>
          </div>
        </div>

        <div className="grid grid-cols-2 gap-3">
          <div>
            <label className="block text-xs font-semibold text-stone-700 mb-1">
              Low Stock Alert Threshold
            </label>
            <input
              type="number"
              min="1"
              value={minThreshold}
              onChange={(e) => setMinThreshold(parseFloat(e.target.value) || 1)}
              className="w-full px-3 py-2 text-xs bg-white border border-[#D5C9B3] rounded-lg font-mono-data"
            />
            <p className="text-[10px] text-stone-400 mt-0.5">Triggers warning when stock drops below this</p>
          </div>

          <div>
            <label className="block text-xs font-semibold text-stone-700 mb-1">
              Purchase Cost Per Unit (₹)
            </label>
            <input
              type="number"
              min="0"
              value={costPerUnit}
              onChange={(e) => setCostPerUnit(parseFloat(e.target.value) || 0)}
              className="w-full px-3 py-2 text-xs bg-white border border-[#D5C9B3] rounded-lg font-mono-data"
            />
          </div>
        </div>

        <div>
          <label className="block text-xs font-semibold text-stone-700 mb-1">
            Supplier / Vendor Info
          </label>
          <input
            type="text"
            value={supplier}
            onChange={(e) => setSupplier(e.target.value)}
            placeholder="e.g. Coats Distributor, Surat Zari Bazaar"
            className="w-full px-3 py-2 text-xs bg-white border border-[#D5C9B3] rounded-lg"
          />
        </div>

        <div className="flex justify-end gap-3 pt-3 border-t border-[#E8DEC8]">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 text-xs font-semibold text-stone-700 bg-white border border-[#D5C9B3] rounded-lg hover:bg-stone-50"
          >
            Cancel
          </button>
          <button
            type="submit"
            className="px-4 py-2 text-xs font-semibold text-white bg-[#C85A32] hover:bg-[#B34D29] rounded-lg shadow-sm"
          >
            {item ? 'Update Material' : 'Save Item'}
          </button>
        </div>
      </form>
    </Modal>
  );
};
