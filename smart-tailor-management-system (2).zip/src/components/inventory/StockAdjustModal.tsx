import React, { useState, useEffect } from 'react';
import { InventoryItem } from '../../types';
import { Modal } from '../common/Modal';
import { Plus, Minus } from 'lucide-react';

interface StockAdjustModalProps {
  isOpen: boolean;
  onClose: () => void;
  item: InventoryItem | null;
  onAdjust: (itemId: string, delta: number) => void;
}

export const StockAdjustModal: React.FC<StockAdjustModalProps> = ({
  isOpen,
  onClose,
  item,
  onAdjust
}) => {
  const [mode, setMode] = useState<'add' | 'remove'>('add');
  const [amount, setAmount] = useState<number>(5);
  const [reason, setReason] = useState('');

  useEffect(() => {
    setAmount(5);
    setMode('add');
    setReason('');
  }, [item, isOpen]);

  if (!item) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!amount || amount <= 0) return;
    const delta = mode === 'add' ? amount : -amount;
    onAdjust(item.id, delta);
    onClose();
  };

  const resultingStock = mode === 'add' ? item.quantity + amount : Math.max(0, item.quantity - amount);

  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      title="Adjust Material Stock Level"
      subtitle={`${item.name} (${item.unit})`}
      maxWidth="sm"
    >
      <form onSubmit={handleSubmit} className="space-y-4">
        {/* Current status */}
        <div className="p-3 bg-[#FAF6EE] rounded-lg border border-[#E8DEC8] flex items-center justify-between text-xs">
          <span className="text-stone-500">Current Stock:</span>
          <span className="font-mono-data font-bold text-stone-900 text-sm">
            {item.quantity} {item.unit}
          </span>
        </div>

        {/* Action Type */}
        <div className="grid grid-cols-2 gap-2 p-1 bg-[#EAE3D2] rounded-lg border border-[#D5C9B3]">
          <button
            type="button"
            onClick={() => setMode('add')}
            className={`py-2 text-xs font-semibold rounded-md flex items-center justify-center gap-1.5 transition-colors ${
              mode === 'add' ? 'bg-white text-emerald-800 shadow-xs' : 'text-stone-600 hover:text-stone-900'
            }`}
          >
            <Plus className="w-3.5 h-3.5 text-emerald-600" />
            <span>Restock (+)</span>
          </button>
          <button
            type="button"
            onClick={() => setMode('remove')}
            className={`py-2 text-xs font-semibold rounded-md flex items-center justify-center gap-1.5 transition-colors ${
              mode === 'remove' ? 'bg-white text-red-800 shadow-xs' : 'text-stone-600 hover:text-stone-900'
            }`}
          >
            <Minus className="w-3.5 h-3.5 text-red-600" />
            <span>Consume / Deduct (-)</span>
          </button>
        </div>

        <div>
          <label className="block text-xs font-semibold text-stone-700 mb-1">
            Quantity ({item.unit})
          </label>
          <input
            type="number"
            min="1"
            value={amount}
            onChange={(e) => setAmount(parseFloat(e.target.value) || 0)}
            className="w-full px-3 py-2 text-sm font-bold font-mono-data bg-white border border-[#D5C9B3] rounded-lg focus:outline-none focus:ring-2 focus:ring-[#C85A32]/30 focus:border-[#C85A32]"
          />
        </div>

        <div>
          <label className="block text-xs font-semibold text-stone-700 mb-1">
            Reason / Job Reference
          </label>
          <input
            type="text"
            value={reason}
            onChange={(e) => setReason(e.target.value)}
            placeholder={mode === 'add' ? 'New shipment from vendor' : 'Used for bridal blouse order'}
            className="w-full px-3 py-2 text-xs bg-white border border-[#D5C9B3] rounded-lg"
          />
        </div>

        {/* Projected preview */}
        <div className="p-2.5 rounded-lg bg-stone-50 border border-stone-200 text-[11px] text-stone-600 flex justify-between items-center">
          <span>Projected New Stock:</span>
          <span className="font-mono-data font-bold text-stone-900">
            {resultingStock} {item.unit}
          </span>
        </div>

        <div className="flex justify-end gap-3 pt-3 border-t border-[#E8DEC8]">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 text-xs font-semibold text-stone-700 bg-white border border-[#D5C9B3] rounded-lg hover:bg-stone-50"
          >
            Cancel
          </button>
          <button
            type="submit"
            className="px-4 py-2 text-xs font-semibold text-white bg-[#C85A32] hover:bg-[#B34D29] rounded-lg shadow-sm"
          >
            Save Stock Adjustment
          </button>
        </div>
      </form>
    </Modal>
  );
};
