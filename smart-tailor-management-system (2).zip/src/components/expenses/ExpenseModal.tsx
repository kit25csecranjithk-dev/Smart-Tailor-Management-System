import React, { useState, useEffect } from 'react';
import { ExpenseCategory, ExpenseRecord } from '../../types';
import { Modal } from '../common/Modal';

interface ExpenseModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (expense: Omit<ExpenseRecord, 'id'> & { id?: string }) => void;
  expense?: ExpenseRecord | null;
}

export const ExpenseModal: React.FC<ExpenseModalProps> = ({
  isOpen,
  onClose,
  onSave,
  expense
}) => {
  const [category, setCategory] = useState<ExpenseCategory>('tailor_wages');
  const [description, setDescription] = useState('');
  const [amount, setAmount] = useState<number>(1000);
  const [date, setDate] = useState(new Date().toISOString().split('T')[0]);
  const [paidTo, setPaidTo] = useState('');
  const [errors, setErrors] = useState<Record<string, string>>({});

  useEffect(() => {
    if (expense) {
      setCategory(expense.category);
      setDescription(expense.description);
      setAmount(expense.amount);
      setDate(expense.date);
      setPaidTo(expense.paidTo || '');
    } else {
      setCategory('tailor_wages');
      setDescription('');
      setAmount(1000);
      setDate(new Date().toISOString().split('T')[0]);
      setPaidTo('');
    }
    setErrors({});
  }, [expense, isOpen]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const newErrors: Record<string, string> = {};

    if (!description.trim()) newErrors.description = 'Please enter an expense description';
    if (!amount || amount <= 0) newErrors.amount = 'Please enter a valid expense amount';

    if (Object.keys(newErrors).length > 0) {
      setErrors(newErrors);
      return;
    }

    onSave({
      id: expense?.id,
      category,
      description: description.trim(),
      amount: Number(amount),
      date,
      paidTo: paidTo.trim() || undefined
    });
    onClose();
  };

  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      title={expense ? 'Edit Expense Record' : 'Record Shop Expense'}
      subtitle="Track monthly rent, tailor wages, utilities, materials and maintenance"
      maxWidth="md"
    >
      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <label className="block text-xs font-semibold text-stone-700 mb-1">
            Expense Category
          </label>
          <select
            value={category}
            onChange={(e) => setCategory(e.target.value as ExpenseCategory)}
            className="w-full px-3 py-2 text-xs bg-white border border-[#D5C9B3] rounded-lg"
          >
            <option value="tailor_wages">Tailor Wages & Piece-rate Pay</option>
            <option value="rent">Shop Monthly Rent</option>
            <option value="electricity">Electricity / Utility Bill</option>
            <option value="threads_materials">Threads, Needles & Chalk</option>
            <option value="machinery_maintenance">Sewing Machine Service & Oil</option>
            <option value="tea_snacks">Tea & Daily Refreshments</option>
            <option value="other">Miscellaneous Shop Expense</option>
          </select>
        </div>

        <div>
          <label className="block text-xs font-semibold text-stone-700 mb-1">
            Description <span className="text-red-500">*</span>
          </label>
          <input
            type="text"
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            placeholder="e.g. Master Murugan 10 blouse piece-rate payment, Juki machine oiling"
            className="w-full px-3 py-2 text-xs bg-white border border-[#D5C9B3] rounded-lg focus:outline-none focus:ring-2 focus:ring-[#C85A32]/30 focus:border-[#C85A32]"
          />
          {errors.description && <p className="text-[11px] text-red-600 mt-1">{errors.description}</p>}
        </div>

        <div className="grid grid-cols-2 gap-3">
          <div>
            <label className="block text-xs font-semibold text-stone-700 mb-1">
              Amount Paid (₹) <span className="text-red-500">*</span>
            </label>
            <input
              type="number"
              min="1"
              value={amount}
              onChange={(e) => setAmount(parseFloat(e.target.value) || 0)}
              className="w-full px-3 py-2 text-xs font-mono-data font-bold bg-white border border-[#D5C9B3] rounded-lg"
            />
            {errors.amount && <p className="text-[11px] text-red-600 mt-1">{errors.amount}</p>}
          </div>

          <div>
            <label className="block text-xs font-semibold text-stone-700 mb-1">
              Expense Date
            </label>
            <input
              type="date"
              value={date}
              onChange={(e) => setDate(e.target.value)}
              className="w-full px-3 py-2 text-xs bg-white border border-[#D5C9B3] rounded-lg font-mono-data"
            />
          </div>
        </div>

        <div>
          <label className="block text-xs font-semibold text-stone-700 mb-1">
            Paid To / Vendor Name
          </label>
          <input
            type="text"
            value={paidTo}
            onChange={(e) => setPaidTo(e.target.value)}
            placeholder="e.g. Landlord Mr. Krishna, Sree Machine Works"
            className="w-full px-3 py-2 text-xs bg-white border border-[#D5C9B3] rounded-lg"
          />
        </div>

        <div className="flex justify-end gap-3 pt-3 border-t border-[#E8DEC8]">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 text-xs font-semibold text-stone-700 bg-white border border-[#D5C9B3] rounded-lg hover:bg-stone-50"
          >
            Cancel
          </button>
          <button
            type="submit"
            className="px-4 py-2 text-xs font-semibold text-white bg-[#C85A32] hover:bg-[#B34D29] rounded-lg shadow-sm"
          >
            {expense ? 'Update Expense' : 'Save Expense'}
          </button>
        </div>
      </form>
    </Modal>
  );
};
