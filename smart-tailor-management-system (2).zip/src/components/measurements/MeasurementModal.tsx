import React, { useState, useEffect } from 'react';
import { Customer, GarmentType, MeasurementRecord, MeasurementUnit } from '../../types';
import { MEASUREMENT_TEMPLATES } from '../../utils/measurementTemplates';
import { Modal } from '../common/Modal';
import { Info, HelpCircle } from 'lucide-react';

interface MeasurementModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (record: Omit<MeasurementRecord, 'id' | 'recordedDate'> & { id?: string; recordedDate?: string }) => void;
  customers: Customer[];
  measurement?: MeasurementRecord | null;
  preselectedCustomerId?: string;
  defaultUnit?: MeasurementUnit;
}

export const MeasurementModal: React.FC<MeasurementModalProps> = ({
  isOpen,
  onClose,
  onSave,
  customers,
  measurement,
  preselectedCustomerId,
  defaultUnit = 'inches'
}) => {
  const [customerId, setCustomerId] = useState('');
  const [garmentType, setGarmentType] = useState<GarmentType>('blouse');
  const [title, setTitle] = useState('');
  const [unit, setUnit] = useState<MeasurementUnit>(defaultUnit);
  const [values, setValues] = useState<Record<string, string>>({});
  const [notes, setNotes] = useState('');
  const [activeHint, setActiveHint] = useState<string | null>(null);
  const [errors, setErrors] = useState<Record<string, string>>({});

  useEffect(() => {
    if (measurement) {
      setCustomerId(measurement.customerId);
      setGarmentType(measurement.garmentType);
      setTitle(measurement.title);
      setUnit(measurement.unit);
      const strVals: Record<string, string> = {};
      Object.entries(measurement.values).forEach(([k, v]) => {
        strVals[k] = String(v);
      });
      setValues(strVals);
      setNotes(measurement.notes || '');
    } else {
      setCustomerId(preselectedCustomerId || (customers[0]?.id || ''));
      setGarmentType('blouse');
      setTitle('Standard Saree Blouse');
      setUnit(defaultUnit);
      setValues({});
      setNotes('');
    }
    setErrors({});
    setActiveHint(null);
  }, [measurement, preselectedCustomerId, isOpen, defaultUnit, customers]);

  // When garmentType changes on fresh create, update default title
  const handleGarmentTypeChange = (newType: GarmentType) => {
    setGarmentType(newType);
    if (!measurement) {
      const template = MEASUREMENT_TEMPLATES[newType];
      setTitle(`${template?.name || 'Custom'} Measurement`);
    }
  };

  const handleFieldChange = (key: string, val: string) => {
    setValues((prev) => ({
      ...prev,
      [key]: val
    }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const newErrors: Record<string, string> = {};

    if (!customerId) newErrors.customerId = 'Please select a customer';
    if (!title.trim()) newErrors.title = 'Please enter a measurement label';

    if (Object.keys(newErrors).length > 0) {
      setErrors(newErrors);
      return;
    }

    const selectedCust = customers.find((c) => c.id === customerId);

    onSave({
      id: measurement?.id,
      customerId,
      customerName: selectedCust ? selectedCust.name : 'Customer',
      garmentType,
      title: title.trim(),
      unit,
      values,
      notes: notes.trim() || undefined,
      recordedDate: measurement?.recordedDate || new Date().toISOString().split('T')[0]
    });
    onClose();
  };

  const currentTemplate = MEASUREMENT_TEMPLATES[garmentType] || MEASUREMENT_TEMPLATES.blouse;

  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      title={measurement ? 'Edit Measurement Record' : 'Record New Measurements'}
      subtitle="Precision tailor specifications with body anatomical points"
      maxWidth="2xl"
    >
      <form onSubmit={handleSubmit} className="space-y-4">
        {/* Customer & Garment Selector */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
          <div>
            <label className="block text-xs font-semibold text-stone-700 mb-1">
              Customer <span className="text-red-500">*</span>
            </label>
            <select
              value={customerId}
              onChange={(e) => setCustomerId(e.target.value)}
              className="w-full px-3 py-2 text-xs bg-white border border-[#D5C9B3] rounded-lg focus:outline-none focus:ring-2 focus:ring-[#C85A32]/30 focus:border-[#C85A32]"
            >
              <option value="">-- Select Customer --</option>
              {customers.map((c) => (
                <option key={c.id} value={c.id}>
                  {c.name} ({c.phone})
                </option>
              ))}
            </select>
            {errors.customerId && <p className="text-[11px] text-red-600 mt-1">{errors.customerId}</p>}
          </div>

          <div>
            <label className="block text-xs font-semibold text-stone-700 mb-1">
              Garment Silhouette <span className="text-red-500">*</span>
            </label>
            <select
              value={garmentType}
              onChange={(e) => handleGarmentTypeChange(e.target.value as GarmentType)}
              className="w-full px-3 py-2 text-xs bg-white border border-[#D5C9B3] rounded-lg focus:outline-none focus:ring-2 focus:ring-[#C85A32]/30 focus:border-[#C85A32]"
            >
              <option value="blouse">Saree Blouse</option>
              <option value="shirt">Formal / Casual Shirt</option>
              <option value="pants">Trousers / Pants</option>
              <option value="churidar">Churidar / Salwar Kameez</option>
              <option value="kurta">Men Kurta / Sherwani</option>
              <option value="suit">Blazer / 2-Piece Suit</option>
              <option value="custom">Custom Pattern</option>
            </select>
          </div>

          <div>
            <label className="block text-xs font-semibold text-stone-700 mb-1">
              Measurement Unit
            </label>
            <div className="grid grid-cols-2 gap-1 p-0.5 bg-[#EAE3D2] rounded-lg border border-[#D5C9B3]">
              <button
                type="button"
                onClick={() => setUnit('inches')}
                className={`py-1.5 text-xs font-semibold rounded-md transition-colors ${
                  unit === 'inches' ? 'bg-white text-[#1B2A4A] shadow-xs' : 'text-stone-600 hover:text-stone-900'
                }`}
              >
                Inches (in)
              </button>
              <button
                type="button"
                onClick={() => setUnit('cm')}
                className={`py-1.5 text-xs font-semibold rounded-md transition-colors ${
                  unit === 'cm' ? 'bg-white text-[#1B2A4A] shadow-xs' : 'text-stone-600 hover:text-stone-900'
                }`}
              >
                Centimeter (cm)
              </button>
            </div>
          </div>
        </div>

        <div>
          <label className="block text-xs font-semibold text-stone-700 mb-1">
            Measurement Card Label <span className="text-red-500">*</span>
          </label>
          <input
            type="text"
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            placeholder="e.g. Wedding Silk Blouse (Padded), Office Formal Shirts"
            className="w-full px-3 py-2 text-xs bg-white border border-[#D5C9B3] rounded-lg focus:outline-none focus:ring-2 focus:ring-[#C85A32]/30 focus:border-[#C85A32]"
          />
          {errors.title && <p className="text-[11px] text-red-600 mt-1">{errors.title}</p>}
        </div>

        {/* Anatomical Measurement Grid */}
        <div className="bg-[#FAF6EE] p-4 rounded-xl border border-[#E8DEC8]">
          <div className="flex items-center justify-between mb-3">
            <h4 className="text-xs font-bold text-[#1B2A4A] uppercase tracking-wider flex items-center gap-1.5">
              <span>{currentTemplate.name} Specifications</span>
              <span className="text-[11px] font-normal text-stone-500 lowercase">({unit})</span>
            </h4>
            <span className="text-[11px] text-stone-500">
              Hover/tap labels for tailor tape placement instructions
            </span>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-3">
            {currentTemplate.fields.map((field) => (
              <div key={field.key} className="relative">
                <div className="flex items-center justify-between mb-1">
                  <label
                    htmlFor={`field-${field.key}`}
                    className="text-[11px] font-medium text-stone-700 truncate cursor-pointer hover:text-[#C85A32]"
                    title={field.description}
                    onClick={() => setActiveHint(activeHint === field.key ? null : field.key)}
                  >
                    {field.label}
                  </label>
                  <button
                    type="button"
                    onClick={() => setActiveHint(activeHint === field.key ? null : field.key)}
                    className="text-stone-400 hover:text-stone-700 ml-1"
                    title={field.description}
                  >
                    <HelpCircle className="w-3 h-3" />
                  </button>
                </div>
                <input
                  id={`field-${field.key}`}
                  type="text"
                  value={values[field.key] || ''}
                  onChange={(e) => handleFieldChange(field.key, e.target.value)}
                  placeholder={field.placeholder}
                  className="w-full px-2.5 py-1.5 text-xs font-mono-data bg-white border border-[#D5C9B3] rounded-md focus:outline-none focus:ring-2 focus:ring-[#C85A32]/30 focus:border-[#C85A32]"
                />
                {activeHint === field.key && (
                  <div className="absolute z-20 left-0 right-0 top-full mt-1 p-2 bg-[#1B2A4A] text-white text-[10px] rounded shadow-lg border border-slate-700 leading-tight">
                    {field.description}
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>

        {/* Special Fitting Notes */}
        <div>
          <label className="block text-xs font-semibold text-stone-700 mb-1">
            Fit, Dart & Alteration Notes
          </label>
          <textarea
            rows={2}
            value={notes}
            onChange={(e) => setNotes(e.target.value)}
            placeholder="e.g. Princess cut, 4 tucks, deep sweetheart neck, double stitched side seams with 2 inch margin for future expansion"
            className="w-full px-3 py-2 text-xs bg-white border border-[#D5C9B3] rounded-lg focus:outline-none focus:ring-2 focus:ring-[#C85A32]/30 focus:border-[#C85A32]"
          />
        </div>

        {/* Action Buttons */}
        <div className="flex justify-end gap-3 pt-3 border-t border-[#E8DEC8]">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 text-xs font-semibold text-stone-700 bg-white border border-[#D5C9B3] rounded-lg hover:bg-stone-50"
          >
            Cancel
          </button>
          <button
            type="submit"
            className="px-4 py-2 text-xs font-semibold text-white bg-[#C85A32] hover:bg-[#B34D29] rounded-lg shadow-sm"
          >
            {measurement ? 'Update Measurement' : 'Save Measurement Record'}
          </button>
        </div>
      </form>
    </Modal>
  );
};
