import React from 'react';
import { Menu, Plus, Bell, Calendar, Search } from 'lucide-react';
import { ActiveTab } from './Sidebar';

interface HeaderProps {
  activeTab: ActiveTab;
  onOpenMobileMenu: () => void;
  onNewOrder: () => void;
  onNewCustomer: () => void;
  overdueOrdersCount: number;
  lowStockCount: number;
}

export const Header: React.FC<HeaderProps> = ({
  activeTab,
  onOpenMobileMenu,
  onNewOrder,
  onNewCustomer,
  overdueOrdersCount,
  lowStockCount
}) => {
  const titles: Record<ActiveTab, { title: string; subtitle: string }> = {
    dashboard: { title: 'Tailor Studio Overview', subtitle: 'Real-time orders, metrics & delivery queue' },
    customers: { title: 'Customer Directory', subtitle: 'Client records, contacts & measurement profiles' },
    measurements: { title: 'Measurement Records', subtitle: 'Blouse, shirt, pants & suit body specifications' },
    orders: { title: 'Stitching Orders', subtitle: 'Bespoke tailoring work orders, fabrics & balances' },
    tracking: { title: 'Order Production Pipeline', subtitle: 'Stage-by-stage garment progress from cutting to delivery' },
    billing: { title: 'Billing & Invoices', subtitle: 'Payment logs, receipts & printable customer invoices' },
    inventory: { title: 'Material & Trim Inventory', subtitle: 'Fabrics, threads, zippers, buttons & stock levels' },
    deliveries: { title: 'Delivery & Trial Schedule', subtitle: 'Upcoming deliveries, trials and urgent timelines' },
    reports: { title: 'Business Reports & P&L', subtitle: 'Revenue, shop expenses, profit & category breakdowns' },
    settings: { title: 'Shop Profile & Settings', subtitle: 'Business info, GSTIN, default units & database backups' }
  };

  const current = titles[activeTab] || { title: 'Smart Tailor', subtitle: 'Tailor Shop Management' };
  const todayFormatted = new Date().toLocaleDateString('en-IN', {
    weekday: 'short',
    day: 'numeric',
    month: 'short',
    year: 'numeric'
  });

  return (
    <header className="sticky top-0 z-30 bg-[#FAF8F5]/90 backdrop-blur-md border-b border-[#E8DEC8] px-4 lg:px-8 py-3.5">
      <div className="flex items-center justify-between gap-4">
        {/* Left: Hamburger & Breadcrumb */}
        <div className="flex items-center gap-3 min-w-0">
          <button
            onClick={onOpenMobileMenu}
            className="p-2 -ml-2 text-stone-700 hover:text-stone-900 rounded-lg hover:bg-stone-200/50 lg:hidden shrink-0"
            aria-label="Open navigation menu"
          >
            <Menu className="w-5 h-5" />
          </button>

          <div className="min-w-0">
            <h2 className="text-base lg:text-lg font-bold text-[#1B2A4A] tracking-tight truncate">
              {current.title}
            </h2>
            <p className="text-xs text-stone-500 hidden sm:block truncate">
              {current.subtitle}
            </p>
          </div>
        </div>

        {/* Center/Right: Date & Alerts */}
        <div className="hidden md:flex items-center gap-4 text-xs text-stone-600">
          <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-[#F0ECE1] border border-[#E0D5C1]">
            <Calendar className="w-3.5 h-3.5 text-stone-500" />
            <span className="font-mono-data font-medium">{todayFormatted}</span>
          </div>

          {(overdueOrdersCount > 0 || lowStockCount > 0) && (
            <div className="flex items-center gap-2">
              {overdueOrdersCount > 0 && (
                <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-md text-xs font-semibold bg-red-50 text-red-700 border border-red-200">
                  <span className="w-1.5 h-1.5 rounded-full bg-red-500" />
                  {overdueOrdersCount} Overdue
                </span>
              )}
              {lowStockCount > 0 && (
                <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-md text-xs font-semibold bg-amber-50 text-amber-700 border border-amber-200">
                  <span className="w-1.5 h-1.5 rounded-full bg-amber-500" />
                  {lowStockCount} Low Stock
                </span>
              )}
            </div>
          )}
        </div>

        {/* Right: Quick Action Buttons */}
        <div className="flex items-center gap-2 shrink-0">
          <button
            onClick={onNewCustomer}
            className="hidden sm:inline-flex items-center gap-1.5 px-3 py-2 text-xs font-semibold text-[#1B2A4A] bg-[#EAE3D2] hover:bg-[#DDD4BF] rounded-lg transition-colors border border-[#D5C9B3]"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>New Customer</span>
          </button>
          
          <button
            onClick={onNewOrder}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-white bg-[#C85A32] hover:bg-[#B34D29] rounded-lg shadow-sm transition-colors whitespace-nowrap"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>New Order</span>
          </button>
        </div>
      </div>
    </header>
  );
};
