import React from 'react';
import {
  LayoutDashboard,
  Users,
  Ruler,
  ShoppingBag,
  Columns3,
  Receipt,
  Boxes,
  CalendarDays,
  BarChart3,
  Settings,
  Scissors,
  LogOut,
  X,
  AlertCircle
} from 'lucide-react';
import { User } from '../../types';

export type ActiveTab =
  | 'dashboard'
  | 'customers'
  | 'measurements'
  | 'orders'
  | 'tracking'
  | 'billing'
  | 'inventory'
  | 'deliveries'
  | 'reports'
  | 'settings';

interface SidebarProps {
  activeTab: ActiveTab;
  setActiveTab: (tab: ActiveTab) => void;
  isOpen: boolean;
  onClose: () => void;
  currentUser: User;
  onLogout: () => void;
  pendingOrdersCount: number;
  lowStockCount: number;
  overdueOrdersCount: number;
}

export const Sidebar: React.FC<SidebarProps> = ({
  activeTab,
  setActiveTab,
  isOpen,
  onClose,
  currentUser,
  onLogout,
  pendingOrdersCount,
  lowStockCount,
  overdueOrdersCount
}) => {
  const navItems = [
    {
      id: 'dashboard' as ActiveTab,
      label: 'Dashboard',
      icon: LayoutDashboard,
      badge: overdueOrdersCount > 0 ? `${overdueOrdersCount} overdue` : undefined,
      badgeType: 'danger'
    },
    {
      id: 'customers' as ActiveTab,
      label: 'Customers',
      icon: Users
    },
    {
      id: 'measurements' as ActiveTab,
      label: 'Measurements',
      icon: Ruler
    },
    {
      id: 'orders' as ActiveTab,
      label: 'Stitching Orders',
      icon: ShoppingBag,
      badge: pendingOrdersCount > 0 ? `${pendingOrdersCount}` : undefined
    },
    {
      id: 'tracking' as ActiveTab,
      label: 'Order Pipeline',
      icon: Columns3
    },
    {
      id: 'billing' as ActiveTab,
      label: 'Billing & Invoices',
      icon: Receipt
    },
    {
      id: 'deliveries' as ActiveTab,
      label: 'Delivery Schedule',
      icon: CalendarDays,
      badge: overdueOrdersCount > 0 ? 'Alert' : undefined,
      badgeType: 'danger'
    },
    {
      id: 'inventory' as ActiveTab,
      label: 'Material Inventory',
      icon: Boxes,
      badge: lowStockCount > 0 ? `${lowStockCount} low` : undefined,
      badgeType: 'warning'
    },
    {
      id: 'reports' as ActiveTab,
      label: 'Reports & Expenses',
      icon: BarChart3
    },
    {
      id: 'settings' as ActiveTab,
      label: 'Shop Settings',
      icon: Settings
    }
  ];

  return (
    <>
      {/* Mobile Backdrop */}
      {isOpen && (
        <div
          className="fixed inset-0 z-40 bg-black/40 lg:hidden backdrop-blur-xs"
          onClick={onClose}
          aria-hidden="true"
        />
      )}

      {/* Sidebar Panel */}
      <aside
        className={`fixed top-0 bottom-0 left-0 z-40 w-64 bg-[#1B2A4A] text-stone-200 flex flex-col transition-transform duration-200 ease-in-out border-r border-[#2C3E63] ${
          isOpen ? 'translate-x-0' : '-translate-x-full lg:translate-x-0'
        }`}
      >
        {/* Brand Header */}
        <div className="flex items-center justify-between px-5 py-5 border-b border-[#2C3E63] bg-[#142038]">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-lg bg-[#C85A32] flex items-center justify-center text-white shadow-sm shrink-0">
              <Scissors className="w-5 h-5" />
            </div>
            <div>
              <h1 className="text-base font-bold text-white tracking-tight leading-tight">
                Smart Tailor
              </h1>
              <p className="text-[11px] text-[#A5B4CB] tracking-wide uppercase font-medium">
                Tailor Management
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1 text-stone-400 hover:text-white lg:hidden rounded-lg hover:bg-stone-800"
            aria-label="Close sidebar"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Navigation Links */}
        <nav className="flex-1 px-3 py-4 space-y-1 overflow-y-auto">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = activeTab === item.id;
            return (
              <button
                key={item.id}
                onClick={() => {
                  setActiveTab(item.id);
                  onClose();
                }}
                className={`w-full flex items-center justify-between px-3.5 py-2.5 rounded-lg text-xs font-medium transition-all ${
                  isActive
                    ? 'bg-[#C85A32] text-white shadow-sm font-semibold'
                    : 'text-[#D0D7E2] hover:bg-[#25375A] hover:text-white'
                }`}
              >
                <div className="flex items-center gap-3 truncate">
                  <Icon className={`w-4 h-4 shrink-0 ${isActive ? 'text-white' : 'text-[#8DA0BF]'}`} />
                  <span className="truncate">{item.label}</span>
                </div>
                {item.badge && (
                  <span
                    className={`ml-2 px-1.5 py-0.5 rounded text-[10px] font-semibold tracking-wide uppercase shrink-0 ${
                      isActive
                        ? 'bg-white/20 text-white'
                        : item.badgeType === 'danger'
                        ? 'bg-red-500/20 text-red-300'
                        : item.badgeType === 'warning'
                        ? 'bg-amber-500/20 text-amber-300'
                        : 'bg-[#2D436D] text-[#BACAE3]'
                    }`}
                  >
                    {item.badge}
                  </span>
                )}
              </button>
            );
          })}
        </nav>

        {/* User Profile & Logout Footer */}
        <div className="p-3 border-t border-[#2C3E63] bg-[#142038]">
          <div className="flex items-center justify-between p-2 rounded-lg bg-[#1B2A4A]/60">
            <div className="flex items-center gap-2.5 min-w-0">
              <div className="w-8 h-8 rounded-full bg-[#3B507A] text-[#FAF8F5] flex items-center justify-center text-xs font-bold uppercase shrink-0">
                {currentUser.name.charAt(0)}
              </div>
              <div className="min-w-0">
                <p className="text-xs font-semibold text-white truncate">
                  {currentUser.name}
                </p>
                <p className="text-[10px] text-[#8DA0BF] truncate">
                  {currentUser.role}
                </p>
              </div>
            </div>
            <button
              onClick={onLogout}
              title="Logout"
              className="p-1.5 text-[#8DA0BF] hover:text-red-300 hover:bg-red-900/30 rounded-md transition-colors shrink-0"
              aria-label="Logout"
            >
              <LogOut className="w-4 h-4" />
            </button>
          </div>
          <div className="mt-2 text-[10px] text-[#71829D] text-center">
            College COP Project · v1.0 Standalone
          </div>
        </div>
      </aside>
    </>
  );
};
