import React from 'react';
import { Customer, Order, MeasurementRecord } from '../../types';
import { Modal } from '../common/Modal';
import { formatINR, formatDate, getStatusLabel, getStatusColorClasses } from '../../utils/formatters';
import { Phone, Mail, MapPin, Ruler, ShoppingBag, Plus, Calendar, Clock } from 'lucide-react';

interface CustomerDetailDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  customer: Customer | null;
  orders: Order[];
  measurements: MeasurementRecord[];
  onNewOrderForCustomer: (customer: Customer) => void;
  onNewMeasurementForCustomer: (customer: Customer) => void;
  onViewOrder: (order: Order) => void;
}

export const CustomerDetailDrawer: React.FC<CustomerDetailDrawerProps> = ({
  isOpen,
  onClose,
  customer,
  orders,
  measurements,
  onNewOrderForCustomer,
  onNewMeasurementForCustomer,
  onViewOrder
}) => {
  if (!customer) return null;

  const customerOrders = orders.filter((o) => o.customerId === customer.id);
  const customerMeasurements = measurements.filter((m) => m.customerId === customer.id);

  const totalSpent = customerOrders.reduce((sum, o) => sum + (o.charges?.totalAmount || 0), 0);
  const totalBalance = customerOrders.reduce((sum, o) => sum + (o.charges?.balanceAmount || 0), 0);

  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      title={customer.name}
      subtitle={`Customer ID: ${customer.id} · Registered ${formatDate(customer.createdAt)}`}
      maxWidth="2xl"
    >
      <div className="space-y-6">
        {/* Customer Quick Stats & Info */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
          <div className="p-3.5 rounded-lg bg-[#FAF6EE] border border-[#E8DEC8]">
            <p className="text-[11px] font-semibold text-stone-500 uppercase tracking-wide">Total Orders</p>
            <p className="text-xl font-bold text-[#1B2A4A] mt-1 font-mono-data">{customerOrders.length}</p>
          </div>
          <div className="p-3.5 rounded-lg bg-[#FAF6EE] border border-[#E8DEC8]">
            <p className="text-[11px] font-semibold text-stone-500 uppercase tracking-wide">Total Billed</p>
            <p className="text-xl font-bold text-[#1B2A4A] mt-1 font-mono-data">{formatINR(totalSpent)}</p>
          </div>
          <div className="p-3.5 rounded-lg bg-[#FFF7ED] border border-[#FED7AA]">
            <p className="text-[11px] font-semibold text-[#C2410C] uppercase tracking-wide">Pending Balance</p>
            <p className="text-xl font-bold text-[#C85A32] mt-1 font-mono-data">{formatINR(totalBalance)}</p>
          </div>
        </div>

        {/* Contact details */}
        <div className="p-4 rounded-lg bg-white border border-[#E8DEC8] space-y-2 text-xs text-stone-700">
          <div className="flex items-center gap-2">
            <Phone className="w-3.5 h-3.5 text-stone-400 shrink-0" />
            <span className="font-mono-data font-semibold text-stone-900">{customer.phone}</span>
          </div>
          {customer.email && (
            <div className="flex items-center gap-2">
              <Mail className="w-3.5 h-3.5 text-stone-400 shrink-0" />
              <span>{customer.email}</span>
            </div>
          )}
          {customer.address && (
            <div className="flex items-start gap-2">
              <MapPin className="w-3.5 h-3.5 text-stone-400 shrink-0 mt-0.5" />
              <span>{customer.address}</span>
            </div>
          )}
          {customer.notes && (
            <div className="pt-2 mt-2 border-t border-stone-100 text-stone-600">
              <span className="font-semibold text-stone-800">Styling Note: </span>
              {customer.notes}
            </div>
          )}
        </div>

        {/* Quick action strip */}
        <div className="flex items-center justify-between gap-3">
          <h4 className="text-xs font-bold text-[#1B2A4A] uppercase tracking-wider">
            Saved Measurement Cards ({customerMeasurements.length})
          </h4>
          <button
            onClick={() => {
              onNewMeasurementForCustomer(customer);
            }}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-[#1B2A4A] bg-[#EFE9DD] hover:bg-[#E4DBCB] border border-[#D8CEBE] rounded-lg transition-colors"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Add Measurement</span>
          </button>
        </div>

        {/* Measurements List */}
        {customerMeasurements.length === 0 ? (
          <div className="p-4 text-center rounded-lg border border-dashed border-stone-300 text-stone-500 text-xs">
            No measurements recorded yet for {customer.name}. Click "Add Measurement" to record body specifications.
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            {customerMeasurements.map((m) => (
              <div key={m.id} className="p-3 rounded-lg bg-white border border-[#E8DEC8] hover:border-[#C85A32]/40 transition-colors">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-xs font-bold text-[#1B2A4A] capitalize">{m.title}</span>
                  <span className="text-[10px] uppercase font-mono-data px-1.5 py-0.5 bg-stone-100 text-stone-600 rounded">
                    {m.unit}
                  </span>
                </div>
                <div className="grid grid-cols-3 gap-1.5 text-[11px] text-stone-600 mb-2 font-mono-data bg-stone-50 p-2 rounded">
                  {Object.entries(m.values).slice(0, 6).map(([key, val]) => (
                    <div key={key}>
                      <span className="text-stone-400 capitalize">{key}: </span>
                      <span className="font-semibold text-stone-800">{String(val)}</span>
                    </div>
                  ))}
                </div>
                <div className="text-[10px] text-stone-400 flex items-center justify-between">
                  <span>Recorded: {formatDate(m.recordedDate)}</span>
                  <span className="capitalize">{m.garmentType}</span>
                </div>
              </div>
            ))}
          </div>
        )}

        {/* Orders History */}
        <div className="flex items-center justify-between gap-3 pt-3 border-t border-[#E8DEC8]">
          <h4 className="text-xs font-bold text-[#1B2A4A] uppercase tracking-wider">
            Stitching Order History ({customerOrders.length})
          </h4>
          <button
            onClick={() => {
              onNewOrderForCustomer(customer);
            }}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-white bg-[#C85A32] hover:bg-[#B34D29] rounded-lg shadow-sm transition-colors"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Create New Order</span>
          </button>
        </div>

        {customerOrders.length === 0 ? (
          <div className="p-4 text-center rounded-lg border border-dashed border-stone-300 text-stone-500 text-xs">
            No past orders found for this customer.
          </div>
        ) : (
          <div className="space-y-2">
            {customerOrders.map((ord) => {
              const statusStyle = getStatusColorClasses(ord.status);
              return (
                <div
                  key={ord.id}
                  onClick={() => onViewOrder(ord)}
                  className="p-3 rounded-lg bg-white border border-[#E8DEC8] hover:border-stone-400 flex items-center justify-between gap-3 cursor-pointer transition-colors"
                >
                  <div className="min-w-0">
                    <div className="flex items-center gap-2">
                      <span className="font-mono-data font-bold text-xs text-[#1B2A4A]">{ord.id}</span>
                      <span className="text-stone-300">·</span>
                      <span className="text-xs font-semibold text-stone-800 truncate">{ord.garmentDescription}</span>
                    </div>
                    <div className="flex items-center gap-3 text-[11px] text-stone-500 mt-1">
                      <span>Delivery: <strong className="text-stone-700">{formatDate(ord.deliveryDate)}</strong></span>
                      <span>·</span>
                      <span>Total: <strong className="text-stone-700 font-mono-data">{formatINR(ord.charges.totalAmount)}</strong></span>
                      {ord.charges.balanceAmount > 0 && (
                        <span className="text-red-600 font-semibold font-mono-data">Due: {formatINR(ord.charges.balanceAmount)}</span>
                      )}
                    </div>
                  </div>
                  <span className={`px-2 py-0.5 rounded text-[10px] font-semibold uppercase tracking-wider border shrink-0 ${statusStyle.bg} ${statusStyle.text} ${statusStyle.border}`}>
                    {getStatusLabel(ord.status)}
                  </span>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </Modal>
  );
};
