import React from 'react';
import { Order, ShopSettings } from '../../types';
import { Modal } from '../common/Modal';
import { formatINR, formatDate, getStatusLabel } from '../../utils/formatters';
import { Printer, Download, CheckCircle, Scissors, Phone, MapPin, Mail } from 'lucide-react';

interface InvoiceModalProps {
  isOpen: boolean;
  onClose: () => void;
  order: Order | null;
  settings: ShopSettings;
}

export const InvoiceModal: React.FC<InvoiceModalProps> = ({
  isOpen,
  onClose,
  order,
  settings
}) => {
  if (!order) return null;

  const handlePrint = () => {
    window.print();
  };

  const invoiceNo = `${settings.invoicePrefix || 'STB'}-${order.id.replace('ORD-', '')}`;
  const isPaidFull = order.charges.balanceAmount === 0;

  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      title="Printable Job Invoice & Cash Memo"
      subtitle={`Invoice #${invoiceNo} · Customer: ${order.customerName}`}
      maxWidth="4xl"
    >
      <div className="space-y-4">
        {/* Top Control Bar (Hidden on print) */}
        <div className="no-print flex items-center justify-between pb-3 border-b border-stone-200">
          <div className="text-xs text-stone-500">
            Official receipt layout formatted for A4 standard printing and customer collection.
          </div>
          <button
            type="button"
            onClick={handlePrint}
            className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-semibold text-white bg-[#1B2A4A] hover:bg-[#142038] rounded-lg shadow-sm transition-colors"
          >
            <Printer className="w-4 h-4 text-[#C85A32]" />
            <span>Print Invoice / Receipt</span>
          </button>
        </div>

        {/* Printable Invoice Container */}
        <div className="print-area bg-white p-6 sm:p-8 rounded-xl border border-stone-300 shadow-sm text-stone-900 font-sans">
          {/* Header */}
          <div className="flex flex-col sm:flex-row justify-between items-start gap-4 pb-6 border-b-2 border-stone-800">
            <div>
              <div className="flex items-center gap-2">
                <Scissors className="w-5 h-5 text-[#C85A32]" />
                <h2 className="text-xl sm:text-2xl font-bold font-serif-tailor text-[#1B2A4A] tracking-tight">
                  {settings.shopName}
                </h2>
              </div>
              <p className="text-xs text-stone-600 mt-0.5 italic">{settings.tagline}</p>
              <div className="mt-2 text-[11px] text-stone-600 space-y-0.5">
                <p>{settings.address}</p>
                <p>Phone: {settings.phone} {settings.alternatePhone ? `| ${settings.alternatePhone}` : ''}</p>
                {settings.gstin && <p className="font-mono-data font-semibold">GSTIN: {settings.gstin}</p>}
              </div>
            </div>

            <div className="text-right sm:text-right w-full sm:w-auto">
              <span className="inline-block px-3 py-1 bg-stone-100 text-[#1B2A4A] font-bold text-xs uppercase tracking-wider rounded border border-stone-300">
                TAILOR JOB INVOICE
              </span>
              <div className="mt-2 text-xs text-stone-600 space-y-1">
                <p>
                  <span className="text-stone-400">Invoice No: </span>
                  <strong className="text-stone-900 font-mono-data">{invoiceNo}</strong>
                </p>
                <p>
                  <span className="text-stone-400">Order ID: </span>
                  <strong className="text-stone-900 font-mono-data">{order.id}</strong>
                </p>
                <p>
                  <span className="text-stone-400">Booking Date: </span>
                  <span className="font-mono-data">{formatDate(order.orderDate)}</span>
                </p>
                <p>
                  <span className="text-stone-400">Target Delivery: </span>
                  <strong className="text-[#C85A32] font-mono-data">{formatDate(order.deliveryDate)}</strong>
                </p>
              </div>
            </div>
          </div>

          {/* Customer & Garment Banner */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 my-6 p-4 rounded-lg bg-[#FAF8F5] border border-[#E8DEC8] text-xs">
            <div>
              <p className="text-[10px] font-bold uppercase tracking-wider text-stone-400 mb-1">
                Billed To (Customer Details)
              </p>
              <p className="font-bold text-stone-900 text-sm">{order.customerName}</p>
              <p className="font-mono-data text-stone-600 mt-0.5">Mobile: {order.customerPhone || 'N/A'}</p>
              <p className="text-stone-500 mt-1">Priority: <strong className="capitalize">{order.priority}</strong></p>
            </div>

            <div>
              <p className="text-[10px] font-bold uppercase tracking-wider text-stone-400 mb-1">
                Garment & Fabric Specification
              </p>
              <p className="font-bold text-stone-900 capitalize">
                {order.garmentDescription} ({order.quantity} Pcs)
              </p>
              <p className="text-stone-600 mt-0.5">
                Fabric: {order.fabricDetails.fabricType} · {order.fabricDetails.color}
              </p>
              <p className="text-stone-500 mt-1">
                Cloth: {order.fabricDetails.customerProvided ? 'Customer Provided' : 'Supplied by Tailor Shop'}
              </p>
            </div>
          </div>

          {/* Attached Measurement Snapshot */}
          {Object.keys(order.measurementsSnapshot || {}).length > 0 && (
            <div className="mb-6 p-3 rounded-lg border border-dashed border-stone-300 bg-stone-50 text-[11px]">
              <div className="flex items-center justify-between mb-1.5">
                <span className="font-semibold text-[#1B2A4A] uppercase text-[10px] tracking-wide">
                  Body Measurement Specs ({order.measurementUnit})
                </span>
                <span className="text-[10px] text-stone-400">Verified by Master Tailor</span>
              </div>
              <div className="grid grid-cols-3 sm:grid-cols-6 gap-2 font-mono-data">
                {Object.entries(order.measurementsSnapshot).map(([k, v]) => (
                  <div key={k} className="truncate">
                    <span className="text-stone-400 capitalize">{k}: </span>
                    <strong className="text-stone-800">{String(v)}</strong>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Charges Table */}
          <div className="overflow-x-auto mb-6">
            <table className="w-full text-xs text-left border-collapse">
              <thead>
                <tr className="border-b-2 border-stone-800 text-[11px] uppercase tracking-wider text-stone-600 bg-stone-50">
                  <th className="py-2.5 px-3">Description</th>
                  <th className="py-2.5 px-3 text-center">Qty</th>
                  <th className="py-2.5 px-3 text-right">Rate</th>
                  <th className="py-2.5 px-3 text-right">Amount (₹)</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-stone-200">
                <tr>
                  <td className="py-2.5 px-3">
                    <p className="font-semibold text-stone-900">{order.garmentDescription}</p>
                    <p className="text-[10px] text-stone-500">Master bespoke drafting, cutting & stitching</p>
                  </td>
                  <td className="py-2.5 px-3 text-center font-mono-data">{order.quantity}</td>
                  <td className="py-2.5 px-3 text-right font-mono-data">{formatINR(order.charges.stitchingCharge)}</td>
                  <td className="py-2.5 px-3 text-right font-mono-data font-semibold">
                    {formatINR(order.charges.stitchingCharge * order.quantity)}
                  </td>
                </tr>

                {order.charges.addOnCharges > 0 && (
                  <tr>
                    <td className="py-2.5 px-3">
                      <p className="font-semibold text-stone-900">Custom Styling & Add-ons</p>
                      <p className="text-[10px] text-stone-500">Embroidery work, cup padding, inner lining, or fancy dori</p>
                    </td>
                    <td className="py-2.5 px-3 text-center font-mono-data">1</td>
                    <td className="py-2.5 px-3 text-right font-mono-data">{formatINR(order.charges.addOnCharges)}</td>
                    <td className="py-2.5 px-3 text-right font-mono-data font-semibold">
                      {formatINR(order.charges.addOnCharges)}
                    </td>
                  </tr>
                )}

                {order.charges.fabricCharge > 0 && (
                  <tr>
                    <td className="py-2.5 px-3">
                      <p className="font-semibold text-stone-900">Shop Fabric & Trims</p>
                      <p className="text-[10px] text-stone-500">{order.fabricDetails.fabricType} fabric supplied</p>
                    </td>
                    <td className="py-2.5 px-3 text-center font-mono-data">1</td>
                    <td className="py-2.5 px-3 text-right font-mono-data">{formatINR(order.charges.fabricCharge)}</td>
                    <td className="py-2.5 px-3 text-right font-mono-data font-semibold">
                      {formatINR(order.charges.fabricCharge)}
                    </td>
                  </tr>
                )}

                {order.charges.discount > 0 && (
                  <tr className="text-emerald-700">
                    <td className="py-2.5 px-3 font-semibold" colSpan={3}>
                      Promotional Discount Applied
                    </td>
                    <td className="py-2.5 px-3 text-right font-mono-data font-semibold">
                      - {formatINR(order.charges.discount)}
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>

          {/* Financial Breakdown & Stamp */}
          <div className="flex flex-col sm:flex-row justify-between items-start gap-6 pt-4 border-t-2 border-stone-800">
            {/* Status Stamp */}
            <div className="w-full sm:w-1/2">
              <div className="flex items-center gap-2 mb-2">
                <span className="text-[10px] font-bold uppercase text-stone-400">Order Progress:</span>
                <span className="px-2 py-0.5 rounded text-[10px] font-bold uppercase bg-stone-100 text-[#1B2A4A] border border-stone-300">
                  {getStatusLabel(order.status)}
                </span>
              </div>

              {isPaidFull ? (
                <div className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg border-2 border-emerald-600 text-emerald-800 bg-emerald-50 text-xs font-bold uppercase tracking-wider">
                  <CheckCircle className="w-4 h-4 text-emerald-600" />
                  <span>Paid in Full</span>
                </div>
              ) : (
                <div className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg border-2 border-amber-600 text-amber-900 bg-amber-50 text-xs font-bold uppercase tracking-wider">
                  <span>Balance Due: {formatINR(order.charges.balanceAmount)}</span>
                </div>
              )}

              <div className="mt-4 text-[10px] text-stone-500 whitespace-pre-line leading-relaxed">
                <strong className="text-stone-700">Terms & Conditions:</strong>
                {'\n'}{settings.invoiceFooterTerms}
              </div>
            </div>

            {/* Calculations right box */}
            <div className="w-full sm:w-1/2 sm:max-w-xs space-y-1.5 text-xs text-right">
              <div className="flex justify-between text-stone-600">
                <span>Subtotal:</span>
                <span className="font-mono-data font-semibold">
                  {formatINR(order.charges.stitchingCharge + order.charges.addOnCharges + order.charges.fabricCharge)}
                </span>
              </div>

              {order.charges.discount > 0 && (
                <div className="flex justify-between text-emerald-700">
                  <span>Discount:</span>
                  <span className="font-mono-data font-semibold">- {formatINR(order.charges.discount)}</span>
                </div>
              )}

              <div className="flex justify-between text-sm font-bold text-stone-900 pt-1 border-t border-stone-200">
                <span>Total Bill Amount:</span>
                <span className="font-mono-data">{formatINR(order.charges.totalAmount)}</span>
              </div>

              <div className="flex justify-between text-stone-600">
                <span>Advance Paid:</span>
                <span className="font-mono-data font-semibold text-emerald-700">
                  {formatINR(order.charges.advancePaid)}
                </span>
              </div>

              <div className="flex justify-between text-sm font-bold text-[#C85A32] pt-1 border-t-2 border-stone-800">
                <span>Balance to Pay:</span>
                <span className="font-mono-data">{formatINR(order.charges.balanceAmount)}</span>
              </div>
            </div>
          </div>

          {/* Signatures footer */}
          <div className="grid grid-cols-2 gap-8 mt-12 pt-6 border-t border-stone-200 text-center text-xs text-stone-500">
            <div>
              <div className="h-10 border-b border-dashed border-stone-300 mb-1" />
              <p className="font-medium text-stone-700">Customer Signature</p>
            </div>
            <div>
              <div className="h-10 border-b border-dashed border-stone-300 mb-1 flex items-end justify-center pb-1">
                <span className="font-serif-tailor italic text-stone-700 font-bold">{settings.ownerName}</span>
              </div>
              <p className="font-medium text-stone-700">For {settings.shopName}</p>
            </div>
          </div>
        </div>
      </div>
    </Modal>
  );
};
