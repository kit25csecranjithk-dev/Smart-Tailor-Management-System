import React, { useState, useEffect } from 'react';
import { Order, PaymentMethod, PaymentRecord } from '../../types';
import { Modal } from '../common/Modal';
import { formatINR } from '../../utils/formatters';
import { CreditCard, IndianRupee, QrCode, Banknote } from 'lucide-react';

interface PaymentModalProps {
  isOpen: boolean;
  onClose: () => void;
  order: Order | null;
  onRecordPayment: (payment: Omit<PaymentRecord, 'id' | 'receiptNo' | 'date'> & { date?: string }) => void;
}

export const PaymentModal: React.FC<PaymentModalProps> = ({
  isOpen,
  onClose,
  order,
  onRecordPayment
}) => {
  const [amount, setAmount] = useState<number>(0);
  const [method, setMethod] = useState<PaymentMethod>('upi');
  const [notes, setNotes] = useState('');
  const [date, setDate] = useState(new Date().toISOString().split('T')[0]);
  const [error, setError] = useState('');

  useEffect(() => {
    if (order) {
      setAmount(order.charges.balanceAmount > 0 ? order.charges.balanceAmount : 0);
      setMethod('upi');
      setNotes(`Payment for Order #${order.id}`);
      setDate(new Date().toISOString().split('T')[0]);
    }
    setError('');
  }, [order, isOpen]);

  if (!order) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!amount || amount <= 0) {
      setError('Please enter a valid payment amount');
      return;
    }

    onRecordPayment({
      orderId: order.id,
      customerId: order.customerId,
      customerName: order.customerName,
      amount: Number(amount),
      method,
      notes: notes.trim() || undefined,
      date
    });
    onClose();
  };

  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      title="Record Customer Payment"
      subtitle={`Order #${order.id} · ${order.customerName}`}
      maxWidth="md"
    >
      <form onSubmit={handleSubmit} className="space-y-4">
        {/* Balance Reminder */}
        <div className="p-3.5 rounded-lg bg-[#FAF6EE] border border-[#E8DEC8] flex items-center justify-between text-xs">
          <div>
            <span className="text-stone-500">Order Total: </span>
            <strong className="text-stone-800 font-mono-data">{formatINR(order.charges.totalAmount)}</strong>
          </div>
          <div>
            <span className="text-stone-500">Already Paid: </span>
            <strong className="text-emerald-700 font-mono-data">{formatINR(order.charges.advancePaid)}</strong>
          </div>
          <div>
            <span className="text-[#C85A32] font-semibold">Remaining Due: </span>
            <strong className="text-[#C85A32] font-mono-data font-bold">{formatINR(order.charges.balanceAmount)}</strong>
          </div>
        </div>

        {error && (
          <div className="p-2.5 rounded-lg bg-red-50 text-red-700 text-xs border border-red-200">
            {error}
          </div>
        )}

        <div>
          <label className="block text-xs font-semibold text-stone-700 mb-1">
            Payment Amount Received (₹) <span className="text-red-500">*</span>
          </label>
          <div className="relative">
            <span className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-stone-400 font-bold">
              ₹
            </span>
            <input
              type="number"
              min="1"
              max={order.charges.balanceAmount > 0 ? order.charges.balanceAmount : undefined}
              value={amount}
              onChange={(e) => setAmount(parseFloat(e.target.value) || 0)}
              className="w-full pl-8 pr-3 py-2 text-sm font-bold font-mono-data text-stone-900 bg-white border border-[#D5C9B3] rounded-lg focus:outline-none focus:ring-2 focus:ring-[#C85A32]/30 focus:border-[#C85A32]"
            />
          </div>
        </div>

        {/* Quick Amount Buttons */}
        {order.charges.balanceAmount > 0 && (
          <div className="flex gap-2">
            <button
              type="button"
              onClick={() => setAmount(order.charges.balanceAmount)}
              className="px-2.5 py-1 text-[11px] font-semibold text-[#1B2A4A] bg-[#EFE9DD] hover:bg-[#E4DBCB] rounded border border-[#D8CEBE]"
            >
              Full Balance ({formatINR(order.charges.balanceAmount)})
            </button>
            {order.charges.balanceAmount > 500 && (
              <button
                type="button"
                onClick={() => setAmount(500)}
                className="px-2.5 py-1 text-[11px] font-semibold text-stone-700 bg-white hover:bg-stone-50 rounded border border-stone-200"
              >
                ₹500 Part
              </button>
            )}
          </div>
        )}

        <div className="grid grid-cols-2 gap-3">
          <div>
            <label className="block text-xs font-semibold text-stone-700 mb-1">
              Payment Method
            </label>
            <select
              value={method}
              onChange={(e) => setMethod(e.target.value as PaymentMethod)}
              className="w-full px-3 py-2 text-xs bg-white border border-[#D5C9B3] rounded-lg"
            >
              <option value="upi">UPI (GPay / PhonePe / Paytm)</option>
              <option value="cash">Cash on Counter</option>
              <option value="card">Debit / Credit Card</option>
              <option value="bank_transfer">Direct Bank Transfer</option>
            </select>
          </div>

          <div>
            <label className="block text-xs font-semibold text-stone-700 mb-1">
              Payment Date
            </label>
            <input
              type="date"
              value={date}
              onChange={(e) => setDate(e.target.value)}
              className="w-full px-3 py-2 text-xs bg-white border border-[#D5C9B3] rounded-lg font-mono-data"
            />
          </div>
        </div>

        <div>
          <label className="block text-xs font-semibold text-stone-700 mb-1">
            Transaction Notes / Reference (Optional)
          </label>
          <input
            type="text"
            value={notes}
            onChange={(e) => setNotes(e.target.value)}
            placeholder="e.g. UPI Ref #4029194, Final balance settled"
            className="w-full px-3 py-2 text-xs bg-white border border-[#D5C9B3] rounded-lg"
          />
        </div>

        <div className="flex justify-end gap-3 pt-3 border-t border-[#E8DEC8]">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 text-xs font-semibold text-stone-700 bg-white border border-[#D5C9B3] rounded-lg hover:bg-stone-50"
          >
            Cancel
          </button>
          <button
            type="submit"
            className="px-4 py-2 text-xs font-semibold text-white bg-emerald-700 hover:bg-emerald-800 rounded-lg shadow-sm"
          >
            Confirm & Save Payment
          </button>
        </div>
      </form>
    </Modal>
  );
};
