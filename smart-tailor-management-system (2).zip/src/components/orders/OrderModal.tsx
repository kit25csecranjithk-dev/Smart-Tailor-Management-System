import React, { useState, useEffect } from 'react';
import {
  Customer,
  GarmentType,
  Order,
  OrderStatus,
  OrderPriority,
  MeasurementRecord,
  MeasurementUnit
} from '../../types';
import { Modal } from '../common/Modal';
import { formatINR } from '../../utils/formatters';
import { Sparkles, Calculator, CheckSquare, Plus } from 'lucide-react';

interface OrderModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (orderData: Partial<Order> & { customerId: string; garmentType: GarmentType }) => void;
  customers: Customer[];
  measurements: MeasurementRecord[];
  order?: Order | null;
  preselectedCustomerId?: string;
  onQuickAddCustomer: () => void;
}

export const OrderModal: React.FC<OrderModalProps> = ({
  isOpen,
  onClose,
  onSave,
  customers,
  measurements,
  order,
  preselectedCustomerId,
  onQuickAddCustomer
}) => {
  // Customer & Garment
  const [customerId, setCustomerId] = useState('');
  const [garmentType, setGarmentType] = useState<GarmentType>('blouse');
  const [garmentDescription, setGarmentDescription] = useState('');
  const [quantity, setQuantity] = useState(1);

  // Measurement Link
  const [selectedMeasurementId, setSelectedMeasurementId] = useState('');
  const [measurementUnit, setMeasurementUnit] = useState<MeasurementUnit>('inches');
  const [measurementsSnapshot, setMeasurementsSnapshot] = useState<Record<string, any>>({});

  // Fabric details
  const [fabricType, setFabricType] = useState('Pure Silk');
  const [fabricColor, setFabricColor] = useState('Red & Gold');
  const [fabricPattern, setFabricPattern] = useState('');
  const [customerProvided, setCustomerProvided] = useState(true);
  const [fabricLengthMeters, setFabricLengthMeters] = useState<number | undefined>(1.0);
  const [fabricNotes, setFabricNotes] = useState('');

  // Dates & Priority
  const todayStr = new Date().toISOString().split('T')[0];
  const defaultDeliveryStr = new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString().split('T')[0];
  const defaultTrialStr = new Date(Date.now() + 4 * 24 * 60 * 60 * 1000).toISOString().split('T')[0];

  const [orderDate, setOrderDate] = useState(todayStr);
  const [trialDate, setTrialDate] = useState(defaultTrialStr);
  const [deliveryDate, setDeliveryDate] = useState(defaultDeliveryStr);
  const [priority, setPriority] = useState<OrderPriority>('standard');
  const [status, setStatus] = useState<OrderStatus>('received');
  const [assignedTailor, setAssignedTailor] = useState('Master Murugan');
  const [notes, setNotes] = useState('');

  // Pricing calculations
  const [stitchingCharge, setStitchingCharge] = useState<number>(850);
  const [addOnCharges, setAddOnCharges] = useState<number>(200);
  const [fabricCharge, setFabricCharge] = useState<number>(0);
  const [discount, setDiscount] = useState<number>(0);
  const [advancePaid, setAdvancePaid] = useState<number>(500);

  const [errors, setErrors] = useState<Record<string, string>>({});

  // Available measurements for this customer
  const availableMeasurements = measurements.filter(
    (m) => m.customerId === customerId && (m.garmentType === garmentType || !garmentType)
  );

  useEffect(() => {
    if (order) {
      setCustomerId(order.customerId);
      setGarmentType(order.garmentType);
      setGarmentDescription(order.garmentDescription);
      setQuantity(order.quantity);

      setSelectedMeasurementId(order.measurementId || '');
      setMeasurementUnit(order.measurementUnit);
      setMeasurementsSnapshot(order.measurementsSnapshot || {});

      setFabricType(order.fabricDetails.fabricType);
      setFabricColor(order.fabricDetails.color);
      setFabricPattern(order.fabricDetails.pattern || '');
      setCustomerProvided(order.fabricDetails.customerProvided);
      setFabricLengthMeters(order.fabricDetails.lengthMeters);
      setFabricNotes(order.fabricDetails.notes || '');

      setOrderDate(order.orderDate);
      setTrialDate(order.trialDate || '');
      setDeliveryDate(order.deliveryDate);
      setPriority(order.priority);
      setStatus(order.status);
      setAssignedTailor(order.assignedTailor || 'Master Murugan');
      setNotes(order.notes || '');

      setStitchingCharge(order.charges.stitchingCharge);
      setAddOnCharges(order.charges.addOnCharges);
      setFabricCharge(order.charges.fabricCharge);
      setDiscount(order.charges.discount);
      setAdvancePaid(order.charges.advancePaid);
    } else {
      const initialCust = preselectedCustomerId || customers[0]?.id || '';
      setCustomerId(initialCust);
      setGarmentType('blouse');
      setGarmentDescription('Custom Saree Blouse with Princess Cut');
      setQuantity(1);

      setSelectedMeasurementId('');
      setMeasurementsSnapshot({});
      setMeasurementUnit('inches');

      setFabricType('Pure Silk');
      setFabricColor('Red & Gold');
      setFabricPattern('');
      setCustomerProvided(true);
      setFabricLengthMeters(1.0);
      setFabricNotes('');

      setOrderDate(todayStr);
      setTrialDate(defaultTrialStr);
      setDeliveryDate(defaultDeliveryStr);
      setPriority('standard');
      setStatus('received');
      setAssignedTailor('Master Murugan');
      setNotes('');

      setStitchingCharge(850);
      setAddOnCharges(200);
      setFabricCharge(0);
      setDiscount(50);
      setAdvancePaid(500);
    }
    setErrors({});
  }, [order, preselectedCustomerId, isOpen, customers]);

  // When customer or garmentType changes, auto-select matching measurement if available
  const handleMeasurementSelection = (mId: string) => {
    setSelectedMeasurementId(mId);
    const found = measurements.find((m) => m.id === mId);
    if (found) {
      setMeasurementsSnapshot(found.values);
      setMeasurementUnit(found.unit);
    }
  };

  // Pricing math
  const subtotal = (Number(stitchingCharge) || 0) + (Number(addOnCharges) || 0) + (Number(fabricCharge) || 0);
  const totalAmount = Math.max(0, subtotal - (Number(discount) || 0));
  const balanceAmount = Math.max(0, totalAmount - (Number(advancePaid) || 0));

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const newErrors: Record<string, string> = {};

    if (!customerId) newErrors.customerId = 'Please select a customer';
    if (!garmentDescription.trim()) newErrors.garmentDescription = 'Please describe the garment order';
    if (!deliveryDate) newErrors.deliveryDate = 'Delivery date is required';
    if (totalAmount <= 0) newErrors.total = 'Total amount cannot be zero';

    if (Object.keys(newErrors).length > 0) {
      setErrors(newErrors);
      return;
    }

    const selectedCust = customers.find((c) => c.id === customerId);

    onSave({
      id: order?.id,
      customerId,
      customerName: selectedCust ? selectedCust.name : 'Customer',
      customerPhone: selectedCust ? selectedCust.phone : '',
      garmentType,
      garmentDescription: garmentDescription.trim(),
      quantity: Number(quantity) || 1,
      fabricDetails: {
        fabricType: fabricType.trim(),
        color: fabricColor.trim(),
        pattern: fabricPattern.trim() || undefined,
        customerProvided,
        lengthMeters: fabricLengthMeters ? Number(fabricLengthMeters) : undefined,
        notes: fabricNotes.trim() || undefined
      },
      measurementId: selectedMeasurementId || undefined,
      measurementsSnapshot,
      measurementUnit,
      status,
      priority,
      orderDate,
      trialDate: trialDate || undefined,
      deliveryDate,
      charges: {
        stitchingCharge: Number(stitchingCharge) || 0,
        addOnCharges: Number(addOnCharges) || 0,
        fabricCharge: Number(fabricCharge) || 0,
        discount: Number(discount) || 0,
        totalAmount,
        advancePaid: Number(advancePaid) || 0,
        balanceAmount
      },
      assignedTailor: assignedTailor.trim() || undefined,
      notes: notes.trim() || undefined
    });
    onClose();
  };

  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      title={order ? `Edit Stitching Order #${order.id}` : 'Create New Stitching Work Order'}
      subtitle="Complete tailor job ticket with measurements, fabric details and billing"
      maxWidth="4xl"
    >
      <form onSubmit={handleSubmit} className="space-y-6">
        {/* Step 1: Customer & Garment Type */}
        <div className="bg-[#FAF6EE] p-4 rounded-xl border border-[#E8DEC8] space-y-3">
          <div className="flex items-center justify-between">
            <h4 className="text-xs font-bold text-[#1B2A4A] uppercase tracking-wider">
              1. Customer & Garment Details
            </h4>
            <button
              type="button"
              onClick={onQuickAddCustomer}
              className="text-xs font-semibold text-[#C85A32] hover:text-[#9A3B18] flex items-center gap-1"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Register New Client</span>
            </button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div>
              <label className="block text-xs font-semibold text-stone-700 mb-1">
                Select Customer <span className="text-red-500">*</span>
              </label>
              <select
                value={customerId}
                onChange={(e) => {
                  setCustomerId(e.target.value);
                  setSelectedMeasurementId('');
                }}
                className="w-full px-3 py-2 text-xs bg-white border border-[#D5C9B3] rounded-lg focus:outline-none focus:ring-2 focus:ring-[#C85A32]/30 focus:border-[#C85A32]"
              >
                <option value="">-- Choose Customer --</option>
                {customers.map((c) => (
                  <option key={c.id} value={c.id}>
                    {c.name} · {c.phone}
                  </option>
                ))}
              </select>
              {errors.customerId && <p className="text-[11px] text-red-600 mt-1">{errors.customerId}</p>}
            </div>

            <div>
              <label className="block text-xs font-semibold text-stone-700 mb-1">
                Garment Category
              </label>
              <select
                value={garmentType}
                onChange={(e) => {
                  setGarmentType(e.target.value as GarmentType);
                  setSelectedMeasurementId('');
                }}
                className="w-full px-3 py-2 text-xs bg-white border border-[#D5C9B3] rounded-lg focus:outline-none focus:ring-2 focus:ring-[#C85A32]/30 focus:border-[#C85A32]"
              >
                <option value="blouse">Saree Blouse</option>
                <option value="shirt">Formal / Casual Shirt</option>
                <option value="pants">Trousers / Pants</option>
                <option value="churidar">Churidar / Salwar Kameez</option>
                <option value="kurta">Men Kurta / Sherwani</option>
                <option value="suit">Blazer / 2-Piece Suit</option>
                <option value="custom">Custom Tailored</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-semibold text-stone-700 mb-1">
                Quantity (Pcs)
              </label>
              <input
                type="number"
                min="1"
                max="50"
                value={quantity}
                onChange={(e) => setQuantity(Math.max(1, parseInt(e.target.value) || 1))}
                className="w-full px-3 py-2 text-xs bg-white border border-[#D5C9B3] rounded-lg font-mono-data"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-stone-700 mb-1">
              Garment Description & Style Specification <span className="text-red-500">*</span>
            </label>
            <input
              type="text"
              value={garmentDescription}
              onChange={(e) => setGarmentDescription(e.target.value)}
              placeholder="e.g., Deep back pot-neck bridal blouse with padded cups and tassels"
              className="w-full px-3 py-2 text-xs bg-white border border-[#D5C9B3] rounded-lg focus:outline-none focus:ring-2 focus:ring-[#C85A32]/30 focus:border-[#C85A32]"
            />
            {errors.garmentDescription && (
              <p className="text-[11px] text-red-600 mt-1">{errors.garmentDescription}</p>
            )}
          </div>
        </div>

        {/* Step 2: Measurement Link */}
        <div className="bg-[#FAF6EE] p-4 rounded-xl border border-[#E8DEC8] space-y-3">
          <h4 className="text-xs font-bold text-[#1B2A4A] uppercase tracking-wider">
            2. Attached Measurements
          </h4>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-semibold text-stone-700 mb-1">
                Select Saved Measurement Card
              </label>
              <select
                value={selectedMeasurementId}
                onChange={(e) => handleMeasurementSelection(e.target.value)}
                className="w-full px-3 py-2 text-xs bg-white border border-[#D5C9B3] rounded-lg focus:outline-none focus:ring-2 focus:ring-[#C85A32]/30 focus:border-[#C85A32]"
              >
                <option value="">-- Enter / Use Manual Specifications --</option>
                {availableMeasurements.map((m) => (
                  <option key={m.id} value={m.id}>
                    {m.title} ({m.unit}) - {m.recordedDate}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs font-semibold text-stone-700 mb-1">
                Measurement Unit
              </label>
              <div className="flex items-center gap-2 pt-1 text-xs text-stone-600">
                <span className="font-semibold uppercase font-mono-data px-2 py-1 bg-white border border-[#D5C9B3] rounded">
                  {measurementUnit}
                </span>
                <span className="text-stone-400">
                  {Object.keys(measurementsSnapshot).length > 0
                    ? `(${Object.keys(measurementsSnapshot).length} data points attached)`
                    : '(No measurements attached)'}
                </span>
              </div>
            </div>
          </div>

          {Object.keys(measurementsSnapshot).length > 0 && (
            <div className="mt-2 p-2.5 rounded-lg bg-white border border-[#E2D9CC] grid grid-cols-3 sm:grid-cols-6 gap-2 text-[11px] font-mono-data">
              {Object.entries(measurementsSnapshot).map(([k, v]) => (
                <div key={k} className="truncate">
                  <span className="text-stone-400 capitalize">{k}: </span>
                  <strong className="text-stone-800">{String(v)}</strong>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Step 3: Fabric Details */}
        <div className="bg-[#FAF6EE] p-4 rounded-xl border border-[#E8DEC8] space-y-3">
          <h4 className="text-xs font-bold text-[#1B2A4A] uppercase tracking-wider">
            3. Fabric & Material Specifications
          </h4>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div>
              <label className="block text-xs font-semibold text-stone-700 mb-1">
                Fabric Material
              </label>
              <input
                type="text"
                value={fabricType}
                onChange={(e) => setFabricType(e.target.value)}
                placeholder="e.g. Raw Silk, Giza Cotton, Linen"
                className="w-full px-3 py-2 text-xs bg-white border border-[#D5C9B3] rounded-lg"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-stone-700 mb-1">
                Fabric Color & Shade
              </label>
              <input
                type="text"
                value={fabricColor}
                onChange={(e) => setFabricColor(e.target.value)}
                placeholder="e.g. Maroon & Gold, Navy Blue"
                className="w-full px-3 py-2 text-xs bg-white border border-[#D5C9B3] rounded-lg"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-stone-700 mb-1">
                Fabric Sourcing
              </label>
              <select
                value={customerProvided ? 'customer' : 'shop'}
                onChange={(e) => setCustomerProvided(e.target.value === 'customer')}
                className="w-full px-3 py-2 text-xs bg-white border border-[#D5C9B3] rounded-lg"
              >
                <option value="customer">Customer Provided Cloth</option>
                <option value="shop">Shop Provided Fabric Bolt</option>
              </select>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-semibold text-stone-700 mb-1">
                Fabric Length (Meters)
              </label>
              <input
                type="number"
                step="0.1"
                min="0"
                value={fabricLengthMeters ?? ''}
                onChange={(e) => setFabricLengthMeters(parseFloat(e.target.value) || undefined)}
                placeholder="1.0"
                className="w-full px-3 py-2 text-xs bg-white border border-[#D5C9B3] rounded-lg font-mono-data"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-stone-700 mb-1">
                Fabric / Trim Notes
              </label>
              <input
                type="text"
                value={fabricNotes}
                onChange={(e) => setFabricNotes(e.target.value)}
                placeholder="e.g. Customer brought border, matching thread #402"
                className="w-full px-3 py-2 text-xs bg-white border border-[#D5C9B3] rounded-lg"
              />
            </div>
          </div>
        </div>

        {/* Step 4: Schedule, Priority & Tailor */}
        <div className="bg-[#FAF6EE] p-4 rounded-xl border border-[#E8DEC8] space-y-3">
          <h4 className="text-xs font-bold text-[#1B2A4A] uppercase tracking-wider">
            4. Timeline & Production
          </h4>

          <div className="grid grid-cols-1 sm:grid-cols-4 gap-3">
            <div>
              <label className="block text-xs font-semibold text-stone-700 mb-1">
                Order Date
              </label>
              <input
                type="date"
                value={orderDate}
                onChange={(e) => setOrderDate(e.target.value)}
                className="w-full px-3 py-2 text-xs bg-white border border-[#D5C9B3] rounded-lg font-mono-data"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-stone-700 mb-1">
                Trial / Basting Date
              </label>
              <input
                type="date"
                value={trialDate}
                onChange={(e) => setTrialDate(e.target.value)}
                className="w-full px-3 py-2 text-xs bg-white border border-[#D5C9B3] rounded-lg font-mono-data"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-stone-700 mb-1">
                Target Delivery Date <span className="text-red-500">*</span>
              </label>
              <input
                type="date"
                value={deliveryDate}
                onChange={(e) => setDeliveryDate(e.target.value)}
                className="w-full px-3 py-2 text-xs bg-white border border-[#D5C9B3] rounded-lg font-mono-data font-semibold text-[#C85A32]"
              />
              {errors.deliveryDate && <p className="text-[11px] text-red-600 mt-1">{errors.deliveryDate}</p>}
            </div>

            <div>
              <label className="block text-xs font-semibold text-stone-700 mb-1">
                Order Priority
              </label>
              <select
                value={priority}
                onChange={(e) => setPriority(e.target.value as OrderPriority)}
                className="w-full px-3 py-2 text-xs bg-white border border-[#D5C9B3] rounded-lg font-semibold"
              >
                <option value="standard">Standard (7-10 Days)</option>
                <option value="urgent">Urgent (3-5 Days)</option>
                <option value="express">Express (24-48 Hours)</option>
              </select>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-semibold text-stone-700 mb-1">
                Assigned Master / Tailor
              </label>
              <select
                value={assignedTailor}
                onChange={(e) => setAssignedTailor(e.target.value)}
                className="w-full px-3 py-2 text-xs bg-white border border-[#D5C9B3] rounded-lg"
              >
                <option value="Master Murugan">Master Murugan (Blouse & Embroidery Specialist)</option>
                <option value="Master Senthil Kumar">Master Senthil Kumar (Suits & Bespoke Cutter)</option>
                <option value="Tailor Ramesh">Tailor Ramesh (Shirts & Trousers)</option>
                <option value="Tailor Fatima">Tailor Fatima (Salwar & Churidar)</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-semibold text-stone-700 mb-1">
                Current Production Stage
              </label>
              <select
                value={status}
                onChange={(e) => setStatus(e.target.value as OrderStatus)}
                className="w-full px-3 py-2 text-xs bg-white border border-[#D5C9B3] rounded-lg font-semibold text-[#1B2A4A]"
              >
                <option value="received">Order Received</option>
                <option value="cutting">Cutting</option>
                <option value="stitching">Stitching</option>
                <option value="trial">Trial / Alteration</option>
                <option value="ready">Ready for Delivery</option>
                <option value="delivered">Delivered</option>
              </select>
            </div>
          </div>
        </div>

        {/* Step 5: Pricing & Advance Calculator */}
        <div className="bg-[#FAF6EE] p-4 rounded-xl border border-[#E8DEC8] space-y-4">
          <div className="flex items-center justify-between">
            <h4 className="text-xs font-bold text-[#1B2A4A] uppercase tracking-wider flex items-center gap-1.5">
              <Calculator className="w-4 h-4 text-[#C85A32]" />
              <span>5. Tailoring Charges & Billing Calculation (₹)</span>
            </h4>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            <div>
              <label className="block text-[11px] font-semibold text-stone-600 mb-1">
                Basic Stitching (₹)
              </label>
              <input
                type="number"
                min="0"
                value={stitchingCharge}
                onChange={(e) => setStitchingCharge(parseFloat(e.target.value) || 0)}
                className="w-full px-3 py-2 text-xs bg-white border border-[#D5C9B3] rounded-lg font-mono-data"
              />
            </div>

            <div>
              <label className="block text-[11px] font-semibold text-stone-600 mb-1">
                Add-on / Work / Lining (₹)
              </label>
              <input
                type="number"
                min="0"
                value={addOnCharges}
                onChange={(e) => setAddOnCharges(parseFloat(e.target.value) || 0)}
                className="w-full px-3 py-2 text-xs bg-white border border-[#D5C9B3] rounded-lg font-mono-data"
              />
            </div>

            <div>
              <label className="block text-[11px] font-semibold text-stone-600 mb-1">
                Shop Fabric Cost (₹)
              </label>
              <input
                type="number"
                min="0"
                value={fabricCharge}
                onChange={(e) => setFabricCharge(parseFloat(e.target.value) || 0)}
                className="w-full px-3 py-2 text-xs bg-white border border-[#D5C9B3] rounded-lg font-mono-data"
              />
            </div>

            <div>
              <label className="block text-[11px] font-semibold text-stone-600 mb-1">
                Discount (₹)
              </label>
              <input
                type="number"
                min="0"
                value={discount}
                onChange={(e) => setDiscount(parseFloat(e.target.value) || 0)}
                className="w-full px-3 py-2 text-xs bg-white border border-[#D5C9B3] rounded-lg font-mono-data"
              />
            </div>
          </div>

          {/* Totals & Advance Bar */}
          <div className="p-4 rounded-xl bg-white border border-[#E2D9CC] flex flex-col sm:flex-row items-center justify-between gap-4">
            <div className="flex items-center gap-6 text-center sm:text-left">
              <div>
                <p className="text-[11px] uppercase font-semibold text-stone-400">Total Bill</p>
                <p className="text-xl font-extrabold text-[#1B2A4A] font-mono-data">{formatINR(totalAmount)}</p>
              </div>
              <div className="h-8 w-px bg-stone-200" />
              <div>
                <p className="text-[11px] uppercase font-semibold text-stone-400">Advance Paid</p>
                <p className="text-xl font-bold text-emerald-700 font-mono-data">{formatINR(advancePaid)}</p>
              </div>
              <div className="h-8 w-px bg-stone-200" />
              <div>
                <p className="text-[11px] uppercase font-semibold text-stone-400">Balance Pending</p>
                <p className="text-xl font-bold text-[#C85A32] font-mono-data">{formatINR(balanceAmount)}</p>
              </div>
            </div>

            <div className="w-full sm:w-48">
              <label className="block text-[11px] font-semibold text-stone-600 mb-1">
                Advance Collected (₹)
              </label>
              <input
                type="number"
                min="0"
                max={totalAmount}
                value={advancePaid}
                onChange={(e) => setAdvancePaid(parseFloat(e.target.value) || 0)}
                className="w-full px-3 py-2 text-xs bg-white border border-[#D5C9B3] rounded-lg font-mono-data font-bold text-emerald-700"
              />
            </div>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex justify-end gap-3 pt-4 border-t border-[#E8DEC8]">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 text-xs font-semibold text-stone-700 bg-white border border-[#D5C9B3] rounded-lg hover:bg-stone-50"
          >
            Cancel
          </button>
          <button
            type="submit"
            className="px-5 py-2.5 text-xs font-semibold text-white bg-[#C85A32] hover:bg-[#B34D29] rounded-lg shadow-sm"
          >
            {order ? 'Update Order Details' : 'Generate Stitching Order'}
          </button>
        </div>
      </form>
    </Modal>
  );
};
