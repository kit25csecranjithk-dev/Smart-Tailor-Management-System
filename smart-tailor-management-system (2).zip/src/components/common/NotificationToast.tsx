import React, { useEffect } from 'react';
import { CheckCircle2, AlertCircle, Info, X } from 'lucide-react';

export type ToastType = 'success' | 'error' | 'info';

export interface ToastMessage {
  id: string;
  type: ToastType;
  message: string;
}

interface ToastProps {
  toasts: ToastMessage[];
  onDismiss: (id: string) => void;
}

export const NotificationToast: React.FC<ToastProps> = ({ toasts, onDismiss }) => {
  return (
    <div className="fixed bottom-5 right-5 z-50 flex flex-col gap-2 max-w-md pointer-events-none">
      {toasts.map((toast) => (
        <ToastItem key={toast.id} toast={toast} onDismiss={onDismiss} />
      ))}
    </div>
  );
};

const ToastItem: React.FC<{ toast: ToastMessage; onDismiss: (id: string) => void }> = ({
  toast,
  onDismiss
}) => {
  useEffect(() => {
    const timer = setTimeout(() => {
      onDismiss(toast.id);
    }, 4000);
    return () => clearTimeout(timer);
  }, [toast.id, onDismiss]);

  const config = {
    success: {
      bg: 'bg-[#064E3B] text-emerald-50 border-emerald-700/50',
      icon: <CheckCircle2 className="w-4 h-4 text-emerald-300 shrink-0" />
    },
    error: {
      bg: 'bg-[#7F1D1D] text-red-50 border-red-700/50',
      icon: <AlertCircle className="w-4 h-4 text-red-300 shrink-0" />
    },
    info: {
      bg: 'bg-[#1E293B] text-slate-100 border-slate-700/50',
      icon: <Info className="w-4 h-4 text-sky-300 shrink-0" />
    }
  }[toast.type];

  return (
    <div
      role="status"
      className={`pointer-events-auto flex items-center justify-between gap-3 px-4 py-3 rounded-lg border shadow-lg text-xs font-medium animate-in fade-in slide-in-from-bottom-2 duration-200 ${config.bg}`}
    >
      <div className="flex items-center gap-2.5">
        {config.icon}
        <span>{toast.message}</span>
      </div>
      <button
        onClick={() => onDismiss(toast.id)}
        className="text-stone-300 hover:text-white p-0.5 rounded transition-colors"
        aria-label="Dismiss notification"
      >
        <X className="w-3.5 h-3.5" />
      </button>
    </div>
  );
};
