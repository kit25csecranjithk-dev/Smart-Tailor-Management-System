import React, { useState } from 'react';
import { Customer, Order, MeasurementRecord } from '../types';
import { Search, Plus, Phone, Mail, MapPin, Eye, Edit2, Trash2, Ruler, ShoppingBag } from 'lucide-react';
import { formatINR, formatDate } from '../utils/formatters';

interface CustomersPageProps {
  customers: Customer[];
  orders: Order[];
  measurements: MeasurementRecord[];
  onOpenCustomerModal: (customer?: Customer) => void;
  onOpenCustomerDetail: (customer: Customer) => void;
  onDeleteCustomer: (customer: Customer) => void;
  onNewOrderForCustomer: (customer: Customer) => void;
  onNewMeasurementForCustomer: (customer: Customer) => void;
}

export const CustomersPage: React.FC<CustomersPageProps> = ({
  customers,
  orders,
  measurements,
  onOpenCustomerModal,
  onOpenCustomerDetail,
  onDeleteCustomer,
  onNewOrderForCustomer,
  onNewMeasurementForCustomer
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [genderFilter, setGenderFilter] = useState<'all' | 'female' | 'male'>('all');

  const filteredCustomers = customers.filter((c) => {
    const matchesSearch =
      c.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      c.phone.includes(searchQuery) ||
      (c.address && c.address.toLowerCase().includes(searchQuery.toLowerCase()));
    const matchesGender = genderFilter === 'all' || c.gender === genderFilter;
    return matchesSearch && matchesGender;
  });

  return (
    <div className="space-y-5">
      {/* Search and Action Bar */}
      <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3 bg-white p-4 rounded-xl border border-[#E8DEC8] shadow-xs">
        <div className="flex-1 relative">
          <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-stone-400" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search customers by name, 10-digit mobile number, or address..."
            className="w-full pl-9 pr-3 py-2 text-xs bg-[#FAF8F5] border border-[#D5C9B3] rounded-lg focus:outline-none focus:ring-2 focus:ring-[#C85A32]/30 focus:border-[#C85A32]"
          />
        </div>

        <div className="flex items-center gap-2">
          {/* Gender Filter Buttons */}
          <div className="flex items-center gap-1 p-1 bg-[#FAF6EE] rounded-lg border border-[#E0D5C1]">
            <button
              onClick={() => setGenderFilter('all')}
              className={`px-3 py-1.5 text-xs font-semibold rounded-md transition-colors ${
                genderFilter === 'all' ? 'bg-white text-[#1B2A4A] shadow-xs' : 'text-stone-600 hover:text-stone-900'
              }`}
            >
              All ({customers.length})
            </button>
            <button
              onClick={() => setGenderFilter('female')}
              className={`px-3 py-1.5 text-xs font-semibold rounded-md transition-colors ${
                genderFilter === 'female' ? 'bg-white text-[#1B2A4A] shadow-xs' : 'text-stone-600 hover:text-stone-900'
              }`}
            >
              Ladies ({customers.filter((c) => c.gender === 'female').length})
            </button>
            <button
              onClick={() => setGenderFilter('male')}
              className={`px-3 py-1.5 text-xs font-semibold rounded-md transition-colors ${
                genderFilter === 'male' ? 'bg-white text-[#1B2A4A] shadow-xs' : 'text-stone-600 hover:text-stone-900'
              }`}
            >
              Gents ({customers.filter((c) => c.gender === 'male').length})
            </button>
          </div>

          <button
            onClick={() => onOpenCustomerModal()}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-white bg-[#C85A32] hover:bg-[#B34D29] rounded-lg shadow-sm transition-colors whitespace-nowrap"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Add Customer</span>
          </button>
        </div>
      </div>

      {/* Customer Directory Grid / Table */}
      {filteredCustomers.length === 0 ? (
        <div className="p-8 text-center bg-white rounded-xl border border-[#E8DEC8] space-y-3">
          <p className="text-sm font-semibold text-stone-700">No customers match your search criteria</p>
          <p className="text-xs text-stone-500">Try modifying your search term or add a new customer.</p>
          <button
            onClick={() => onOpenCustomerModal()}
            className="px-4 py-2 text-xs font-semibold text-white bg-[#C85A32] hover:bg-[#B34D29] rounded-lg inline-flex items-center gap-1.5"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Register New Client</span>
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {filteredCustomers.map((customer) => {
            const customerOrders = orders.filter((o) => o.customerId === customer.id);
            const customerMeasurements = measurements.filter((m) => m.customerId === customer.id);
            const pendingBalance = customerOrders.reduce((sum, o) => sum + (o.charges?.balanceAmount || 0), 0);

            return (
              <div
                key={customer.id}
                className="bg-white rounded-xl border border-[#E8DEC8] hover:border-[#C85A32]/40 shadow-xs p-4 flex flex-col justify-between transition-all"
              >
                <div>
                  {/* Top: Name & Badges */}
                  <div className="flex items-start justify-between gap-2 mb-2">
                    <div className="min-w-0">
                      <h3
                        onClick={() => onOpenCustomerDetail(customer)}
                        className="text-sm font-bold text-[#1B2A4A] hover:text-[#C85A32] cursor-pointer truncate"
                      >
                        {customer.name}
                      </h3>
                      <p className="text-[10px] text-stone-400 font-mono-data">ID: {customer.id}</p>
                    </div>

                    <div className="flex items-center gap-1 shrink-0">
                      <span className="px-2 py-0.5 rounded text-[10px] uppercase font-semibold tracking-wider bg-[#FAF6EE] text-stone-600 border border-[#E2D9CC]">
                        {customer.gender}
                      </span>
                    </div>
                  </div>

                  {/* Contact Info */}
                  <div className="space-y-1.5 text-xs text-stone-600 mb-3">
                    <div className="flex items-center gap-2">
                      <Phone className="w-3.5 h-3.5 text-stone-400 shrink-0" />
                      <span className="font-mono-data font-semibold text-stone-800">{customer.phone}</span>
                    </div>

                    {customer.email && (
                      <div className="flex items-center gap-2 truncate">
                        <Mail className="w-3.5 h-3.5 text-stone-400 shrink-0" />
                        <span className="truncate">{customer.email}</span>
                      </div>
                    )}

                    {customer.address && (
                      <div className="flex items-start gap-2 line-clamp-1">
                        <MapPin className="w-3.5 h-3.5 text-stone-400 shrink-0 mt-0.5" />
                        <span className="truncate">{customer.address}</span>
                      </div>
                    )}
                  </div>

                  {/* Metric Chips */}
                  <div className="grid grid-cols-3 gap-2 p-2 bg-[#FAF8F5] rounded-lg border border-[#EDE5D6] text-center text-[11px] mb-3">
                    <div>
                      <p className="text-[10px] text-stone-400 uppercase font-semibold">Orders</p>
                      <p className="font-mono-data font-bold text-stone-900">{customerOrders.length}</p>
                    </div>
                    <div>
                      <p className="text-[10px] text-stone-400 uppercase font-semibold">Specs</p>
                      <p className="font-mono-data font-bold text-stone-900">{customerMeasurements.length}</p>
                    </div>
                    <div>
                      <p className="text-[10px] text-stone-400 uppercase font-semibold">Balance</p>
                      <p
                        className={`font-mono-data font-bold ${
                          pendingBalance > 0 ? 'text-[#C85A32]' : 'text-emerald-700'
                        }`}
                      >
                        {formatINR(pendingBalance)}
                      </p>
                    </div>
                  </div>
                </div>

                {/* Bottom Actions */}
                <div className="pt-2 border-t border-[#F1ECE1] flex items-center justify-between gap-1 text-xs">
                  <div className="flex items-center gap-1">
                    <button
                      onClick={() => onOpenCustomerDetail(customer)}
                      className="p-1.5 text-stone-600 hover:text-[#1B2A4A] hover:bg-stone-100 rounded-md transition-colors"
                      title="View Profile & Measurement History"
                    >
                      <Eye className="w-3.5 h-3.5" />
                    </button>
                    <button
                      onClick={() => onOpenCustomerModal(customer)}
                      className="p-1.5 text-stone-600 hover:text-stone-900 hover:bg-stone-100 rounded-md transition-colors"
                      title="Edit Profile"
                    >
                      <Edit2 className="w-3.5 h-3.5" />
                    </button>
                    <button
                      onClick={() => onDeleteCustomer(customer)}
                      className="p-1.5 text-stone-400 hover:text-red-600 hover:bg-red-50 rounded-md transition-colors"
                      title="Delete Customer"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>

                  <div className="flex items-center gap-1.5">
                    <button
                      onClick={() => onNewMeasurementForCustomer(customer)}
                      className="px-2 py-1 text-[11px] font-medium text-[#1B2A4A] bg-[#EFE9DD] hover:bg-[#E4DBCB] rounded border border-[#D8CEBE] transition-colors"
                      title="Add Measurement Card"
                    >
                      + Spec
                    </button>
                    <button
                      onClick={() => onNewOrderForCustomer(customer)}
                      className="px-2 py-1 text-[11px] font-semibold text-white bg-[#C85A32] hover:bg-[#B34D29] rounded shadow-2xs transition-colors"
                      title="Create Stitching Order"
                    >
                      + Order
                    </button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};
