import React, { useState } from 'react';
import { Order, OrderStatus } from '../types';
import {
  CalendarDays,
  Clock,
  AlertTriangle,
  CheckCircle,
  Phone,
  Eye,
  Check,
  ChevronRight,
  Filter
} from 'lucide-react';
import {
  formatDate,
  formatINR,
  isOverdue,
  isToday,
  getDaysRemaining,
  getStatusLabel,
  getStatusColorClasses
} from '../utils/formatters';

interface DeliverySchedulePageProps {
  orders: Order[];
  onViewOrder: (order: Order) => void;
  onUpdateStatus: (orderId: string, status: OrderStatus) => void;
}

export const DeliverySchedulePage: React.FC<DeliverySchedulePageProps> = ({
  orders,
  onViewOrder,
  onUpdateStatus
}) => {
  const [scheduleFilter, setScheduleFilter] = useState<'all' | 'overdue' | 'today' | 'week'>('all');

  const pendingOrders = orders.filter((o) => o.status !== 'delivered');
  const overdueOrders = pendingOrders.filter((o) => isOverdue(o.deliveryDate, o.status));
  const todayOrders = pendingOrders.filter((o) => isToday(o.deliveryDate));
  
  const next7DaysOrders = pendingOrders.filter((o) => {
    const days = getDaysRemaining(o.deliveryDate);
    return days >= 0 && days <= 7;
  });

  const getFilteredList = () => {
    switch (scheduleFilter) {
      case 'overdue':
        return overdueOrders;
      case 'today':
        return todayOrders;
      case 'week':
        return next7DaysOrders;
      case 'all':
      default:
        // Sort by delivery date ascending
        return [...pendingOrders].sort((a, b) => a.deliveryDate.localeCompare(b.deliveryDate));
    }
  };

  const currentList = getFilteredList();

  return (
    <div className="space-y-5">
      {/* Overview Stat Strip */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3.5">
        <button
          onClick={() => setScheduleFilter('overdue')}
          className={`p-4 rounded-xl border text-left transition-all ${
            scheduleFilter === 'overdue'
              ? 'bg-red-50 border-red-300 ring-2 ring-red-400'
              : 'bg-white border-[#E8DEC8] hover:border-red-300'
          }`}
        >
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-semibold text-red-700 uppercase tracking-wider">
              Overdue
            </span>
            <AlertTriangle className="w-4 h-4 text-red-600" />
          </div>
          <p className="text-2xl font-bold text-red-700 mt-2 font-mono-data">
            {overdueOrders.length}
          </p>
          <p className="text-[11px] text-stone-500 mt-1">Past promised date</p>
        </button>

        <button
          onClick={() => setScheduleFilter('today')}
          className={`p-4 rounded-xl border text-left transition-all ${
            scheduleFilter === 'today'
              ? 'bg-amber-50 border-amber-300 ring-2 ring-amber-400'
              : 'bg-white border-[#E8DEC8] hover:border-amber-300'
          }`}
        >
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-semibold text-amber-800 uppercase tracking-wider">
              Due Today
            </span>
            <Clock className="w-4 h-4 text-amber-700" />
          </div>
          <p className="text-2xl font-bold text-amber-800 mt-2 font-mono-data">
            {todayOrders.length}
          </p>
          <p className="text-[11px] text-stone-500 mt-1">Scheduled for pickup today</p>
        </button>

        <button
          onClick={() => setScheduleFilter('week')}
          className={`p-4 rounded-xl border text-left transition-all ${
            scheduleFilter === 'week'
              ? 'bg-[#FAF6EE] border-[#C85A32] ring-2 ring-[#C85A32]/40'
              : 'bg-white border-[#E8DEC8] hover:border-[#C85A32]/50'
          }`}
        >
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-semibold text-[#1B2A4A] uppercase tracking-wider">
              Next 7 Days
            </span>
            <CalendarDays className="w-4 h-4 text-[#C85A32]" />
          </div>
          <p className="text-2xl font-bold text-[#1B2A4A] mt-2 font-mono-data">
            {next7DaysOrders.length}
          </p>
          <p className="text-[11px] text-stone-500 mt-1">Due within this week</p>
        </button>

        <button
          onClick={() => setScheduleFilter('all')}
          className={`p-4 rounded-xl border text-left transition-all ${
            scheduleFilter === 'all'
              ? 'bg-[#FAF6EE] border-[#1B2A4A] ring-2 ring-[#1B2A4A]/20'
              : 'bg-white border-[#E8DEC8] hover:border-stone-400'
          }`}
        >
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-semibold text-stone-600 uppercase tracking-wider">
              Total Pending
            </span>
            <CheckCircle className="w-4 h-4 text-stone-500" />
          </div>
          <p className="text-2xl font-bold text-[#1B2A4A] mt-2 font-mono-data">
            {pendingOrders.length}
          </p>
          <p className="text-[11px] text-stone-500 mt-1">All undelivered garments</p>
        </button>
      </div>

      {/* Schedule Items List */}
      <div className="bg-white rounded-xl border border-[#E8DEC8] shadow-xs overflow-hidden">
        <div className="p-4 border-b border-[#E8DEC8] flex items-center justify-between bg-[#FAF8F5]">
          <div>
            <h3 className="text-sm font-bold text-[#1B2A4A] tracking-tight">
              Customer Delivery & Fitting Calendar Queue
            </h3>
            <p className="text-xs text-stone-500 mt-0.5">
              Showing {currentList.length} scheduled order{currentList.length > 1 ? 's' : ''} sorted chronologically
            </p>
          </div>

          <div className="text-xs text-stone-500 font-mono-data">
            Filter: <strong className="capitalize text-stone-800">{scheduleFilter}</strong>
          </div>
        </div>

        {currentList.length === 0 ? (
          <div className="p-10 text-center text-stone-400 text-xs">
            No orders match the selected schedule timeline filter.
          </div>
        ) : (
          <div className="divide-y divide-[#F1EBE0]">
            {currentList.map((order) => {
              const overdue = isOverdue(order.deliveryDate, order.status);
              const dueToday = isToday(order.deliveryDate);
              const daysLeft = getDaysRemaining(order.deliveryDate);
              const statusStyle = getStatusColorClasses(order.status);

              return (
                <div
                  key={order.id}
                  className={`p-4 hover:bg-[#FAF6EE] transition-colors flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 ${
                    overdue ? 'bg-red-50/30' : dueToday ? 'bg-amber-50/20' : ''
                  }`}
                >
                  {/* Left: Date Badge & Details */}
                  <div className="flex items-start gap-4 min-w-0">
                    <div
                      className={`w-14 text-center p-2 rounded-lg border shrink-0 ${
                        overdue
                          ? 'bg-red-50 border-red-200 text-red-800'
                          : dueToday
                          ? 'bg-amber-50 border-amber-200 text-amber-900'
                          : 'bg-[#FAF6EE] border-[#E2D9CC] text-stone-700'
                      }`}
                    >
                      <p className="text-[10px] uppercase font-bold tracking-wider leading-none">
                        {new Date(order.deliveryDate).toLocaleDateString('en-IN', { month: 'short' })}
                      </p>
                      <p className="text-lg font-bold font-mono-data leading-tight mt-0.5">
                        {new Date(order.deliveryDate).getDate()}
                      </p>
                      <p className="text-[9px] uppercase font-semibold leading-none mt-0.5">
                        {overdue ? 'Late' : dueToday ? 'Today' : `${daysLeft}d`}
                      </p>
                    </div>

                    <div className="min-w-0">
                      <div className="flex items-center gap-2">
                        <span className="font-mono-data font-bold text-xs text-stone-900">{order.id}</span>
                        <span className="text-stone-300">·</span>
                        <span className="text-xs font-bold text-[#1B2A4A] truncate">{order.customerName}</span>
                        <span className="text-stone-300 hidden sm:inline">·</span>
                        <span className="text-[11px] text-stone-500 font-mono-data hidden sm:inline">{order.customerPhone}</span>
                      </div>

                      <p className="text-xs text-stone-700 font-medium mt-1 truncate">
                        {order.garmentDescription}
                      </p>

                      <div className="flex flex-wrap items-center gap-3 text-[11px] text-stone-500 mt-1.5">
                        <span>
                          Target: <strong className="text-stone-700 font-mono-data">{formatDate(order.deliveryDate)}</strong>
                        </span>
                        {order.trialDate && (
                          <span>
                            Trial: <strong className="text-stone-700 font-mono-data">{formatDate(order.trialDate)}</strong>
                          </span>
                        )}
                        <span>
                          Total: <strong className="text-stone-800 font-mono-data">{formatINR(order.charges.totalAmount)}</strong>
                        </span>
                        {order.charges.balanceAmount > 0 && (
                          <span className="text-[#C85A32] font-semibold font-mono-data">
                            Collect Due: {formatINR(order.charges.balanceAmount)}
                          </span>
                        )}
                      </div>
                    </div>
                  </div>

                  {/* Right: Stage Badge & Fast Delivery Button */}
                  <div className="flex items-center gap-2 self-end sm:self-center shrink-0">
                    <span
                      className={`px-2.5 py-1 rounded text-xs font-semibold uppercase tracking-wider border ${statusStyle.bg} ${statusStyle.text} ${statusStyle.border}`}
                    >
                      {getStatusLabel(order.status)}
                    </span>

                    <button
                      onClick={() => onViewOrder(order)}
                      className="p-1.5 text-stone-600 hover:text-stone-900 rounded hover:bg-stone-100"
                      title="View Invoice & Job Card"
                    >
                      <Eye className="w-4 h-4" />
                    </button>

                    {order.status !== 'delivered' && (
                      <button
                        onClick={() => onUpdateStatus(order.id, 'delivered')}
                        className="px-3 py-1.5 text-xs font-semibold text-white bg-emerald-700 hover:bg-emerald-800 rounded-lg shadow-2xs transition-colors flex items-center gap-1.5 whitespace-nowrap"
                      >
                        <Check className="w-3.5 h-3.5" />
                        <span>Mark Delivered</span>
                      </button>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
};
