import React from 'react';
import {
  Users,
  ShoppingBag,
  Clock,
  CheckCircle2,
  AlertTriangle,
  IndianRupee,
  Calendar,
  ArrowRight,
  TrendingUp,
  Scissors,
  Plus,
  Receipt,
  Boxes,
  Eye
} from 'lucide-react';
import { Customer, Order, InventoryItem, OrderStatus } from '../types';
import {
  formatINR,
  formatDate,
  isToday,
  isOverdue,
  getStatusLabel,
  getStatusColorClasses,
  getPriorityBadge
} from '../utils/formatters';
import { ActiveTab } from '../components/layout/Sidebar';

interface DashboardPageProps {
  customers: Customer[];
  orders: Order[];
  inventory: InventoryItem[];
  setActiveTab: (tab: ActiveTab) => void;
  onNewOrder: () => void;
  onNewCustomer: () => void;
  onViewOrder: (order: Order) => void;
  onUpdateOrderStatus: (orderId: string, status: OrderStatus) => void;
}

export const DashboardPage: React.FC<DashboardPageProps> = ({
  customers,
  orders,
  inventory,
  setActiveTab,
  onNewOrder,
  onNewCustomer,
  onViewOrder,
  onUpdateOrderStatus
}) => {
  // Calculations
  const totalCustomers = customers.length;
  const activeOrders = orders.filter((o) => o.status !== 'delivered');
  const inProgressCount = orders.filter((o) => ['cutting', 'stitching', 'trial'].includes(o.status)).length;
  const readyCount = orders.filter((o) => o.status === 'ready').length;
  const deliveredCount = orders.filter((o) => o.status === 'delivered').length;
  const overdueOrders = orders.filter((o) => isOverdue(o.deliveryDate, o.status));

  const totalRevenue = orders.reduce((sum, o) => sum + (o.charges?.totalAmount || 0), 0);
  const totalAdvance = orders.reduce((sum, o) => sum + (o.charges?.advancePaid || 0), 0);
  const totalBalanceDue = orders.reduce((sum, o) => sum + (o.charges?.balanceAmount || 0), 0);

  const lowStockItems = inventory.filter((i) => i.quantity <= i.minThreshold);
  const todayDeliveries = orders.filter((o) => isToday(o.deliveryDate) && o.status !== 'delivered');
  const todayTrials = orders.filter((o) => o.trialDate && isToday(o.trialDate) && o.status !== 'delivered');

  // Pipeline stage counts
  const stageCounts: Record<OrderStatus, number> = {
    received: orders.filter((o) => o.status === 'received').length,
    cutting: orders.filter((o) => o.status === 'cutting').length,
    stitching: orders.filter((o) => o.status === 'stitching').length,
    trial: orders.filter((o) => o.status === 'trial').length,
    ready: orders.filter((o) => o.status === 'ready').length,
    delivered: orders.filter((o) => o.status === 'delivered').length
  };

  return (
    <div className="space-y-6">
      {/* Overdue Urgent Alert Banner */}
      {overdueOrders.length > 0 && (
        <div className="p-4 rounded-xl bg-red-50 border border-red-200 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 shadow-xs">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-lg bg-red-100 text-red-700 shrink-0">
              <AlertTriangle className="w-5 h-5" />
            </div>
            <div>
              <h4 className="text-xs font-bold text-red-900 tracking-tight">
                {overdueOrders.length} Stitching Order{overdueOrders.length > 1 ? 's' : ''} Past Promised Delivery Date
              </h4>
              <p className="text-[11px] text-red-700 mt-0.5">
                Urgent attention required. Fast-track cutting & stitching to avoid customer delays.
              </p>
            </div>
          </div>
          <button
            onClick={() => setActiveTab('deliveries')}
            className="px-3 py-1.5 text-xs font-semibold text-red-800 bg-red-100 hover:bg-red-200 rounded-lg transition-colors flex items-center gap-1.5 whitespace-nowrap self-end sm:self-center"
          >
            <span>View Overdue Queue</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>
      )}

      {/* KPI Stats Strip */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3.5">
        <div className="p-4 rounded-xl bg-white border border-[#E8DEC8] shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-semibold text-stone-500 uppercase tracking-wider">
              Total Clients
            </span>
            <div className="p-1.5 rounded-lg bg-[#FAF6EE] text-[#1B2A4A]">
              <Users className="w-4 h-4" />
            </div>
          </div>
          <p className="text-2xl font-bold text-[#1B2A4A] mt-2 font-mono-data">
            {totalCustomers}
          </p>
          <p className="text-[11px] text-stone-500 mt-1 flex items-center gap-1">
            <span>{activeOrders.length} active orders pending</span>
          </p>
        </div>

        <div className="p-4 rounded-xl bg-white border border-[#E8DEC8] shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-semibold text-stone-500 uppercase tracking-wider">
              In Production
            </span>
            <div className="p-1.5 rounded-lg bg-amber-50 text-amber-700">
              <Clock className="w-4 h-4" />
            </div>
          </div>
          <p className="text-2xl font-bold text-amber-800 mt-2 font-mono-data">
            {inProgressCount}
          </p>
          <p className="text-[11px] text-stone-500 mt-1">
            Cutting · Stitching · Trials
          </p>
        </div>

        <div className="p-4 rounded-xl bg-white border border-[#E8DEC8] shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-semibold text-stone-500 uppercase tracking-wider">
              Ready for Pickup
            </span>
            <div className="p-1.5 rounded-lg bg-emerald-50 text-emerald-700">
              <CheckCircle2 className="w-4 h-4" />
            </div>
          </div>
          <p className="text-2xl font-bold text-emerald-700 mt-2 font-mono-data">
            {readyCount}
          </p>
          <p className="text-[11px] text-stone-500 mt-1">
            {deliveredCount} delivered this month
          </p>
        </div>

        <div className="p-4 rounded-xl bg-white border border-[#E8DEC8] shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-semibold text-stone-500 uppercase tracking-wider">
              Balance Pending
            </span>
            <div className="p-1.5 rounded-lg bg-orange-50 text-[#C85A32]">
              <IndianRupee className="w-4 h-4" />
            </div>
          </div>
          <p className="text-2xl font-bold text-[#C85A32] mt-2 font-mono-data">
            {formatINR(totalBalanceDue)}
          </p>
          <p className="text-[11px] text-stone-500 mt-1">
            Total Revenue: <strong className="font-mono-data text-stone-700">{formatINR(totalRevenue)}</strong>
          </p>
        </div>
      </div>

      {/* Production Pipeline Progress Tracker */}
      <div className="p-5 rounded-xl bg-white border border-[#E8DEC8] shadow-xs">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h3 className="text-sm font-bold text-[#1B2A4A] tracking-tight">
              Garment Production Lifecycle Pipeline
            </h3>
            <p className="text-xs text-stone-500 mt-0.5">
              Live distribution of active customer garments across shop workstations
            </p>
          </div>
          <button
            onClick={() => setActiveTab('tracking')}
            className="text-xs font-semibold text-[#C85A32] hover:text-[#B34D29] flex items-center gap-1"
          >
            <span>Open Kanban Board</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-2.5">
          {(
            [
              { id: 'received', label: 'Received', count: stageCounts.received, color: 'border-stone-300 bg-stone-50 text-stone-700' },
              { id: 'cutting', label: 'Cutting', count: stageCounts.cutting, color: 'border-orange-200 bg-orange-50 text-orange-800' },
              { id: 'stitching', label: 'Stitching', count: stageCounts.stitching, color: 'border-blue-200 bg-blue-50 text-blue-800' },
              { id: 'trial', label: 'Trial / Alter', count: stageCounts.trial, color: 'border-purple-200 bg-purple-50 text-purple-800' },
              { id: 'ready', label: 'Ready', count: stageCounts.ready, color: 'border-emerald-200 bg-emerald-50 text-emerald-800' },
              { id: 'delivered', label: 'Delivered', count: stageCounts.delivered, color: 'border-slate-200 bg-slate-50 text-slate-700' }
            ] as const
          ).map((stage) => (
            <div
              key={stage.id}
              onClick={() => setActiveTab('tracking')}
              className={`p-3 rounded-lg border text-center cursor-pointer transition-all hover:scale-[1.02] ${stage.color}`}
            >
              <p className="text-[11px] font-semibold uppercase tracking-wider">{stage.label}</p>
              <p className="text-xl font-bold font-mono-data mt-1">{stage.count}</p>
            </div>
          ))}
        </div>
      </div>

      {/* Two Column Layout: Recent Orders & Today's Schedule */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left (2 cols): Active Stitching Orders Table */}
        <div className="lg:col-span-2 space-y-4">
          <div className="p-5 rounded-xl bg-white border border-[#E8DEC8] shadow-xs">
            <div className="flex items-center justify-between mb-4">
              <div>
                <h3 className="text-sm font-bold text-[#1B2A4A] tracking-tight">
                  Active Stitching Job Orders
                </h3>
                <p className="text-xs text-stone-500 mt-0.5">
                  Recent tailor work tickets and delivery deadlines
                </p>
              </div>
              <button
                onClick={() => setActiveTab('orders')}
                className="text-xs font-semibold text-[#C85A32] hover:text-[#B34D29] flex items-center gap-1"
              >
                <span>All Orders</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-xs text-left">
                <thead>
                  <tr className="border-b border-[#E8DEC8] text-stone-400 font-semibold text-[11px] uppercase tracking-wider bg-[#FAF8F5]">
                    <th className="py-2.5 px-3">Order ID</th>
                    <th className="py-2.5 px-3">Client</th>
                    <th className="py-2.5 px-3">Garment & Fabric</th>
                    <th className="py-2.5 px-3">Due Date</th>
                    <th className="py-2.5 px-3">Status</th>
                    <th className="py-2.5 px-3 text-right">Balance</th>
                    <th className="py-2.5 px-3 text-right">Action</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#F1EBE0]">
                  {orders.slice(0, 6).map((order) => {
                    const statusStyle = getStatusColorClasses(order.status);
                    const overdue = isOverdue(order.deliveryDate, order.status);
                    return (
                      <tr key={order.id} className="hover:bg-[#FAF6EE] transition-colors">
                        <td className="py-3 px-3 font-mono-data font-bold text-stone-900">
                          {order.id}
                        </td>
                        <td className="py-3 px-3">
                          <p className="font-semibold text-stone-900">{order.customerName}</p>
                          <p className="text-[10px] text-stone-500 font-mono-data">{order.customerPhone}</p>
                        </td>
                        <td className="py-3 px-3 max-w-[180px]">
                          <p className="font-medium text-stone-800 truncate">{order.garmentDescription}</p>
                          <p className="text-[10px] text-stone-400 capitalize">
                            {order.garmentType} · {order.fabricDetails.fabricType}
                          </p>
                        </td>
                        <td className="py-3 px-3 whitespace-nowrap">
                          <span
                            className={`font-mono-data ${
                              overdue ? 'text-red-700 font-bold' : isToday(order.deliveryDate) ? 'text-amber-700 font-bold' : 'text-stone-700'
                            }`}
                          >
                            {formatDate(order.deliveryDate)}
                          </span>
                          {overdue && (
                            <span className="block text-[10px] text-red-600 font-semibold">Overdue</span>
                          )}
                        </td>
                        <td className="py-3 px-3 whitespace-nowrap">
                          <span
                            className={`px-2 py-0.5 rounded text-[10px] font-semibold uppercase tracking-wider border ${statusStyle.bg} ${statusStyle.text} ${statusStyle.border}`}
                          >
                            {getStatusLabel(order.status)}
                          </span>
                        </td>
                        <td className="py-3 px-3 text-right font-mono-data font-semibold whitespace-nowrap">
                          {order.charges.balanceAmount > 0 ? (
                            <span className="text-[#C85A32]">{formatINR(order.charges.balanceAmount)}</span>
                          ) : (
                            <span className="text-emerald-700">Paid</span>
                          )}
                        </td>
                        <td className="py-3 px-3 text-right whitespace-nowrap">
                          <button
                            onClick={() => onViewOrder(order)}
                            className="p-1 text-stone-500 hover:text-[#1B2A4A] rounded hover:bg-stone-200/50"
                            title="View / Print Order"
                          >
                            <Eye className="w-4 h-4" />
                          </button>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>
        </div>

        {/* Right (1 col): Today's Schedule & Low Stock Alerts */}
        <div className="space-y-4">
          {/* Today's Queue */}
          <div className="p-5 rounded-xl bg-white border border-[#E8DEC8] shadow-xs">
            <div className="flex items-center justify-between mb-3">
              <h3 className="text-sm font-bold text-[#1B2A4A] tracking-tight flex items-center gap-2">
                <Calendar className="w-4 h-4 text-[#C85A32]" />
                <span>Today's Customer Queue</span>
              </h3>
              <span className="text-[10px] font-mono-data px-1.5 py-0.5 rounded bg-stone-100 text-stone-600">
                {todayDeliveries.length + todayTrials.length} events
              </span>
            </div>

            {todayDeliveries.length === 0 && todayTrials.length === 0 ? (
              <p className="text-xs text-stone-500 py-3 text-center">
                No orders scheduled for delivery or trial today.
              </p>
            ) : (
              <div className="space-y-2.5">
                {todayDeliveries.map((ord) => (
                  <div
                    key={ord.id}
                    onClick={() => onViewOrder(ord)}
                    className="p-2.5 rounded-lg bg-[#FAF6EE] border border-[#E8DEC8] hover:border-[#C85A32]/50 cursor-pointer transition-colors"
                  >
                    <div className="flex items-center justify-between">
                      <span className="text-[10px] font-bold uppercase tracking-wider text-emerald-800">
                        Delivery Today
                      </span>
                      <span className="text-[10px] font-mono-data text-stone-500">{ord.id}</span>
                    </div>
                    <p className="text-xs font-bold text-stone-900 mt-1">{ord.customerName}</p>
                    <p className="text-[11px] text-stone-600 truncate">{ord.garmentDescription}</p>
                  </div>
                ))}

                {todayTrials.map((ord) => (
                  <div
                    key={`trial-${ord.id}`}
                    onClick={() => onViewOrder(ord)}
                    className="p-2.5 rounded-lg bg-purple-50/60 border border-purple-200 hover:border-purple-300 cursor-pointer transition-colors"
                  >
                    <div className="flex items-center justify-between">
                      <span className="text-[10px] font-bold uppercase tracking-wider text-purple-800">
                        Fitting / Trial Today
                      </span>
                      <span className="text-[10px] font-mono-data text-stone-500">{ord.id}</span>
                    </div>
                    <p className="text-xs font-bold text-stone-900 mt-1">{ord.customerName}</p>
                    <p className="text-[11px] text-stone-600 truncate">{ord.garmentDescription}</p>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Low Stock Material Warnings */}
          <div className="p-5 rounded-xl bg-white border border-[#E8DEC8] shadow-xs">
            <div className="flex items-center justify-between mb-3">
              <h3 className="text-sm font-bold text-[#1B2A4A] tracking-tight flex items-center gap-2">
                <Boxes className="w-4 h-4 text-amber-600" />
                <span>Low Stock Materials</span>
              </h3>
              <button
                onClick={() => setActiveTab('inventory')}
                className="text-[11px] text-[#C85A32] font-semibold hover:underline"
              >
                Manage
              </button>
            </div>

            {lowStockItems.length === 0 ? (
              <p className="text-xs text-stone-500 py-3 text-center">
                All threads, fabrics, and trims are well stocked.
              </p>
            ) : (
              <div className="space-y-2">
                {lowStockItems.slice(0, 4).map((item) => (
                  <div
                    key={item.id}
                    className="p-2.5 rounded-lg bg-amber-50/60 border border-amber-200 flex items-center justify-between gap-2 text-xs"
                  >
                    <div className="min-w-0">
                      <p className="font-semibold text-stone-900 truncate">{item.name}</p>
                      <p className="text-[10px] text-stone-500 capitalize">{item.category} · {item.color || 'Standard'}</p>
                    </div>
                    <span className="font-mono-data font-bold text-amber-800 text-xs shrink-0">
                      {item.quantity} / {item.minThreshold} {item.unit}
                    </span>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Quick Shortcuts */}
          <div className="p-4 rounded-xl bg-[#1B2A4A] text-white shadow-xs space-y-2">
            <p className="text-xs font-bold tracking-tight">Quick Tailor Actions</p>
            <div className="grid grid-cols-2 gap-2 pt-1">
              <button
                onClick={onNewOrder}
                className="py-2 px-3 text-xs font-semibold bg-[#C85A32] hover:bg-[#B34D29] text-white rounded-lg flex items-center justify-center gap-1.5 transition-colors"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>New Order</span>
              </button>
              <button
                onClick={onNewCustomer}
                className="py-2 px-3 text-xs font-semibold bg-[#2B3E68] hover:bg-[#384E7D] text-white rounded-lg flex items-center justify-center gap-1.5 transition-colors"
              >
                <Users className="w-3.5 h-3.5" />
                <span>New Client</span>
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
