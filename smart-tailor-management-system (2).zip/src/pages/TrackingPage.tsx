import React from 'react';
import { Order, OrderStatus } from '../types';
import {
  ChevronRight,
  ChevronLeft,
  Calendar,
  AlertTriangle,
  CheckCircle2,
  Eye,
  Scissors,
  UserCheck,
  PackageCheck,
  ShoppingBag
} from 'lucide-react';
import {
  formatDate,
  formatINR,
  isOverdue,
  isToday,
  getPriorityBadge,
  getDaysRemaining
} from '../utils/formatters';

interface TrackingPageProps {
  orders: Order[];
  onUpdateStatus: (orderId: string, status: OrderStatus) => void;
  onViewOrder: (order: Order) => void;
}

export const TrackingPage: React.FC<TrackingPageProps> = ({
  orders,
  onUpdateStatus,
  onViewOrder
}) => {
  const columns: { id: OrderStatus; title: string; color: string; headerBg: string }[] = [
    { id: 'received', title: 'Order Received', color: 'border-stone-300 text-stone-700', headerBg: 'bg-stone-100' },
    { id: 'cutting', title: 'Cutting Station', color: 'border-orange-300 text-orange-800', headerBg: 'bg-orange-50' },
    { id: 'stitching', title: 'Stitching Floor', color: 'border-blue-300 text-blue-800', headerBg: 'bg-blue-50' },
    { id: 'trial', title: 'Trial & Alterations', color: 'border-purple-300 text-purple-800', headerBg: 'bg-purple-50' },
    { id: 'ready', title: 'Ready for Pickup', color: 'border-emerald-300 text-emerald-800', headerBg: 'bg-emerald-50' },
    { id: 'delivered', title: 'Delivered', color: 'border-slate-300 text-slate-700', headerBg: 'bg-slate-100' }
  ];

  const getNextStatus = (current: OrderStatus): OrderStatus | null => {
    switch (current) {
      case 'received': return 'cutting';
      case 'cutting': return 'stitching';
      case 'stitching': return 'trial';
      case 'trial': return 'ready';
      case 'ready': return 'delivered';
      case 'delivered': return null;
      default: return null;
    }
  };

  const getPrevStatus = (current: OrderStatus): OrderStatus | null => {
    switch (current) {
      case 'delivered': return 'ready';
      case 'ready': return 'trial';
      case 'trial': return 'stitching';
      case 'stitching': return 'cutting';
      case 'cutting': return 'received';
      case 'received': return null;
      default: return null;
    }
  };

  return (
    <div className="space-y-4">
      {/* Informative Header Strip */}
      <div className="bg-white p-4 rounded-xl border border-[#E8DEC8] flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 shadow-xs">
        <div>
          <h3 className="text-sm font-bold text-[#1B2A4A] tracking-tight">
            Tailor Shop Production Pipeline (Kanban Board)
          </h3>
          <p className="text-xs text-stone-500 mt-0.5">
            Advance orders through workstations using the arrows or review customer fit instructions
          </p>
        </div>

        <div className="flex items-center gap-4 text-xs font-medium text-stone-600">
          <span className="flex items-center gap-1.5">
            <span className="w-2.5 h-2.5 rounded-full bg-red-500" />
            Overdue
          </span>
          <span className="flex items-center gap-1.5">
            <span className="w-2.5 h-2.5 rounded-full bg-amber-500" />
            Due Today
          </span>
          <span className="flex items-center gap-1.5">
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-500" />
            On Schedule
          </span>
        </div>
      </div>

      {/* 6 Kanban Columns */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-6 gap-3.5 items-start">
        {columns.map((col) => {
          const stageOrders = orders.filter((o) => o.status === col.id);
          return (
            <div
              key={col.id}
              className="bg-[#FAF8F5] rounded-xl border border-[#E8DEC8] flex flex-col max-h-[calc(100vh-220px)] overflow-hidden shadow-xs"
            >
              {/* Column Header */}
              <div className={`p-3 border-b border-[#E8DEC8] ${col.headerBg} flex items-center justify-between`}>
                <span className="text-xs font-bold text-[#1B2A4A] tracking-tight truncate">
                  {col.title}
                </span>
                <span className="px-2 py-0.5 bg-white border border-[#D5C9B3] rounded-full text-[10px] font-mono-data font-bold text-stone-700">
                  {stageOrders.length}
                </span>
              </div>

              {/* Cards List */}
              <div className="p-2 space-y-2.5 overflow-y-auto flex-1">
                {stageOrders.length === 0 ? (
                  <div className="py-8 text-center text-stone-400 text-xs">
                    No garments currently in {col.title.toLowerCase()}
                  </div>
                ) : (
                  stageOrders.map((order) => {
                    const overdue = isOverdue(order.deliveryDate, order.status);
                    const dueToday = isToday(order.deliveryDate);
                    const daysLeft = getDaysRemaining(order.deliveryDate);
                    const priorityBadge = getPriorityBadge(order.priority);
                    const nextStage = getNextStatus(order.status);
                    const prevStage = getPrevStatus(order.status);

                    return (
                      <div
                        key={order.id}
                        className={`bg-white p-3 rounded-lg border transition-all shadow-2xs hover:shadow-xs ${
                          overdue
                            ? 'border-red-300 ring-1 ring-red-200'
                            : dueToday
                            ? 'border-amber-300 ring-1 ring-amber-200'
                            : 'border-[#E8DEC8]'
                        }`}
                      >
                        {/* Top ID & Priority */}
                        <div className="flex items-center justify-between gap-1 mb-1.5">
                          <span className="font-mono-data font-bold text-xs text-stone-900">
                            {order.id}
                          </span>
                          <span
                            className={`px-1.5 py-0.2 rounded text-[9px] font-semibold uppercase tracking-wider border ${priorityBadge.classes}`}
                          >
                            {order.priority}
                          </span>
                        </div>

                        {/* Customer & Garment */}
                        <p className="text-xs font-bold text-stone-900 truncate">
                          {order.customerName}
                        </p>
                        <p className="text-[11px] text-stone-600 line-clamp-2 mt-0.5 font-medium leading-tight">
                          {order.garmentDescription}
                        </p>
                        <p className="text-[10px] text-stone-400 mt-1 capitalize truncate">
                          {order.fabricDetails.fabricType} · {order.quantity} pc{order.quantity > 1 ? 's' : ''}
                        </p>

                        {/* Delivery countdown tag */}
                        <div className="mt-2 pt-2 border-t border-stone-100 flex items-center justify-between text-[10px]">
                          <span
                            className={`font-mono-data font-semibold ${
                              overdue
                                ? 'text-red-700'
                                : dueToday
                                ? 'text-amber-700'
                                : 'text-stone-500'
                            }`}
                          >
                            {overdue
                              ? 'Overdue'
                              : dueToday
                              ? 'Due Today'
                              : `${daysLeft}d left (${formatDate(order.deliveryDate)})`}
                          </span>

                          <span className="font-mono-data font-semibold text-stone-700">
                            {formatINR(order.charges.totalAmount)}
                          </span>
                        </div>

                        {order.assignedTailor && (
                          <div className="mt-1 text-[10px] text-stone-500 truncate">
                            Tailor: <strong className="text-stone-700">{order.assignedTailor}</strong>
                          </div>
                        )}

                        {/* Move Pipeline Buttons */}
                        <div className="mt-2.5 pt-2 border-t border-stone-100 flex items-center justify-between gap-1">
                          <button
                            onClick={() => onViewOrder(order)}
                            className="p-1 text-stone-500 hover:text-stone-900 rounded hover:bg-stone-100"
                            title="View Garment Details & Invoice"
                          >
                            <Eye className="w-3.5 h-3.5" />
                          </button>

                          <div className="flex items-center gap-1">
                            {prevStage && (
                              <button
                                onClick={() => onUpdateStatus(order.id, prevStage)}
                                className="px-1.5 py-1 text-[10px] font-semibold text-stone-600 bg-stone-100 hover:bg-stone-200 rounded flex items-center gap-0.5 transition-colors"
                                title={`Move back to ${prevStage}`}
                              >
                                <ChevronLeft className="w-3 h-3" />
                                <span>Prev</span>
                              </button>
                            )}

                            {nextStage && (
                              <button
                                onClick={() => onUpdateStatus(order.id, nextStage)}
                                className="px-2 py-1 text-[10px] font-semibold text-white bg-[#C85A32] hover:bg-[#B34D29] rounded flex items-center gap-0.5 shadow-2xs transition-colors"
                                title={`Advance to ${nextStage}`}
                              >
                                <span>Advance</span>
                                <ChevronRight className="w-3 h-3" />
                              </button>
                            )}
                          </div>
                        </div>
                      </div>
                    );
                  })
                )}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
