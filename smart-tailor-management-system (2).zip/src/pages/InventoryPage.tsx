import React, { useState } from 'react';
import { InventoryCategory, InventoryItem } from '../types';
import {
  Boxes,
  Plus,
  Search,
  AlertTriangle,
  Edit2,
  Trash2,
  SlidersHorizontal,
  PackagePlus,
  PackageMinus
} from 'lucide-react';
import { formatINR } from '../utils/formatters';

interface InventoryPageProps {
  inventory: InventoryItem[];
  onOpenInventoryModal: (item?: InventoryItem) => void;
  onOpenStockAdjustModal: (item: InventoryItem) => void;
  onDeleteInventoryItem: (item: InventoryItem) => void;
}

export const InventoryPage: React.FC<InventoryPageProps> = ({
  inventory,
  onOpenInventoryModal,
  onOpenStockAdjustModal,
  onDeleteInventoryItem
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [categoryFilter, setCategoryFilter] = useState<'all' | InventoryCategory>('all');
  const [showOnlyLowStock, setShowOnlyLowStock] = useState(false);

  const lowStockCount = inventory.filter((i) => i.quantity <= i.minThreshold).length;
  const totalValuation = inventory.reduce((sum, i) => sum + i.quantity * i.costPerUnit, 0);

  const filteredItems = inventory.filter((item) => {
    const matchesSearch =
      item.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (item.color && item.color.toLowerCase().includes(searchQuery.toLowerCase())) ||
      (item.supplier && item.supplier.toLowerCase().includes(searchQuery.toLowerCase()));
    const matchesCategory = categoryFilter === 'all' || item.category === categoryFilter;
    const matchesLowStock = !showOnlyLowStock || item.quantity <= item.minThreshold;
    return matchesSearch && matchesCategory && matchesLowStock;
  });

  return (
    <div className="space-y-5">
      {/* Low Stock Warning Banner if any items low */}
      {lowStockCount > 0 && (
        <div className="p-4 rounded-xl bg-amber-50 border border-amber-200 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 shadow-xs">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-lg bg-amber-100 text-amber-800 shrink-0">
              <AlertTriangle className="w-5 h-5" />
            </div>
            <div>
              <h4 className="text-xs font-bold text-amber-900 tracking-tight">
                {lowStockCount} Material Item{lowStockCount > 1 ? 's' : ''} Below Minimum Reorder Threshold
              </h4>
              <p className="text-[11px] text-amber-700 mt-0.5">
                Certain threads, linings, or zippers need urgent restocking to prevent tailoring delays.
              </p>
            </div>
          </div>
          <button
            onClick={() => setShowOnlyLowStock(!showOnlyLowStock)}
            className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-colors whitespace-nowrap self-end sm:self-center ${
              showOnlyLowStock
                ? 'bg-amber-800 text-white'
                : 'bg-amber-100 text-amber-900 hover:bg-amber-200'
            }`}
          >
            {showOnlyLowStock ? 'Showing Low Stock (Clear)' : 'Filter Low Stock Items'}
          </button>
        </div>
      )}

      {/* KPI strip */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="p-4 rounded-xl bg-white border border-[#E8DEC8] shadow-xs">
          <span className="text-[11px] font-semibold text-stone-500 uppercase tracking-wider">
            Total Material SKUs
          </span>
          <p className="text-2xl font-bold text-[#1B2A4A] mt-2 font-mono-data">
            {inventory.length}
          </p>
          <p className="text-[11px] text-stone-500 mt-1">Across fabrics, threads, buttons & trims</p>
        </div>

        <div className="p-4 rounded-xl bg-white border border-[#E8DEC8] shadow-xs">
          <span className="text-[11px] font-semibold text-stone-500 uppercase tracking-wider">
            Low Stock Alerts
          </span>
          <p className={`text-2xl font-bold mt-2 font-mono-data ${lowStockCount > 0 ? 'text-amber-700' : 'text-emerald-700'}`}>
            {lowStockCount}
          </p>
          <p className="text-[11px] text-stone-500 mt-1">Items at or below reorder level</p>
        </div>

        <div className="p-4 rounded-xl bg-white border border-[#E8DEC8] shadow-xs">
          <span className="text-[11px] font-semibold text-stone-500 uppercase tracking-wider">
            Total Inventory Valuation
          </span>
          <p className="text-2xl font-bold text-[#1B2A4A] mt-2 font-mono-data">
            {formatINR(totalValuation)}
          </p>
          <p className="text-[11px] text-stone-500 mt-1">Estimated raw materials value</p>
        </div>
      </div>

      {/* Toolbar */}
      <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3 bg-white p-4 rounded-xl border border-[#E8DEC8] shadow-xs">
        <div className="flex-1 relative">
          <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-stone-400" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search material by name, color code, or supplier..."
            className="w-full pl-9 pr-3 py-2 text-xs bg-[#FAF8F5] border border-[#D5C9B3] rounded-lg focus:outline-none focus:ring-2 focus:ring-[#C85A32]/30 focus:border-[#C85A32]"
          />
        </div>

        <div className="flex items-center gap-2">
          <select
            value={categoryFilter}
            onChange={(e) => setCategoryFilter(e.target.value as any)}
            className="px-3 py-2 text-xs bg-[#FAF6EE] border border-[#D5C9B3] rounded-lg text-[#1B2A4A] font-semibold"
          >
            <option value="all">All Categories</option>
            <option value="fabric">Fabrics</option>
            <option value="thread">Threads</option>
            <option value="button">Buttons & Hooks</option>
            <option value="zipper">Zippers</option>
            <option value="lining">Linings</option>
            <option value="accessory">Accessories & Laces</option>
          </select>

          <button
            onClick={() => onOpenInventoryModal()}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-white bg-[#C85A32] hover:bg-[#B34D29] rounded-lg shadow-sm transition-colors whitespace-nowrap"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Add Material</span>
          </button>
        </div>
      </div>

      {/* Inventory Table */}
      {filteredItems.length === 0 ? (
        <div className="p-8 text-center bg-white rounded-xl border border-[#E8DEC8] space-y-3">
          <p className="text-sm font-semibold text-stone-700">No materials match the filter</p>
          <p className="text-xs text-stone-500">Add materials or clear filters to view all trims.</p>
          <button
            onClick={() => onOpenInventoryModal()}
            className="px-4 py-2 text-xs font-semibold text-white bg-[#C85A32] hover:bg-[#B34D29] rounded-lg inline-flex items-center gap-1.5"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Add New Item</span>
          </button>
        </div>
      ) : (
        <div className="bg-white rounded-xl border border-[#E8DEC8] shadow-xs overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-xs text-left">
              <thead>
                <tr className="border-b border-[#E8DEC8] text-stone-400 font-semibold text-[11px] uppercase tracking-wider bg-[#FAF8F5]">
                  <th className="py-3 px-4">Material & Category</th>
                  <th className="py-3 px-4">Color / Shade</th>
                  <th className="py-3 px-4">Current Stock</th>
                  <th className="py-3 px-4">Min Threshold</th>
                  <th className="py-3 px-4 text-right">Unit Cost</th>
                  <th className="py-3 px-4 text-right">Total Value</th>
                  <th className="py-3 px-4">Supplier</th>
                  <th className="py-3 px-4 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#F1EBE0]">
                {filteredItems.map((item) => {
                  const isLow = item.quantity <= item.minThreshold;
                  return (
                    <tr
                      key={item.id}
                      className={`hover:bg-[#FAF6EE] transition-colors ${
                        isLow ? 'bg-amber-50/30' : ''
                      }`}
                    >
                      <td className="py-3 px-4">
                        <p className="font-semibold text-stone-900">{item.name}</p>
                        <span className="text-[10px] uppercase font-mono-data px-1.5 py-0.2 rounded bg-stone-100 text-stone-600 border border-stone-200">
                          {item.category}
                        </span>
                      </td>

                      <td className="py-3 px-4 text-stone-700">
                        {item.color || 'Standard'}
                      </td>

                      <td className="py-3 px-4 whitespace-nowrap">
                        <div className="flex items-center gap-1.5">
                          <span
                            className={`font-mono-data font-bold text-xs ${
                              isLow ? 'text-amber-800' : 'text-stone-900'
                            }`}
                          >
                            {item.quantity} {item.unit}
                          </span>
                          {isLow && (
                            <span className="px-1.5 py-0.5 rounded text-[9px] font-bold uppercase tracking-wider bg-amber-100 text-amber-800 border border-amber-200">
                              Low
                            </span>
                          )}
                        </div>
                      </td>

                      <td className="py-3 px-4 font-mono-data text-stone-500 whitespace-nowrap">
                        {item.minThreshold} {item.unit}
                      </td>

                      <td className="py-3 px-4 text-right font-mono-data text-stone-700 whitespace-nowrap">
                        {formatINR(item.costPerUnit)}
                      </td>

                      <td className="py-3 px-4 text-right font-mono-data font-bold text-stone-900 whitespace-nowrap">
                        {formatINR(item.quantity * item.costPerUnit)}
                      </td>

                      <td className="py-3 px-4 text-stone-500 max-w-[140px] truncate">
                        {item.supplier || '—'}
                      </td>

                      <td className="py-3 px-4 text-right whitespace-nowrap">
                        <div className="flex items-center justify-end gap-1">
                          <button
                            onClick={() => onOpenStockAdjustModal(item)}
                            className="px-2 py-1 text-[11px] font-medium text-[#1B2A4A] bg-[#EFE9DD] hover:bg-[#E4DBCB] border border-[#D8CEBE] rounded transition-colors"
                            title="Quick Adjust Stock (+ / -)"
                          >
                            Adjust
                          </button>
                          <button
                            onClick={() => onOpenInventoryModal(item)}
                            className="p-1.5 text-stone-600 hover:text-stone-900 hover:bg-stone-100 rounded transition-colors"
                            title="Edit Item"
                          >
                            <Edit2 className="w-3.5 h-3.5" />
                          </button>
                          <button
                            onClick={() => onDeleteInventoryItem(item)}
                            className="p-1.5 text-stone-400 hover:text-red-600 hover:bg-red-50 rounded transition-colors"
                            title="Delete Item"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
};
