import React, { useState } from 'react';
import { Order, PaymentRecord } from '../types';
import {
  Receipt,
  CreditCard,
  Search,
  IndianRupee,
  CheckCircle,
  Eye,
  Printer,
  Download,
  Calendar,
  ArrowUpRight
} from 'lucide-react';
import { formatINR, formatDate, formatDateTime } from '../utils/formatters';

interface BillingPageProps {
  orders: Order[];
  payments: PaymentRecord[];
  onViewInvoice: (order: Order) => void;
  onRecordPayment: (order: Order) => void;
}

export const BillingPage: React.FC<BillingPageProps> = ({
  orders,
  payments,
  onViewInvoice,
  onRecordPayment
}) => {
  const [activeTab, setActiveTab] = useState<'invoices' | 'payments'>('invoices');
  const [searchQuery, setSearchQuery] = useState('');
  const [paymentFilter, setPaymentFilter] = useState<'all' | 'due' | 'paid'>('all');

  const totalBilled = orders.reduce((sum, o) => sum + (o.charges?.totalAmount || 0), 0);
  const totalCollected = orders.reduce((sum, o) => sum + (o.charges?.advancePaid || 0), 0);
  const totalOutstanding = orders.reduce((sum, o) => sum + (o.charges?.balanceAmount || 0), 0);

  const filteredOrders = orders.filter((o) => {
    const matchesSearch =
      o.id.toLowerCase().includes(searchQuery.toLowerCase()) ||
      o.customerName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      o.customerPhone.includes(searchQuery);
    const matchesFilter =
      paymentFilter === 'all' ||
      (paymentFilter === 'due' && o.charges.balanceAmount > 0) ||
      (paymentFilter === 'paid' && o.charges.balanceAmount === 0);
    return matchesSearch && matchesFilter;
  });

  const filteredPayments = payments.filter((p) => {
    return (
      p.receiptNo.toLowerCase().includes(searchQuery.toLowerCase()) ||
      p.orderId.toLowerCase().includes(searchQuery.toLowerCase()) ||
      p.customerName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      p.method.toLowerCase().includes(searchQuery.toLowerCase())
    );
  });

  return (
    <div className="space-y-6">
      {/* Financial Summary Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="p-5 rounded-xl bg-white border border-[#E8DEC8] shadow-xs">
          <span className="text-[11px] font-semibold text-stone-500 uppercase tracking-wider">
            Total Billed Revenue
          </span>
          <p className="text-2xl font-extrabold text-[#1B2A4A] mt-2 font-mono-data">
            {formatINR(totalBilled)}
          </p>
          <p className="text-xs text-stone-400 mt-1">Across all {orders.length} orders registered</p>
        </div>

        <div className="p-5 rounded-xl bg-white border border-[#E8DEC8] shadow-xs">
          <span className="text-[11px] font-semibold text-stone-500 uppercase tracking-wider">
            Total Collected Advance & Cash
          </span>
          <p className="text-2xl font-extrabold text-emerald-700 mt-2 font-mono-data">
            {formatINR(totalCollected)}
          </p>
          <p className="text-xs text-stone-400 mt-1">{payments.length} successful payment transactions</p>
        </div>

        <div className="p-5 rounded-xl bg-white border border-[#FED7AA] bg-[#FFFBF5] shadow-xs">
          <span className="text-[11px] font-semibold text-[#C2410C] uppercase tracking-wider">
            Total Pending Customer Balances
          </span>
          <p className="text-2xl font-extrabold text-[#C85A32] mt-2 font-mono-data">
            {formatINR(totalOutstanding)}
          </p>
          <p className="text-xs text-stone-500 mt-1">Collect upon garment trial or delivery</p>
        </div>
      </div>

      {/* Tabs and Search Controls */}
      <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3 bg-white p-4 rounded-xl border border-[#E8DEC8] shadow-xs">
        {/* Toggle View */}
        <div className="flex items-center gap-1 p-1 bg-[#FAF6EE] rounded-lg border border-[#E0D5C1]">
          <button
            onClick={() => setActiveTab('invoices')}
            className={`px-4 py-1.5 text-xs font-semibold rounded-md transition-colors ${
              activeTab === 'invoices' ? 'bg-white text-[#1B2A4A] shadow-xs' : 'text-stone-600 hover:text-stone-900'
            }`}
          >
            Invoices & Balances ({orders.length})
          </button>
          <button
            onClick={() => setActiveTab('payments')}
            className={`px-4 py-1.5 text-xs font-semibold rounded-md transition-colors ${
              activeTab === 'payments' ? 'bg-white text-[#1B2A4A] shadow-xs' : 'text-stone-600 hover:text-stone-900'
            }`}
          >
            Payment Receipts Ledger ({payments.length})
          </button>
        </div>

        <div className="flex items-center gap-2">
          {activeTab === 'invoices' && (
            <select
              value={paymentFilter}
              onChange={(e) => setPaymentFilter(e.target.value as any)}
              className="px-3 py-2 text-xs bg-[#FAF6EE] border border-[#D5C9B3] rounded-lg text-[#1B2A4A] font-semibold"
            >
              <option value="all">All Invoices</option>
              <option value="due">Pending Balance Due</option>
              <option value="paid">Fully Settled</option>
            </select>
          )}

          <div className="relative">
            <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-stone-400" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search by order ID, customer name or receipt..."
              className="pl-9 pr-3 py-2 text-xs bg-[#FAF8F5] border border-[#D5C9B3] rounded-lg focus:outline-none focus:ring-2 focus:ring-[#C85A32]/30 focus:border-[#C85A32] w-64"
            />
          </div>
        </div>
      </div>

      {/* Content based on Active Tab */}
      {activeTab === 'invoices' ? (
        <div className="bg-white rounded-xl border border-[#E8DEC8] shadow-xs overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-xs text-left">
              <thead>
                <tr className="border-b border-[#E8DEC8] text-stone-400 font-semibold text-[11px] uppercase tracking-wider bg-[#FAF8F5]">
                  <th className="py-3 px-4">Order / Invoice No</th>
                  <th className="py-3 px-4">Customer Details</th>
                  <th className="py-3 px-4">Garment Item</th>
                  <th className="py-3 px-4 text-right">Total Bill</th>
                  <th className="py-3 px-4 text-right">Advance Paid</th>
                  <th className="py-3 px-4 text-right">Balance Due</th>
                  <th className="py-3 px-4 text-right">Invoice Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#F1EBE0]">
                {filteredOrders.map((order) => {
                  const isSettled = order.charges.balanceAmount === 0;
                  return (
                    <tr key={order.id} className="hover:bg-[#FAF6EE] transition-colors">
                      <td className="py-3 px-4 whitespace-nowrap">
                        <span className="font-mono-data font-bold text-stone-900 block">{order.id}</span>
                        <span className="text-[10px] text-stone-400 font-mono-data">{formatDate(order.orderDate)}</span>
                      </td>

                      <td className="py-3 px-4">
                        <p className="font-semibold text-stone-900">{order.customerName}</p>
                        <p className="text-[10px] text-stone-500 font-mono-data">{order.customerPhone}</p>
                      </td>

                      <td className="py-3 px-4 max-w-[200px]">
                        <p className="font-medium text-stone-800 truncate">{order.garmentDescription}</p>
                        <p className="text-[10px] text-stone-400 capitalize">{order.garmentType}</p>
                      </td>

                      <td className="py-3 px-4 text-right font-mono-data font-bold text-stone-900 whitespace-nowrap">
                        {formatINR(order.charges.totalAmount)}
                      </td>

                      <td className="py-3 px-4 text-right font-mono-data font-semibold text-emerald-700 whitespace-nowrap">
                        {formatINR(order.charges.advancePaid)}
                      </td>

                      <td className="py-3 px-4 text-right font-mono-data font-bold whitespace-nowrap">
                        {isSettled ? (
                          <span className="inline-flex items-center gap-1 text-[10px] uppercase font-bold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200">
                            <CheckCircle className="w-3 h-3 text-emerald-600" />
                            Settled
                          </span>
                        ) : (
                          <span className="text-[#C85A32]">{formatINR(order.charges.balanceAmount)}</span>
                        )}
                      </td>

                      <td className="py-3 px-4 text-right whitespace-nowrap">
                        <div className="flex items-center justify-end gap-1.5">
                          {!isSettled && (
                            <button
                              onClick={() => onRecordPayment(order)}
                              className="px-2.5 py-1 text-[11px] font-semibold text-white bg-emerald-700 hover:bg-emerald-800 rounded shadow-2xs transition-colors flex items-center gap-1"
                            >
                              <CreditCard className="w-3 h-3" />
                              <span>Collect</span>
                            </button>
                          )}
                          <button
                            onClick={() => onViewInvoice(order)}
                            className="px-2.5 py-1 text-[11px] font-semibold text-[#1B2A4A] bg-[#FAF6EE] hover:bg-[#EAE3D2] border border-[#D5C9B3] rounded transition-colors flex items-center gap-1"
                          >
                            <Printer className="w-3 h-3 text-[#C85A32]" />
                            <span>Invoice</span>
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      ) : (
        /* Payments Ledger Table */
        <div className="bg-white rounded-xl border border-[#E8DEC8] shadow-xs overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-xs text-left">
              <thead>
                <tr className="border-b border-[#E8DEC8] text-stone-400 font-semibold text-[11px] uppercase tracking-wider bg-[#FAF8F5]">
                  <th className="py-3 px-4">Receipt No</th>
                  <th className="py-3 px-4">Order ID</th>
                  <th className="py-3 px-4">Customer Name</th>
                  <th className="py-3 px-4">Date Recorded</th>
                  <th className="py-3 px-4">Payment Method</th>
                  <th className="py-3 px-4">Reference / Note</th>
                  <th className="py-3 px-4 text-right">Amount Received</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#F1EBE0]">
                {filteredPayments.map((payment) => (
                  <tr key={payment.id} className="hover:bg-[#FAF6EE] transition-colors">
                    <td className="py-3 px-4 font-mono-data font-bold text-stone-900 whitespace-nowrap">
                      {payment.receiptNo}
                    </td>
                    <td className="py-3 px-4 font-mono-data text-stone-700 whitespace-nowrap">
                      {payment.orderId}
                    </td>
                    <td className="py-3 px-4 font-semibold text-stone-900 whitespace-nowrap">
                      {payment.customerName}
                    </td>
                    <td className="py-3 px-4 font-mono-data text-stone-600 whitespace-nowrap">
                      {formatDate(payment.date)}
                    </td>
                    <td className="py-3 px-4 whitespace-nowrap">
                      <span className="px-2 py-0.5 rounded text-[10px] font-bold uppercase tracking-wider bg-stone-100 text-stone-700 border border-stone-200">
                        {payment.method.replace('_', ' ')}
                      </span>
                    </td>
                    <td className="py-3 px-4 text-stone-500 max-w-[200px] truncate">
                      {payment.notes || '—'}
                    </td>
                    <td className="py-3 px-4 text-right font-mono-data font-bold text-emerald-700 whitespace-nowrap">
                      {formatINR(payment.amount)}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
};
