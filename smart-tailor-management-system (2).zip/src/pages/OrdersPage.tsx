import React, { useState } from 'react';
import { Order, OrderStatus, OrderPriority } from '../types';
import {
  Search,
  Plus,
  Filter,
  Eye,
  Edit2,
  Trash2,
  Receipt,
  CreditCard,
  AlertTriangle,
  Clock,
  CheckCircle,
  Scissors
} from 'lucide-react';
import {
  formatINR,
  formatDate,
  isOverdue,
  isToday,
  getStatusLabel,
  getStatusColorClasses,
  getPriorityBadge
} from '../utils/formatters';

interface OrdersPageProps {
  orders: Order[];
  onOpenOrderModal: (order?: Order) => void;
  onViewInvoice: (order: Order) => void;
  onRecordPayment: (order: Order) => void;
  onUpdateStatus: (orderId: string, status: OrderStatus) => void;
  onDeleteOrder: (order: Order) => void;
}

export const OrdersPage: React.FC<OrdersPageProps> = ({
  orders,
  onOpenOrderModal,
  onViewInvoice,
  onRecordPayment,
  onUpdateStatus,
  onDeleteOrder
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<'all' | OrderStatus>('all');
  const [priorityFilter, setPriorityFilter] = useState<'all' | OrderPriority>('all');

  const filteredOrders = orders.filter((o) => {
    const matchesSearch =
      o.id.toLowerCase().includes(searchQuery.toLowerCase()) ||
      o.customerName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      o.customerPhone.includes(searchQuery) ||
      o.garmentDescription.toLowerCase().includes(searchQuery.toLowerCase()) ||
      o.fabricDetails.fabricType.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesStatus = statusFilter === 'all' || o.status === statusFilter;
    const matchesPriority = priorityFilter === 'all' || o.priority === priorityFilter;
    return matchesSearch && matchesStatus && matchesPriority;
  });

  return (
    <div className="space-y-5">
      {/* Search and Multi-Filter Toolbar */}
      <div className="flex flex-col lg:flex-row items-stretch lg:items-center justify-between gap-3 bg-white p-4 rounded-xl border border-[#E8DEC8] shadow-xs">
        <div className="flex-1 relative">
          <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-stone-400" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search by Order ID (ORD-...), customer name, mobile, garment, or fabric..."
            className="w-full pl-9 pr-3 py-2 text-xs bg-[#FAF8F5] border border-[#D5C9B3] rounded-lg focus:outline-none focus:ring-2 focus:ring-[#C85A32]/30 focus:border-[#C85A32]"
          />
        </div>

        <div className="flex flex-wrap items-center gap-2">
          {/* Status filter dropdown */}
          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value as any)}
            className="px-3 py-2 text-xs bg-[#FAF6EE] border border-[#D5C9B3] rounded-lg text-[#1B2A4A] font-semibold"
          >
            <option value="all">All Statuses ({orders.length})</option>
            <option value="received">Received ({orders.filter((o) => o.status === 'received').length})</option>
            <option value="cutting">Cutting ({orders.filter((o) => o.status === 'cutting').length})</option>
            <option value="stitching">Stitching ({orders.filter((o) => o.status === 'stitching').length})</option>
            <option value="trial">Trial / Alteration ({orders.filter((o) => o.status === 'trial').length})</option>
            <option value="ready">Ready for Delivery ({orders.filter((o) => o.status === 'ready').length})</option>
            <option value="delivered">Delivered ({orders.filter((o) => o.status === 'delivered').length})</option>
          </select>

          {/* Priority filter */}
          <select
            value={priorityFilter}
            onChange={(e) => setPriorityFilter(e.target.value as any)}
            className="px-3 py-2 text-xs bg-[#FAF6EE] border border-[#D5C9B3] rounded-lg text-[#1B2A4A] font-semibold"
          >
            <option value="all">All Priorities</option>
            <option value="standard">Standard</option>
            <option value="urgent">Urgent</option>
            <option value="express">Express</option>
          </select>

          <button
            onClick={() => onOpenOrderModal()}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-white bg-[#C85A32] hover:bg-[#B34D29] rounded-lg shadow-sm transition-colors whitespace-nowrap"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>New Stitching Order</span>
          </button>
        </div>
      </div>

      {/* Orders Table */}
      {filteredOrders.length === 0 ? (
        <div className="p-8 text-center bg-white rounded-xl border border-[#E8DEC8] space-y-3">
          <p className="text-sm font-semibold text-stone-700">No stitching orders match the current filter</p>
          <p className="text-xs text-stone-500">Reset your filters or create a new stitching work order.</p>
          <button
            onClick={() => onOpenOrderModal()}
            className="px-4 py-2 text-xs font-semibold text-white bg-[#C85A32] hover:bg-[#B34D29] rounded-lg inline-flex items-center gap-1.5"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Create New Order</span>
          </button>
        </div>
      ) : (
        <div className="bg-white rounded-xl border border-[#E8DEC8] shadow-xs overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-xs text-left">
              <thead>
                <tr className="border-b border-[#E8DEC8] text-stone-400 font-semibold text-[11px] uppercase tracking-wider bg-[#FAF8F5]">
                  <th className="py-3 px-4">Order & Priority</th>
                  <th className="py-3 px-4">Customer Details</th>
                  <th className="py-3 px-4">Garment & Fabric</th>
                  <th className="py-3 px-4">Schedule & Delivery</th>
                  <th className="py-3 px-4">Production Stage</th>
                  <th className="py-3 px-4 text-right">Charges & Balance</th>
                  <th className="py-3 px-4 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#F1EBE0]">
                {filteredOrders.map((order) => {
                  const statusStyle = getStatusColorClasses(order.status);
                  const priorityBadge = getPriorityBadge(order.priority);
                  const overdue = isOverdue(order.deliveryDate, order.status);
                  const dueToday = isToday(order.deliveryDate);

                  return (
                    <tr key={order.id} className="hover:bg-[#FAF6EE] transition-colors">
                      {/* Order ID & Priority */}
                      <td className="py-3 px-4 whitespace-nowrap">
                        <span className="font-mono-data font-bold text-stone-900 block text-xs">
                          {order.id}
                        </span>
                        <span
                          className={`inline-block mt-1 px-1.5 py-0.5 rounded text-[10px] font-semibold border ${priorityBadge.classes}`}
                        >
                          {priorityBadge.label}
                        </span>
                      </td>

                      {/* Customer Info */}
                      <td className="py-3 px-4">
                        <p className="font-semibold text-stone-900">{order.customerName}</p>
                        <p className="text-[10px] text-stone-500 font-mono-data">{order.customerPhone}</p>
                      </td>

                      {/* Garment Details */}
                      <td className="py-3 px-4 max-w-[220px]">
                        <p className="font-medium text-stone-800 truncate" title={order.garmentDescription}>
                          {order.garmentDescription}
                        </p>
                        <p className="text-[10px] text-stone-500 capitalize">
                          {order.garmentType} · {order.quantity} pc{order.quantity > 1 ? 's' : ''} ·{' '}
                          {order.fabricDetails.fabricType}
                        </p>
                      </td>

                      {/* Dates */}
                      <td className="py-3 px-4 whitespace-nowrap">
                        <div className="flex items-center gap-1.5">
                          <span
                            className={`font-mono-data text-xs ${
                              overdue
                                ? 'text-red-700 font-bold'
                                : dueToday
                                ? 'text-amber-800 font-bold'
                                : 'text-stone-700'
                            }`}
                          >
                            {formatDate(order.deliveryDate)}
                          </span>
                        </div>
                        {overdue ? (
                          <span className="text-[10px] font-bold text-red-600 block">
                            ⚠ Overdue
                          </span>
                        ) : dueToday ? (
                          <span className="text-[10px] font-bold text-amber-700 block">
                            ★ Deliver Today
                          </span>
                        ) : (
                          <span className="text-[10px] text-stone-400 block">
                            Booked: {formatDate(order.orderDate)}
                          </span>
                        )}
                      </td>

                      {/* Status Dropdown */}
                      <td className="py-3 px-4 whitespace-nowrap">
                        <select
                          value={order.status}
                          onChange={(e) => onUpdateStatus(order.id, e.target.value as OrderStatus)}
                          className={`px-2.5 py-1 text-xs font-semibold rounded-md border focus:outline-none transition-colors cursor-pointer ${statusStyle.bg} ${statusStyle.text} ${statusStyle.border}`}
                        >
                          <option value="received">Order Received</option>
                          <option value="cutting">Cutting</option>
                          <option value="stitching">Stitching</option>
                          <option value="trial">Trial / Alteration</option>
                          <option value="ready">Ready for Delivery</option>
                          <option value="delivered">Delivered</option>
                        </select>
                      </td>

                      {/* Charges & Balance */}
                      <td className="py-3 px-4 text-right whitespace-nowrap">
                        <p className="font-mono-data font-bold text-stone-900">
                          {formatINR(order.charges.totalAmount)}
                        </p>
                        {order.charges.balanceAmount > 0 ? (
                          <p className="text-[11px] font-semibold text-[#C85A32] font-mono-data">
                            Due: {formatINR(order.charges.balanceAmount)}
                          </p>
                        ) : (
                          <span className="text-[10px] font-bold text-emerald-700 uppercase tracking-wide">
                            Paid Full
                          </span>
                        )}
                      </td>

                      {/* Action buttons */}
                      <td className="py-3 px-4 text-right whitespace-nowrap">
                        <div className="flex items-center justify-end gap-1">
                          <button
                            onClick={() => onViewInvoice(order)}
                            className="p-1.5 text-stone-600 hover:text-[#1B2A4A] hover:bg-stone-100 rounded-md transition-colors"
                            title="Print Customer Invoice & Cash Memo"
                          >
                            <Receipt className="w-3.5 h-3.5" />
                          </button>

                          {order.charges.balanceAmount > 0 && (
                            <button
                              onClick={() => onRecordPayment(order)}
                              className="p-1.5 text-emerald-700 hover:text-emerald-900 hover:bg-emerald-50 rounded-md transition-colors"
                              title="Record Payment / Collect Balance"
                            >
                              <CreditCard className="w-3.5 h-3.5" />
                            </button>
                          )}

                          <button
                            onClick={() => onOpenOrderModal(order)}
                            className="p-1.5 text-stone-600 hover:text-stone-900 hover:bg-stone-100 rounded-md transition-colors"
                            title="Edit Order"
                          >
                            <Edit2 className="w-3.5 h-3.5" />
                          </button>

                          <button
                            onClick={() => onDeleteOrder(order)}
                            className="p-1.5 text-stone-400 hover:text-red-600 hover:bg-red-50 rounded-md transition-colors"
                            title="Delete Order"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
};
