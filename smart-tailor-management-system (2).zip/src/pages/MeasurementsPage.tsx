import React, { useState } from 'react';
import { MeasurementRecord, GarmentType, Customer } from '../types';
import { Search, Plus, Ruler, ShoppingBag, Edit2, Trash2, Printer, Check, Copy } from 'lucide-react';
import { formatDate, getGarmentName } from '../utils/formatters';

interface MeasurementsPageProps {
  measurements: MeasurementRecord[];
  customers: Customer[];
  onOpenMeasurementModal: (measurement?: MeasurementRecord) => void;
  onDeleteMeasurement: (measurement: MeasurementRecord) => void;
  onCreateOrderFromMeasurement: (measurement: MeasurementRecord) => void;
}

export const MeasurementsPage: React.FC<MeasurementsPageProps> = ({
  measurements,
  customers,
  onOpenMeasurementModal,
  onDeleteMeasurement,
  onCreateOrderFromMeasurement
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [typeFilter, setTypeFilter] = useState<'all' | GarmentType>('all');
  const [copiedId, setCopiedId] = useState<string | null>(null);

  const filteredMeasurements = measurements.filter((m) => {
    const matchesSearch =
      m.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      m.customerName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      m.id.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesType = typeFilter === 'all' || m.garmentType === typeFilter;
    return matchesSearch && matchesType;
  });

  const handleCopySpecs = (m: MeasurementRecord) => {
    const text = `Measurement Specs: ${m.title} (${m.customerName})\nGarment: ${m.garmentType} (${m.unit})\n` +
      Object.entries(m.values).map(([k, v]) => `${k}: ${v}`).join('\n') +
      (m.notes ? `\nNotes: ${m.notes}` : '');
    navigator.clipboard.writeText(text);
    setCopiedId(m.id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  return (
    <div className="space-y-5">
      {/* Top Filter and Search Bar */}
      <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3 bg-white p-4 rounded-xl border border-[#E8DEC8] shadow-xs">
        <div className="flex-1 relative">
          <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-stone-400" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search measurements by client name, blouse title, or ID..."
            className="w-full pl-9 pr-3 py-2 text-xs bg-[#FAF8F5] border border-[#D5C9B3] rounded-lg focus:outline-none focus:ring-2 focus:ring-[#C85A32]/30 focus:border-[#C85A32]"
          />
        </div>

        <div className="flex items-center gap-2 overflow-x-auto pb-1 sm:pb-0">
          <select
            value={typeFilter}
            onChange={(e) => setTypeFilter(e.target.value as any)}
            className="px-3 py-2 text-xs bg-[#FAF6EE] border border-[#D5C9B3] rounded-lg text-[#1B2A4A] font-semibold"
          >
            <option value="all">All Garment Silhouettes</option>
            <option value="blouse">Saree Blouses</option>
            <option value="shirt">Shirts</option>
            <option value="pants">Pants / Trousers</option>
            <option value="churidar">Churidar / Salwar</option>
            <option value="kurta">Kurtas</option>
            <option value="suit">Suits / Blazers</option>
            <option value="custom">Custom Pattern</option>
          </select>

          <button
            onClick={() => onOpenMeasurementModal()}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-white bg-[#C85A32] hover:bg-[#B34D29] rounded-lg shadow-sm transition-colors whitespace-nowrap shrink-0"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Record Measurement</span>
          </button>
        </div>
      </div>

      {/* Measurement Cards List */}
      {filteredMeasurements.length === 0 ? (
        <div className="p-8 text-center bg-white rounded-xl border border-[#E8DEC8] space-y-3">
          <Ruler className="w-8 h-8 text-stone-300 mx-auto" />
          <p className="text-sm font-semibold text-stone-700">No measurement records found</p>
          <p className="text-xs text-stone-500">Add a new measurement template card to get started.</p>
          <button
            onClick={() => onOpenMeasurementModal()}
            className="px-4 py-2 text-xs font-semibold text-white bg-[#C85A32] hover:bg-[#B34D29] rounded-lg inline-flex items-center gap-1.5"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Record First Measurement</span>
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {filteredMeasurements.map((m) => (
            <div
              key={m.id}
              className="bg-white rounded-xl border border-[#E8DEC8] hover:border-[#C85A32]/40 shadow-xs p-5 flex flex-col justify-between transition-all"
            >
              <div>
                {/* Header */}
                <div className="flex items-start justify-between gap-3 mb-2.5">
                  <div>
                    <h3 className="text-sm font-bold text-[#1B2A4A] tracking-tight">{m.title}</h3>
                    <p className="text-xs text-stone-600 font-semibold mt-0.5">
                      Client: <span className="text-stone-900">{m.customerName}</span>
                    </p>
                  </div>
                  <div className="flex items-center gap-1.5 shrink-0">
                    <span className="px-2 py-0.5 rounded text-[10px] font-mono-data font-bold uppercase tracking-wider bg-[#FAF6EE] text-[#1B2A4A] border border-[#E2D9CC]">
                      {m.unit}
                    </span>
                    <span className="px-2 py-0.5 rounded text-[10px] font-semibold uppercase tracking-wider bg-stone-100 text-stone-600">
                      {getGarmentName(m.garmentType)}
                    </span>
                  </div>
                </div>

                {/* Values Table Grid */}
                <div className="bg-[#FAF8F5] p-3 rounded-lg border border-[#EDE5D6] mb-3">
                  <div className="grid grid-cols-3 sm:grid-cols-4 gap-2 text-xs font-mono-data">
                    {Object.entries(m.values).map(([key, val]) => (
                      <div key={key} className="bg-white p-1.5 rounded border border-[#E5DCCB]">
                        <span className="block text-[10px] text-stone-400 capitalize truncate" title={key}>
                          {key}
                        </span>
                        <span className="font-bold text-stone-800 text-xs truncate block">{String(val)}</span>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Notes */}
                {m.notes && (
                  <p className="text-[11px] text-stone-600 italic bg-amber-50/50 p-2 rounded border border-amber-100 mb-3">
                    <strong className="text-amber-900 not-italic">Fitting Note: </strong>
                    {m.notes}
                  </p>
                )}

                <p className="text-[10px] text-stone-400 font-mono-data">
                  Recorded: {formatDate(m.recordedDate)} · Card Ref: {m.id}
                </p>
              </div>

              {/* Bottom Actions */}
              <div className="pt-3 mt-3 border-t border-[#F1ECE1] flex items-center justify-between gap-2">
                <div className="flex items-center gap-1">
                  <button
                    onClick={() => handleCopySpecs(m)}
                    className="p-1.5 text-stone-600 hover:text-[#1B2A4A] hover:bg-stone-100 rounded-md transition-colors"
                    title="Copy measurements to clipboard"
                  >
                    {copiedId === m.id ? (
                      <Check className="w-3.5 h-3.5 text-emerald-600" />
                    ) : (
                      <Copy className="w-3.5 h-3.5" />
                    )}
                  </button>
                  <button
                    onClick={() => onOpenMeasurementModal(m)}
                    className="p-1.5 text-stone-600 hover:text-stone-900 hover:bg-stone-100 rounded-md transition-colors"
                    title="Edit Measurement"
                  >
                    <Edit2 className="w-3.5 h-3.5" />
                  </button>
                  <button
                    onClick={() => onDeleteMeasurement(m)}
                    className="p-1.5 text-stone-400 hover:text-red-600 hover:bg-red-50 rounded-md transition-colors"
                    title="Delete Measurement"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>

                <button
                  onClick={() => onCreateOrderFromMeasurement(m)}
                  className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-white bg-[#C85A32] hover:bg-[#B34D29] rounded-lg shadow-2xs transition-colors"
                >
                  <ShoppingBag className="w-3.5 h-3.5" />
                  <span>Create Stitching Order</span>
                </button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};
