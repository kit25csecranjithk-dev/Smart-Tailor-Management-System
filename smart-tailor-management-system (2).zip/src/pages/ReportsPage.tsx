import React, { useState } from 'react';
import { Order, ExpenseRecord, PaymentRecord, ExpenseCategory } from '../types';
import {
  TrendingUp,
  TrendingDown,
  DollarSign,
  Download,
  Plus,
  Trash2,
  PieChart,
  BarChart,
  Calendar,
  IndianRupee,
  Receipt
} from 'lucide-react';
import { formatINR, formatDate } from '../utils/formatters';

interface ReportsPageProps {
  orders: Order[];
  expenses: ExpenseRecord[];
  payments: PaymentRecord[];
  onOpenExpenseModal: (expense?: ExpenseRecord) => void;
  onDeleteExpense: (expense: ExpenseRecord) => void;
}

export const ReportsPage: React.FC<ReportsPageProps> = ({
  orders,
  expenses,
  payments,
  onOpenExpenseModal,
  onDeleteExpense
}) => {
  const [expenseCategoryFilter, setExpenseCategoryFilter] = useState<'all' | ExpenseCategory>('all');

  // Revenue math
  const totalBilled = orders.reduce((sum, o) => sum + (o.charges?.totalAmount || 0), 0);
  const totalCollectedIncome = payments.reduce((sum, p) => sum + p.amount, 0);
  const totalOutstanding = orders.reduce((sum, o) => sum + (o.charges?.balanceAmount || 0), 0);

  // Stitching vs Addons vs Fabric sales
  const stitchingIncome = orders.reduce((sum, o) => sum + (o.charges?.stitchingCharge || 0) * (o.quantity || 1), 0);
  const addOnIncome = orders.reduce((sum, o) => sum + (o.charges?.addOnCharges || 0), 0);
  const fabricIncome = orders.reduce((sum, o) => sum + (o.charges?.fabricCharge || 0), 0);

  // Expenses math
  const totalExpenses = expenses.reduce((sum, e) => sum + e.amount, 0);
  const netProfit = totalCollectedIncome - totalExpenses;

  // Garment popularity breakdown
  const garmentCounts: Record<string, number> = {};
  orders.forEach((o) => {
    garmentCounts[o.garmentType] = (garmentCounts[o.garmentType] || 0) + o.quantity;
  });

  const filteredExpenses = expenses.filter(
    (e) => expenseCategoryFilter === 'all' || e.category === expenseCategoryFilter
  );

  // CSV Export handler
  const handleExportCSV = () => {
    const rows = [
      ['SMART TAILOR MANAGEMENT SYSTEM - FINANCIAL & ORDERS REPORT'],
      ['Generated On', new Date().toLocaleString('en-IN')],
      [],
      ['--- FINANCIAL SUMMARY ---'],
      ['Metric', 'Amount (INR)'],
      ['Total Stitching Labor Billed', stitchingIncome],
      ['Total Custom Addons & Work', addOnIncome],
      ['Total Fabric Sales', fabricIncome],
      ['Total Billed Revenue', totalBilled],
      ['Total Cash & Online Collected', totalCollectedIncome],
      ['Total Pending Customer Balance', totalOutstanding],
      ['Total Shop Operating Expenses', totalExpenses],
      ['Net Realized Profit', netProfit],
      [],
      ['--- ORDERS BREAKDOWN ---'],
      ['Order ID', 'Customer', 'Garment', 'Status', 'Total Bill', 'Advance Paid', 'Balance Due'],
      ...orders.map((o) => [
        o.id,
        o.customerName,
        o.garmentDescription,
        o.status,
        o.charges.totalAmount,
        o.charges.advancePaid,
        o.charges.balanceAmount
      ]),
      [],
      ['--- EXPENSES BREAKDOWN ---'],
      ['Expense ID', 'Category', 'Description', 'Date', 'Paid To', 'Amount'],
      ...expenses.map((e) => [e.id, e.category, e.description, e.date, e.paidTo || '', e.amount])
    ];

    const csvContent = 'data:text/csv;charset=utf-8,' + rows.map((e) => e.join(',')).join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `smart_tailor_report_${new Date().toISOString().split('T')[0]}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="space-y-6">
      {/* Top Header & Export Action */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 bg-white p-4 rounded-xl border border-[#E8DEC8] shadow-xs">
        <div>
          <h3 className="text-sm font-bold text-[#1B2A4A] tracking-tight">
            Financial Health, Revenue & Expense Ledger
          </h3>
          <p className="text-xs text-stone-500 mt-0.5">
            Profit and loss calculations based on collected cash flows and workshop overheads
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={handleExportCSV}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-[#1B2A4A] bg-[#FAF6EE] hover:bg-[#EAE3D2] border border-[#D5C9B3] rounded-lg transition-colors"
          >
            <Download className="w-3.5 h-3.5 text-[#C85A32]" />
            <span>Export CSV Report</span>
          </button>

          <button
            onClick={() => onOpenExpenseModal()}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-white bg-[#C85A32] hover:bg-[#B34D29] rounded-lg shadow-sm transition-colors"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Record Shop Expense</span>
          </button>
        </div>
      </div>

      {/* Financial P&L Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="p-4 rounded-xl bg-white border border-[#E8DEC8] shadow-xs">
          <span className="text-[11px] font-semibold text-stone-500 uppercase tracking-wider">
            Total Cash Collected
          </span>
          <p className="text-2xl font-extrabold text-emerald-700 mt-2 font-mono-data">
            {formatINR(totalCollectedIncome)}
          </p>
          <p className="text-xs text-stone-500 mt-1">Realized income from advances & collections</p>
        </div>

        <div className="p-4 rounded-xl bg-white border border-[#E8DEC8] shadow-xs">
          <span className="text-[11px] font-semibold text-stone-500 uppercase tracking-wider">
            Total Shop Expenses
          </span>
          <p className="text-2xl font-extrabold text-red-700 mt-2 font-mono-data">
            {formatINR(totalExpenses)}
          </p>
          <p className="text-xs text-stone-500 mt-1">Rent, wages, electricity & supplies</p>
        </div>

        <div className="p-4 rounded-xl bg-white border border-[#E8DEC8] shadow-xs">
          <span className="text-[11px] font-semibold text-stone-500 uppercase tracking-wider">
            Net Realized Profit
          </span>
          <p
            className={`text-2xl font-extrabold mt-2 font-mono-data ${
              netProfit >= 0 ? 'text-[#1B2A4A]' : 'text-red-700'
            }`}
          >
            {formatINR(netProfit)}
          </p>
          <p className="text-xs text-stone-500 mt-1">Cash collected minus total paid expenses</p>
        </div>

        <div className="p-4 rounded-xl bg-white border border-[#FED7AA] bg-[#FFFBF5] shadow-xs">
          <span className="text-[11px] font-semibold text-[#C2410C] uppercase tracking-wider">
            Outstanding Due
          </span>
          <p className="text-2xl font-extrabold text-[#C85A32] mt-2 font-mono-data">
            {formatINR(totalOutstanding)}
          </p>
          <p className="text-xs text-stone-500 mt-1">Pending collection at delivery</p>
        </div>
      </div>

      {/* Two Column Section: Income Streams & Garment Breakdown */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Income Streams Breakdown */}
        <div className="p-5 rounded-xl bg-white border border-[#E8DEC8] shadow-xs space-y-4">
          <h4 className="text-xs font-bold text-[#1B2A4A] uppercase tracking-wider">
            Income Streams Distribution
          </h4>

          <div className="space-y-3">
            <div>
              <div className="flex justify-between text-xs mb-1">
                <span className="font-medium text-stone-700">Stitching Labor Charges</span>
                <span className="font-mono-data font-bold text-stone-900">{formatINR(stitchingIncome)}</span>
              </div>
              <div className="w-full h-2 rounded-full bg-stone-100 overflow-hidden">
                <div
                  className="h-full bg-[#1B2A4A] rounded-full"
                  style={{ width: `${totalBilled > 0 ? (stitchingIncome / totalBilled) * 100 : 0}%` }}
                />
              </div>
            </div>

            <div>
              <div className="flex justify-between text-xs mb-1">
                <span className="font-medium text-stone-700">Aari, Embroidery & Add-ons</span>
                <span className="font-mono-data font-bold text-stone-900">{formatINR(addOnIncome)}</span>
              </div>
              <div className="w-full h-2 rounded-full bg-stone-100 overflow-hidden">
                <div
                  className="h-full bg-[#C85A32] rounded-full"
                  style={{ width: `${totalBilled > 0 ? (addOnIncome / totalBilled) * 100 : 0}%` }}
                />
              </div>
            </div>

            <div>
              <div className="flex justify-between text-xs mb-1">
                <span className="font-medium text-stone-700">Shop Fabric & Lining Sales</span>
                <span className="font-mono-data font-bold text-stone-900">{formatINR(fabricIncome)}</span>
              </div>
              <div className="w-full h-2 rounded-full bg-stone-100 overflow-hidden">
                <div
                  className="h-full bg-emerald-600 rounded-full"
                  style={{ width: `${totalBilled > 0 ? (fabricIncome / totalBilled) * 100 : 0}%` }}
                />
              </div>
            </div>
          </div>
        </div>

        {/* Garment Popularity Breakdown */}
        <div className="p-5 rounded-xl bg-white border border-[#E8DEC8] shadow-xs space-y-4">
          <h4 className="text-xs font-bold text-[#1B2A4A] uppercase tracking-wider">
            Garments Tailored by Silhouette
          </h4>

          <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5">
            {Object.entries(garmentCounts).map(([garment, count]) => (
              <div key={garment} className="p-3 rounded-lg bg-[#FAF8F5] border border-[#E8DEC8] text-center">
                <p className="text-[11px] font-semibold text-stone-500 uppercase tracking-wide capitalize">
                  {garment}
                </p>
                <p className="text-xl font-bold text-[#1B2A4A] font-mono-data mt-1">{count} pcs</p>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Expenses Ledger Table */}
      <div className="bg-white rounded-xl border border-[#E8DEC8] shadow-xs overflow-hidden">
        <div className="p-4 border-b border-[#E8DEC8] flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 bg-[#FAF8F5]">
          <div>
            <h4 className="text-sm font-bold text-[#1B2A4A] tracking-tight">
              Operational Expense Log
            </h4>
            <p className="text-xs text-stone-500 mt-0.5">
              Audited expenses for workshop operations and labor
            </p>
          </div>

          <div className="flex items-center gap-2">
            <select
              value={expenseCategoryFilter}
              onChange={(e) => setExpenseCategoryFilter(e.target.value as any)}
              className="px-3 py-1.5 text-xs bg-white border border-[#D5C9B3] rounded-lg text-[#1B2A4A] font-semibold"
            >
              <option value="all">All Expense Categories</option>
              <option value="tailor_wages">Tailor Wages</option>
              <option value="rent">Shop Rent</option>
              <option value="electricity">Electricity</option>
              <option value="threads_materials">Threads & Materials</option>
              <option value="machinery_maintenance">Machine Maintenance</option>
              <option value="tea_snacks">Tea & Refreshments</option>
              <option value="other">Other</option>
            </select>
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-xs text-left">
            <thead>
              <tr className="border-b border-[#E8DEC8] text-stone-400 font-semibold text-[11px] uppercase tracking-wider bg-[#FAF8F5]">
                <th className="py-3 px-4">Expense ID</th>
                <th className="py-3 px-4">Date</th>
                <th className="py-3 px-4">Category</th>
                <th className="py-3 px-4">Description</th>
                <th className="py-3 px-4">Paid To</th>
                <th className="py-3 px-4 text-right">Amount (₹)</th>
                <th className="py-3 px-4 text-right">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#F1EBE0]">
              {filteredExpenses.map((expense) => (
                <tr key={expense.id} className="hover:bg-[#FAF6EE] transition-colors">
                  <td className="py-3 px-4 font-mono-data font-bold text-stone-900 whitespace-nowrap">
                    {expense.id}
                  </td>
                  <td className="py-3 px-4 font-mono-data text-stone-600 whitespace-nowrap">
                    {formatDate(expense.date)}
                  </td>
                  <td className="py-3 px-4 whitespace-nowrap">
                    <span className="px-2 py-0.5 rounded text-[10px] font-bold uppercase tracking-wider bg-stone-100 text-stone-700 border border-stone-200">
                      {expense.category.replace('_', ' ')}
                    </span>
                  </td>
                  <td className="py-3 px-4 font-medium text-stone-800">
                    {expense.description}
                  </td>
                  <td className="py-3 px-4 text-stone-500">
                    {expense.paidTo || '—'}
                  </td>
                  <td className="py-3 px-4 text-right font-mono-data font-bold text-red-700 whitespace-nowrap">
                    {formatINR(expense.amount)}
                  </td>
                  <td className="py-3 px-4 text-right whitespace-nowrap">
                    <button
                      onClick={() => onDeleteExpense(expense)}
                      className="p-1.5 text-stone-400 hover:text-red-600 hover:bg-red-50 rounded transition-colors"
                      title="Delete Expense"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
