import React, { useState } from 'react';
import { Scissors, Eye, EyeOff, Lock, User as UserIcon, CheckCircle2, ShieldCheck } from 'lucide-react';
import { User } from '../types';

interface LoginPageProps {
  onLogin: (user: User) => void;
}

export const LoginPage: React.FC<LoginPageProps> = ({ onLogin }) => {
  const [username, setUsername] = useState('admin');
  const [password, setPassword] = useState('master123');
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  const handleLoginSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    if (!username.trim()) {
      setError('Please enter your username');
      return;
    }
    if (!password.trim()) {
      setError('Please enter your password');
      return;
    }

    setIsLoading(true);

    setTimeout(() => {
      // Demo credentials validation
      if ((username === 'admin' && password === 'master123') || (username === 'staff' && password === 'staff123')) {
        const loggedUser: User = {
          id: username === 'admin' ? 'usr-1' : 'usr-2',
          username: username,
          name: username === 'admin' ? 'Master Senthil Kumar' : 'Ramesh (Senior Tailor)',
          role: username === 'admin' ? 'Master Tailor' : 'Billing Staff',
          isLoggedIn: true
        };
        onLogin(loggedUser);
      } else {
        setError('Invalid username or password. Use demo login or: admin / master123');
        setIsLoading(false);
      }
    }, 400);
  };

  const handleQuickDemoLogin = (role: 'master' | 'staff') => {
    setError('');
    setIsLoading(true);
    setTimeout(() => {
      const loggedUser: User = role === 'master'
        ? {
            id: 'usr-1',
            username: 'admin',
            name: 'Master Senthil Kumar',
            role: 'Master Tailor',
            isLoggedIn: true
          }
        : {
            id: 'usr-2',
            username: 'staff',
            name: 'Ramesh (Senior Tailor)',
            role: 'Senior Cutter',
            isLoggedIn: true
          };
      onLogin(loggedUser);
    }, 300);
  };

  return (
    <div className="min-h-screen bg-[#F5F2EB] flex flex-col justify-center items-center p-4">
      <div className="w-full max-w-md">
        {/* Brand Card */}
        <div className="text-center mb-6">
          <div className="inline-flex items-center justify-center w-14 h-14 rounded-2xl bg-[#1B2A4A] text-[#FAF8F5] shadow-lg mb-3">
            <Scissors className="w-7 h-7 text-[#C85A32]" />
          </div>
          <h1 className="text-2xl font-bold text-[#1B2A4A] tracking-tight">
            Smart Tailor
          </h1>
          <p className="text-xs text-stone-600 mt-1">
            Bespoke Tailor Shop Management & Order Studio
          </p>
        </div>

        {/* Login Form Box */}
        <div className="bg-[#FDFBF7] rounded-xl border border-[#E0D5C1] shadow-xl p-7">
          <div className="mb-5 pb-3 border-b border-[#EAE3D2]">
            <h2 className="text-base font-bold text-[#1B2A4A]">Studio Login</h2>
            <p className="text-xs text-stone-500 mt-0.5">Enter your credentials to access shop records</p>
          </div>

          {error && (
            <div className="mb-4 p-3 rounded-lg bg-red-50 border border-red-200 text-xs text-red-700">
              {error}
            </div>
          )}

          <form onSubmit={handleLoginSubmit} className="space-y-4">
            <div>
              <label className="block text-xs font-semibold text-stone-700 mb-1">
                Username
              </label>
              <div className="relative">
                <span className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-stone-400">
                  <UserIcon className="w-4 h-4" />
                </span>
                <input
                  type="text"
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  placeholder="e.g. admin"
                  className="w-full pl-9 pr-3 py-2 text-xs text-stone-900 bg-white border border-[#D5C9B3] rounded-lg focus:outline-none focus:ring-2 focus:ring-[#C85A32]/30 focus:border-[#C85A32] transition-colors"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-stone-700 mb-1">
                Password
              </label>
              <div className="relative">
                <span className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-stone-400">
                  <Lock className="w-4 h-4" />
                </span>
                <input
                  type={showPassword ? 'text' : 'password'}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••••"
                  className="w-full pl-9 pr-9 py-2 text-xs text-stone-900 bg-white border border-[#D5C9B3] rounded-lg focus:outline-none focus:ring-2 focus:ring-[#C85A32]/30 focus:border-[#C85A32] transition-colors"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute inset-y-0 right-0 pr-3 flex items-center text-stone-400 hover:text-stone-700"
                  aria-label={showPassword ? 'Hide password' : 'Show password'}
                >
                  {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>

            <button
              type="submit"
              disabled={isLoading}
              className="w-full py-2.5 px-4 bg-[#C85A32] hover:bg-[#B34D29] text-white text-xs font-semibold rounded-lg shadow-sm transition-colors flex items-center justify-center gap-2 mt-2 disabled:opacity-50"
            >
              {isLoading ? (
                <span>Authenticating...</span>
              ) : (
                <>
                  <ShieldCheck className="w-4 h-4" />
                  <span>Sign In to Tailor System</span>
                </>
              )}
            </button>
          </form>

          {/* Quick Demo Login Option */}
          <div className="mt-6 pt-5 border-t border-[#EAE3D2]">
            <p className="text-[11px] font-semibold text-stone-500 uppercase tracking-wider text-center mb-2.5">
              Instant Demo Access for Review
            </p>
            <div className="grid grid-cols-2 gap-2">
              <button
                type="button"
                onClick={() => handleQuickDemoLogin('master')}
                className="px-3 py-2 text-xs font-medium text-[#1B2A4A] bg-[#EFE9DD] hover:bg-[#E4DBCB] border border-[#D8CEBE] rounded-lg transition-colors flex items-center justify-center gap-1.5"
              >
                <CheckCircle2 className="w-3.5 h-3.5 text-[#C85A32]" />
                <span>Master Tailor</span>
              </button>
              <button
                type="button"
                onClick={() => handleQuickDemoLogin('staff')}
                className="px-3 py-2 text-xs font-medium text-[#1B2A4A] bg-[#EFE9DD] hover:bg-[#E4DBCB] border border-[#D8CEBE] rounded-lg transition-colors flex items-center justify-center gap-1.5"
              >
                <CheckCircle2 className="w-3.5 h-3.5 text-[#2C5282]" />
                <span>Senior Staff</span>
              </button>
            </div>
          </div>
        </div>

        {/* College Project Badge Footer */}
        <div className="text-center mt-5 text-[11px] text-stone-500 space-y-0.5">
          <p className="font-medium text-stone-700">Concept of Practices (COP) Real-World Project</p>
          <p>Department of Computer Science & Engineering</p>
          <p className="text-stone-400">LocalStorage Demo Mode · Works 100% Offline in VS Code</p>
        </div>
      </div>
    </div>
  );
};
