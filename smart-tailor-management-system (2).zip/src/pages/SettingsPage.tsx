import React, { useState, useEffect, useRef } from 'react';
import { ShopSettings } from '../types';
import {
  Save,
  RotateCcw,
  Download,
  Upload,
  CheckCircle,
  Building2,
  Database,
  GraduationCap,
  ShieldCheck,
  AlertTriangle
} from 'lucide-react';

interface SettingsPageProps {
  settings: ShopSettings;
  onSaveSettings: (settings: ShopSettings) => void;
  onResetDemoData: () => void;
  onExportBackup: () => void;
  onImportBackup: (jsonString: string) => { success: boolean; message: string };
}

export const SettingsPage: React.FC<SettingsPageProps> = ({
  settings,
  onSaveSettings,
  onResetDemoData,
  onExportBackup,
  onImportBackup
}) => {
  const [formData, setFormData] = useState<ShopSettings>(settings);
  const [saveSuccess, setSaveSuccess] = useState(false);
  const [importStatus, setImportStatus] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    setFormData(settings);
  }, [settings]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSaveSettings(formData);
    setSaveSuccess(true);
    setTimeout(() => setSaveSuccess(false), 3000);
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      const content = event.target?.result as string;
      if (content) {
        const result = onImportBackup(content);
        setImportStatus(result.message);
        setTimeout(() => setImportStatus(null), 4000);
      }
    };
    reader.readAsText(file);
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  return (
    <div className="space-y-6 max-w-5xl">
      {/* Top Banner */}
      <div className="bg-white p-5 rounded-xl border border-[#E8DEC8] shadow-xs flex items-center justify-between">
        <div>
          <h3 className="text-base font-bold text-[#1B2A4A] tracking-tight">
            Tailor Studio Configuration & System Preferences
          </h3>
          <p className="text-xs text-stone-500 mt-0.5">
            Configure boutique details, invoice terms, default measurement units and data backups
          </p>
        </div>

        {saveSuccess && (
          <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-emerald-50 text-emerald-800 border border-emerald-200 text-xs font-semibold animate-in fade-in">
            <CheckCircle className="w-4 h-4 text-emerald-600" />
            <span>Settings Saved!</span>
          </div>
        )}
      </div>

      {/* Main Settings Form */}
      <form onSubmit={handleSubmit} className="space-y-6">
        <div className="bg-white p-6 rounded-xl border border-[#E8DEC8] shadow-xs space-y-4">
          <h4 className="text-xs font-bold text-[#1B2A4A] uppercase tracking-wider flex items-center gap-2">
            <Building2 className="w-4 h-4 text-[#C85A32]" />
            <span>Boutique & Tailor Shop Identity</span>
          </h4>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-stone-700 mb-1">
                Shop / Studio Name <span className="text-red-500">*</span>
              </label>
              <input
                type="text"
                value={formData.shopName}
                onChange={(e) => setFormData({ ...formData, shopName: e.target.value })}
                className="w-full px-3 py-2 text-xs bg-[#FAF8F5] border border-[#D5C9B3] rounded-lg focus:outline-none focus:ring-2 focus:ring-[#C85A32]/30 focus:border-[#C85A32]"
                required
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-stone-700 mb-1">
                Tagline / Slogan
              </label>
              <input
                type="text"
                value={formData.tagline}
                onChange={(e) => setFormData({ ...formData, tagline: e.target.value })}
                className="w-full px-3 py-2 text-xs bg-[#FAF8F5] border border-[#D5C9B3] rounded-lg focus:outline-none focus:ring-2 focus:ring-[#C85A32]/30 focus:border-[#C85A32]"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-stone-700 mb-1">
                Master Tailor / Proprietor Name <span className="text-red-500">*</span>
              </label>
              <input
                type="text"
                value={formData.ownerName}
                onChange={(e) => setFormData({ ...formData, ownerName: e.target.value })}
                className="w-full px-3 py-2 text-xs bg-[#FAF8F5] border border-[#D5C9B3] rounded-lg focus:outline-none focus:ring-2 focus:ring-[#C85A32]/30 focus:border-[#C85A32]"
                required
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-stone-700 mb-1">
                Primary Phone Number <span className="text-red-500">*</span>
              </label>
              <input
                type="text"
                value={formData.phone}
                onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                className="w-full px-3 py-2 text-xs bg-[#FAF8F5] border border-[#D5C9B3] rounded-lg font-mono-data"
                required
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-stone-700 mb-1">
                Alternate Phone / Landline
              </label>
              <input
                type="text"
                value={formData.alternatePhone || ''}
                onChange={(e) => setFormData({ ...formData, alternatePhone: e.target.value })}
                className="w-full px-3 py-2 text-xs bg-[#FAF8F5] border border-[#D5C9B3] rounded-lg font-mono-data"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-stone-700 mb-1">
                Studio Email Address
              </label>
              <input
                type="email"
                value={formData.email}
                onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                className="w-full px-3 py-2 text-xs bg-[#FAF8F5] border border-[#D5C9B3] rounded-lg"
              />
            </div>

            <div className="sm:col-span-2">
              <label className="block text-xs font-semibold text-stone-700 mb-1">
                Shop Physical Address (Appears on Printed Invoices)
              </label>
              <input
                type="text"
                value={formData.address}
                onChange={(e) => setFormData({ ...formData, address: e.target.value })}
                className="w-full px-3 py-2 text-xs bg-[#FAF8F5] border border-[#D5C9B3] rounded-lg"
              />
            </div>
          </div>
        </div>

        {/* Invoicing and Regional Preferences */}
        <div className="bg-white p-6 rounded-xl border border-[#E8DEC8] shadow-xs space-y-4">
          <h4 className="text-xs font-bold text-[#1B2A4A] uppercase tracking-wider">
            Invoicing, GST & Units
          </h4>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div>
              <label className="block text-xs font-semibold text-stone-700 mb-1">
                GSTIN / Tax ID
              </label>
              <input
                type="text"
                value={formData.gstin || ''}
                onChange={(e) => setFormData({ ...formData, gstin: e.target.value })}
                placeholder="29AABCS1429B1Z8"
                className="w-full px-3 py-2 text-xs bg-[#FAF8F5] border border-[#D5C9B3] rounded-lg font-mono-data"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-stone-700 mb-1">
                Invoice Number Prefix
              </label>
              <input
                type="text"
                value={formData.invoicePrefix}
                onChange={(e) => setFormData({ ...formData, invoicePrefix: e.target.value })}
                placeholder="STB"
                className="w-full px-3 py-2 text-xs bg-[#FAF8F5] border border-[#D5C9B3] rounded-lg font-mono-data uppercase"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-stone-700 mb-1">
                Default Measurement Unit
              </label>
              <select
                value={formData.defaultUnit}
                onChange={(e) => setFormData({ ...formData, defaultUnit: e.target.value as any })}
                className="w-full px-3 py-2 text-xs bg-[#FAF8F5] border border-[#D5C9B3] rounded-lg font-semibold"
              >
                <option value="inches">Inches (in)</option>
                <option value="cm">Centimeters (cm)</option>
              </select>
            </div>

            <div className="sm:col-span-3">
              <label className="block text-xs font-semibold text-stone-700 mb-1">
                Invoice Footer Terms & Conditions
              </label>
              <textarea
                rows={3}
                value={formData.invoiceFooterTerms}
                onChange={(e) => setFormData({ ...formData, invoiceFooterTerms: e.target.value })}
                className="w-full px-3 py-2 text-xs bg-[#FAF8F5] border border-[#D5C9B3] rounded-lg font-sans"
              />
            </div>
          </div>

          <div className="flex justify-end pt-2">
            <button
              type="submit"
              className="inline-flex items-center gap-2 px-5 py-2.5 text-xs font-semibold text-white bg-[#C85A32] hover:bg-[#B34D29] rounded-lg shadow-sm transition-colors"
            >
              <Save className="w-4 h-4" />
              <span>Save Changes</span>
            </button>
          </div>
        </div>
      </form>

      {/* Database Backup & Restore */}
      <div className="bg-white p-6 rounded-xl border border-[#E8DEC8] shadow-xs space-y-4">
        <h4 className="text-xs font-bold text-[#1B2A4A] uppercase tracking-wider flex items-center gap-2">
          <Database className="w-4 h-4 text-[#C85A32]" />
          <span>Local Data Persistence & Database Portability</span>
        </h4>
        <p className="text-xs text-stone-600">
          All client measurements, job orders, inventory, and expense ledgers are persisted in browser LocalStorage.
          You can download a complete JSON backup to restore on another machine or VS Code localhost anytime.
        </p>

        {importStatus && (
          <div className="p-3 rounded-lg bg-blue-50 text-blue-900 border border-blue-200 text-xs font-medium">
            {importStatus}
          </div>
        )}

        <div className="flex flex-wrap items-center gap-3 pt-2">
          <button
            type="button"
            onClick={onExportBackup}
            className="inline-flex items-center gap-2 px-4 py-2 text-xs font-semibold text-[#1B2A4A] bg-[#FAF6EE] hover:bg-[#EAE3D2] border border-[#D5C9B3] rounded-lg transition-colors"
          >
            <Download className="w-4 h-4 text-[#C85A32]" />
            <span>Download JSON Database Backup</span>
          </button>

          <input
            type="file"
            ref={fileInputRef}
            onChange={handleFileChange}
            accept=".json"
            className="hidden"
          />
          <button
            type="button"
            onClick={() => fileInputRef.current?.click()}
            className="inline-flex items-center gap-2 px-4 py-2 text-xs font-semibold text-stone-700 bg-white hover:bg-stone-50 border border-stone-300 rounded-lg transition-colors"
          >
            <Upload className="w-4 h-4" />
            <span>Restore from Backup File</span>
          </button>

          <button
            type="button"
            onClick={onResetDemoData}
            className="inline-flex items-center gap-2 px-4 py-2 text-xs font-semibold text-red-700 bg-red-50 hover:bg-red-100 border border-red-200 rounded-lg transition-colors ml-auto"
          >
            <RotateCcw className="w-4 h-4" />
            <span>Reset to Initial Demo Data</span>
          </button>
        </div>
      </div>

      {/* College COP Project Details Card */}
      <div className="bg-[#FAF8F5] p-6 rounded-xl border border-[#E0D5C1] shadow-xs space-y-3">
        <div className="flex items-center gap-2 text-[#1B2A4A]">
          <GraduationCap className="w-5 h-5 text-[#C85A32]" />
          <h4 className="text-sm font-bold tracking-tight">
            College Project Information (Concept of Practices - COP)
          </h4>
        </div>
        <div className="text-xs text-stone-600 space-y-1.5 leading-relaxed">
          <p>
            <strong>Project Title:</strong> Smart Tailor - Tailor Shop Management System
          </p>
          <p>
            <strong>Problem Solved:</strong> Replaces traditional manual tailor paper notebooks with a structured digital record system for multi-garment body measurements (blouses, shirts, trousers, salwar), tracking order lifecycle stages (cutting, stitching, trials), auto-calculating advance billing balances, and notifying low material stock.
          </p>
          <p>
            <strong>Technology Architecture:</strong> React 19 + TypeScript + Tailwind CSS v4 + Vite + LocalStorage client-side persistence (Zero external backend/API key dependencies, 100% offline runnable in VS Code).
          </p>
          <p>
            <strong>Local VS Code Execution:</strong> Run <code className="px-1.5 py-0.5 bg-white border border-stone-300 rounded font-mono-data text-stone-800">npm install</code> followed by <code className="px-1.5 py-0.5 bg-white border border-stone-300 rounded font-mono-data text-stone-800">npm run dev</code> on port 3000.
          </p>
        </div>
      </div>
    </div>
  );
};
