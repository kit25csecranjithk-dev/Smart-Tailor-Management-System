export type GarmentType = 'blouse' | 'shirt' | 'pants' | 'churidar' | 'kurta' | 'suit' | 'custom';

export type MeasurementUnit = 'inches' | 'cm';

export type OrderStatus = 'received' | 'cutting' | 'stitching' | 'trial' | 'ready' | 'delivered';

export type OrderPriority = 'standard' | 'urgent' | 'express';

export type PaymentMethod = 'cash' | 'upi' | 'card' | 'bank_transfer';

export type InventoryCategory = 'fabric' | 'thread' | 'button' | 'zipper' | 'lining' | 'accessory';

export type ExpenseCategory = 'rent' | 'electricity' | 'threads_materials' | 'machinery_maintenance' | 'tailor_wages' | 'tea_snacks' | 'other';

export interface Customer {
  id: string;
  name: string;
  phone: string;
  email?: string;
  address?: string;
  gender: 'female' | 'male' | 'other';
  notes?: string;
  createdAt: string;
  updatedAt: string;
}

export interface MeasurementRecord {
  id: string;
  customerId: string;
  customerName: string;
  garmentType: GarmentType;
  title: string; // e.g., "Wedding Silk Blouse", "Formal Slim Shirt"
  unit: MeasurementUnit;
  values: Record<string, number | string>;
  recordedDate: string;
  notes?: string;
}

export interface FabricDetails {
  fabricType: string;
  color: string;
  pattern?: string;
  customerProvided: boolean;
  lengthMeters?: number;
  notes?: string;
}

export interface OrderCharges {
  stitchingCharge: number;
  addOnCharges: number;
  fabricCharge: number;
  discount: number;
  totalAmount: number;
  advancePaid: number;
  balanceAmount: number;
}

export interface StatusHistoryItem {
  status: OrderStatus;
  timestamp: string;
  note?: string;
}

export interface Order {
  id: string; // e.g. "ORD-2026-001"
  customerId: string;
  customerName: string;
  customerPhone: string;
  garmentType: GarmentType;
  garmentDescription: string;
  quantity: number;
  fabricDetails: FabricDetails;
  measurementId?: string;
  measurementsSnapshot: Record<string, number | string>;
  measurementUnit: MeasurementUnit;
  status: OrderStatus;
  priority: OrderPriority;
  orderDate: string;
  trialDate?: string;
  deliveryDate: string;
  deliveredDate?: string;
  charges: OrderCharges;
  assignedTailor?: string;
  notes?: string;
  statusHistory: StatusHistoryItem[];
  createdAt: string;
  updatedAt: string;
}

export interface PaymentRecord {
  id: string;
  receiptNo: string;
  orderId: string;
  customerId: string;
  customerName: string;
  amount: number;
  date: string;
  method: PaymentMethod;
  notes?: string;
}

export interface InventoryItem {
  id: string;
  name: string;
  category: InventoryCategory;
  color?: string;
  quantity: number;
  unit: 'meters' | 'spools' | 'packets' | 'pieces' | 'rolls';
  minThreshold: number;
  costPerUnit: number;
  supplier?: string;
  lastUpdated: string;
}

export interface ExpenseRecord {
  id: string;
  category: ExpenseCategory;
  description: string;
  amount: number;
  date: string;
  paidTo?: string;
}

export interface ShopSettings {
  shopName: string;
  tagline: string;
  ownerName: string;
  phone: string;
  alternatePhone?: string;
  email: string;
  address: string;
  gstin?: string;
  currencySymbol: string;
  defaultUnit: MeasurementUnit;
  invoicePrefix: string;
  invoiceFooterTerms: string;
}

export interface User {
  id: string;
  username: string;
  name: string;
  role: 'Master Tailor' | 'Senior Cutter' | 'Billing Staff';
  isLoggedIn: boolean;
}
