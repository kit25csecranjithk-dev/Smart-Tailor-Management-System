import React, { useState, useEffect } from 'react';
import {
  Customer,
  MeasurementRecord,
  Order,
  InventoryItem,
  ExpenseRecord,
  PaymentRecord,
  ShopSettings,
  User,
  OrderStatus
} from './types';
import { storageService } from './services/storage';
import { Sidebar, ActiveTab } from './components/layout/Sidebar';
import { Header } from './components/layout/Header';
import { NotificationToast, ToastMessage, ToastType } from './components/common/NotificationToast';
import { ConfirmModal } from './components/common/ConfirmModal';

// Pages
import { LoginPage } from './pages/LoginPage';
import { DashboardPage } from './pages/DashboardPage';
import { CustomersPage } from './pages/CustomersPage';
import { MeasurementsPage } from './pages/MeasurementsPage';
import { OrdersPage } from './pages/OrdersPage';
import { TrackingPage } from './pages/TrackingPage';
import { BillingPage } from './pages/BillingPage';
import { InventoryPage } from './pages/InventoryPage';
import { DeliverySchedulePage } from './pages/DeliverySchedulePage';
import { ReportsPage } from './pages/ReportsPage';
import { SettingsPage } from './pages/SettingsPage';

// Modals
import { CustomerModal } from './components/customers/CustomerModal';
import { CustomerDetailDrawer } from './components/customers/CustomerDetailDrawer';
import { MeasurementModal } from './components/measurements/MeasurementModal';
import { OrderModal } from './components/orders/OrderModal';
import { InvoiceModal } from './components/billing/InvoiceModal';
import { PaymentModal } from './components/billing/PaymentModal';
import { InventoryModal } from './components/inventory/InventoryModal';
import { StockAdjustModal } from './components/inventory/StockAdjustModal';
import { ExpenseModal } from './components/expenses/ExpenseModal';
import { isOverdue } from './utils/formatters';

export default function App() {
  // Authentication State
  const [user, setUser] = useState<User | null>(() => {
    const saved = storageService.getUser();
    return saved?.isLoggedIn ? saved : null;
  });

  // Navigation State
  const [activeTab, setActiveTab] = useState<ActiveTab>('dashboard');
  const [mobileSidebarOpen, setMobileSidebarOpen] = useState(false);

  // Data Collections
  const [customers, setCustomers] = useState<Customer[]>(() => storageService.getCustomers());
  const [measurements, setMeasurements] = useState<MeasurementRecord[]>(() => storageService.getMeasurements());
  const [orders, setOrders] = useState<Order[]>(() => storageService.getOrders());
  const [inventory, setInventory] = useState<InventoryItem[]>(() => storageService.getInventory());
  const [expenses, setExpenses] = useState<ExpenseRecord[]>(() => storageService.getExpenses());
  const [payments, setPayments] = useState<PaymentRecord[]>(() => storageService.getPayments());
  const [settings, setSettings] = useState<ShopSettings>(() => storageService.getSettings());

  // Toast System
  const [toasts, setToasts] = useState<ToastMessage[]>([]);
  const showToast = (type: ToastType, message: string) => {
    const id = `${Date.now()}-${Math.random().toString(36).substr(2, 4)}`;
    setToasts((prev) => [...prev, { id, type, message }]);
  };
  const dismissToast = (id: string) => {
    setToasts((prev) => prev.filter((t) => t.id !== id));
  };

  // Modals States
  const [customerModal, setCustomerModal] = useState<{ isOpen: boolean; customer: Customer | null }>({
    isOpen: false,
    customer: null
  });
  const [customerDetail, setCustomerDetail] = useState<{ isOpen: boolean; customer: Customer | null }>({
    isOpen: false,
    customer: null
  });
  const [measurementModal, setMeasurementModal] = useState<{
    isOpen: boolean;
    measurement: MeasurementRecord | null;
    preselectedCustomerId?: string;
  }>({
    isOpen: false,
    measurement: null
  });
  const [orderModal, setOrderModal] = useState<{
    isOpen: boolean;
    order: Order | null;
    preselectedCustomerId?: string;
  }>({
    isOpen: false,
    order: null
  });
  const [invoiceModal, setInvoiceModal] = useState<{ isOpen: boolean; order: Order | null }>({
    isOpen: false,
    order: null
  });
  const [paymentModal, setPaymentModal] = useState<{ isOpen: boolean; order: Order | null }>({
    isOpen: false,
    order: null
  });
  const [inventoryModal, setInventoryModal] = useState<{ isOpen: boolean; item: InventoryItem | null }>({
    isOpen: false,
    item: null
  });
  const [stockAdjustModal, setStockAdjustModal] = useState<{ isOpen: boolean; item: InventoryItem | null }>({
    isOpen: false,
    item: null
  });
  const [expenseModal, setExpenseModal] = useState<{ isOpen: boolean; expense: ExpenseRecord | null }>({
    isOpen: false,
    expense: null
  });
  const [confirmDialog, setConfirmDialog] = useState<{
    isOpen: boolean;
    title: string;
    message: string;
    onConfirm: () => void;
    danger?: boolean;
  }>({
    isOpen: false,
    title: '',
    message: '',
    onConfirm: () => {}
  });

  // Reload all states from storageService
  const refreshData = () => {
    setCustomers(storageService.getCustomers());
    setMeasurements(storageService.getMeasurements());
    setOrders(storageService.getOrders());
    setInventory(storageService.getInventory());
    setExpenses(storageService.getExpenses());
    setPayments(storageService.getPayments());
    setSettings(storageService.getSettings());
  };

  // --- Auth Handlers ---
  const handleLogin = (loggedUser: User) => {
    storageService.setUser(loggedUser);
    setUser(loggedUser);
    showToast('success', `Welcome back, ${loggedUser.name}!`);
  };

  const handleLogout = () => {
    const unloggedUser: User = {
      id: 'usr-1',
      username: '',
      name: '',
      role: 'Master Tailor',
      isLoggedIn: false
    };
    storageService.setUser(unloggedUser);
    setUser(null);
    showToast('info', 'Logged out successfully');
  };

  // --- Customer Handlers ---
  const handleSaveCustomer = (customerData: any) => {
    const saved = storageService.saveCustomer(customerData);
    refreshData();
    showToast('success', `Customer profile "${saved.name}" saved!`);
  };

  const handleDeleteCustomer = (customer: Customer) => {
    setConfirmDialog({
      isOpen: true,
      title: 'Delete Customer Record',
      message: `Are you sure you want to delete customer "${customer.name}"? This action cannot be undone.`,
      danger: true,
      onConfirm: () => {
        storageService.deleteCustomer(customer.id);
        refreshData();
        showToast('info', `Customer ${customer.name} deleted`);
      }
    });
  };

  // --- Measurement Handlers ---
  const handleSaveMeasurement = (recordData: any) => {
    const saved = storageService.saveMeasurement(recordData);
    refreshData();
    showToast('success', `Measurement card "${saved.title}" saved!`);
  };

  const handleDeleteMeasurement = (record: MeasurementRecord) => {
    setConfirmDialog({
      isOpen: true,
      title: 'Delete Measurement Specification',
      message: `Delete measurement card "${record.title}" for ${record.customerName}?`,
      danger: true,
      onConfirm: () => {
        storageService.deleteMeasurement(record.id);
        refreshData();
        showToast('info', 'Measurement card removed');
      }
    });
  };

  // --- Order Handlers ---
  const handleSaveOrder = (orderData: any) => {
    const saved = storageService.saveOrder(orderData);
    refreshData();
    showToast('success', `Stitching Order #${saved.id} generated!`);
  };

  const handleUpdateOrderStatus = (orderId: string, status: OrderStatus) => {
    const updated = storageService.updateOrderStatus(orderId, status);
    if (updated) {
      refreshData();
      showToast('info', `Order #${orderId} moved to stage: ${status}`);
    }
  };

  const handleDeleteOrder = (order: Order) => {
    setConfirmDialog({
      isOpen: true,
      title: 'Cancel & Delete Order',
      message: `Delete work order #${order.id} for ${order.customerName}?`,
      danger: true,
      onConfirm: () => {
        storageService.deleteOrder(order.id);
        refreshData();
        showToast('info', `Order #${order.id} deleted`);
      }
    });
  };

  // --- Payment Handlers ---
  const handleRecordPayment = (paymentData: any) => {
    const saved = storageService.recordPayment(paymentData);
    refreshData();
    showToast('success', `Payment receipt #${saved.receiptNo} of ₹${saved.amount} recorded!`);
  };

  // --- Inventory Handlers ---
  const handleSaveInventory = (itemData: any) => {
    const saved = storageService.saveInventoryItem(itemData);
    refreshData();
    showToast('success', `Material item "${saved.name}" saved!`);
  };

  const handleAdjustStock = (itemId: string, delta: number) => {
    const updated = storageService.adjustInventoryStock(itemId, delta);
    if (updated) {
      refreshData();
      showToast('success', `Stock adjusted: ${updated.quantity} ${updated.unit} remaining`);
    }
  };

  const handleDeleteInventory = (item: InventoryItem) => {
    setConfirmDialog({
      isOpen: true,
      title: 'Remove Material Item',
      message: `Delete "${item.name}" from inventory catalog?`,
      danger: true,
      onConfirm: () => {
        storageService.deleteInventoryItem(item.id);
        refreshData();
        showToast('info', 'Item removed from inventory');
      }
    });
  };

  // --- Expense Handlers ---
  const handleSaveExpense = (expenseData: any) => {
    const saved = storageService.saveExpense(expenseData);
    refreshData();
    showToast('success', `Shop expense of ₹${saved.amount} recorded!`);
  };

  const handleDeleteExpense = (expense: ExpenseRecord) => {
    setConfirmDialog({
      isOpen: true,
      title: 'Delete Expense Log',
      message: `Delete expense "${expense.description}" (₹${expense.amount})?`,
      danger: true,
      onConfirm: () => {
        storageService.deleteExpense(expense.id);
        refreshData();
        showToast('info', 'Expense record deleted');
      }
    });
  };

  // --- Settings Handlers ---
  const handleSaveSettings = (newSettings: ShopSettings) => {
    storageService.saveSettings(newSettings);
    setSettings(newSettings);
    showToast('success', 'Shop settings & invoice preferences updated!');
  };

  const handleResetDemoData = () => {
    setConfirmDialog({
      isOpen: true,
      title: 'Reset to Default Sample Data',
      message:
        'This will reset all customers, measurements, orders, inventory and expenses to initial demo records. Ideal for fresh project demonstration and viva testing.',
      danger: true,
      onConfirm: () => {
        storageService.resetToDefaults();
        refreshData();
        showToast('success', 'Demo data reset successfully!');
      }
    });
  };

  const handleExportBackup = () => {
    const json = storageService.exportBackup();
    const blob = new Blob([json], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `smart_tailor_backup_${new Date().toISOString().split('T')[0]}.json`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
    showToast('success', 'Database backup JSON file downloaded!');
  };

  const handleImportBackup = (jsonString: string) => {
    const result = storageService.importBackup(jsonString);
    if (result.success) {
      refreshData();
      showToast('success', result.message);
    } else {
      showToast('error', result.message);
    }
    return result;
  };

  // Counts for alerts
  const overdueCount = orders.filter((o) => isOverdue(o.deliveryDate, o.status)).length;
  const lowStockCount = inventory.filter((i) => i.quantity <= i.minThreshold).length;
  const pendingOrdersCount = orders.filter((o) => o.status !== 'delivered').length;

  // If not logged in, show Login Page
  if (!user) {
    return <LoginPage onLogin={handleLogin} />;
  }

  return (
    <div className="min-h-screen bg-[#FAF8F5] text-[#1B2A4A] flex flex-col font-sans">
      {/* Toast Notifications */}
      <NotificationToast toasts={toasts} onDismiss={dismissToast} />

      {/* Confirmation Dialog */}
      <ConfirmModal
        isOpen={confirmDialog.isOpen}
        onClose={() => setConfirmDialog((prev) => ({ ...prev, isOpen: false }))}
        onConfirm={confirmDialog.onConfirm}
        title={confirmDialog.title}
        message={confirmDialog.message}
        danger={confirmDialog.danger}
      />

      {/* Reusable Modals */}
      <CustomerModal
        isOpen={customerModal.isOpen}
        onClose={() => setCustomerModal({ isOpen: false, customer: null })}
        onSave={handleSaveCustomer}
        customer={customerModal.customer}
      />

      <CustomerDetailDrawer
        isOpen={customerDetail.isOpen}
        onClose={() => setCustomerDetail({ isOpen: false, customer: null })}
        customer={customerDetail.customer}
        orders={orders}
        measurements={measurements}
        onNewOrderForCustomer={(cust) => {
          setCustomerDetail({ isOpen: false, customer: null });
          setOrderModal({ isOpen: true, order: null, preselectedCustomerId: cust.id });
        }}
        onNewMeasurementForCustomer={(cust) => {
          setCustomerDetail({ isOpen: false, customer: null });
          setMeasurementModal({ isOpen: true, measurement: null, preselectedCustomerId: cust.id });
        }}
        onViewOrder={(ord) => {
          setCustomerDetail({ isOpen: false, customer: null });
          setInvoiceModal({ isOpen: true, order: ord });
        }}
      />

      <MeasurementModal
        isOpen={measurementModal.isOpen}
        onClose={() => setMeasurementModal({ isOpen: false, measurement: null })}
        onSave={handleSaveMeasurement}
        customers={customers}
        measurement={measurementModal.measurement}
        preselectedCustomerId={measurementModal.preselectedCustomerId}
        defaultUnit={settings.defaultUnit}
      />

      <OrderModal
        isOpen={orderModal.isOpen}
        onClose={() => setOrderModal({ isOpen: false, order: null })}
        onSave={handleSaveOrder}
        customers={customers}
        measurements={measurements}
        order={orderModal.order}
        preselectedCustomerId={orderModal.preselectedCustomerId}
        onQuickAddCustomer={() => {
          setCustomerModal({ isOpen: true, customer: null });
        }}
      />

      <InvoiceModal
        isOpen={invoiceModal.isOpen}
        onClose={() => setInvoiceModal({ isOpen: false, order: null })}
        order={invoiceModal.order}
        settings={settings}
      />

      <PaymentModal
        isOpen={paymentModal.isOpen}
        onClose={() => setPaymentModal({ isOpen: false, order: null })}
        order={paymentModal.order}
        onRecordPayment={handleRecordPayment}
      />

      <InventoryModal
        isOpen={inventoryModal.isOpen}
        onClose={() => setInventoryModal({ isOpen: false, item: null })}
        onSave={handleSaveInventory}
        item={inventoryModal.item}
      />

      <StockAdjustModal
        isOpen={stockAdjustModal.isOpen}
        onClose={() => setStockAdjustModal({ isOpen: false, item: null })}
        item={stockAdjustModal.item}
        onAdjust={handleAdjustStock}
      />

      <ExpenseModal
        isOpen={expenseModal.isOpen}
        onClose={() => setExpenseModal({ isOpen: false, expense: null })}
        onSave={handleSaveExpense}
        expense={expenseModal.expense}
      />

      {/* Main Layout */}
      <div className="flex flex-1 min-h-screen">
        {/* Sidebar */}
        <Sidebar
          activeTab={activeTab}
          setActiveTab={setActiveTab}
          isOpen={mobileSidebarOpen}
          onClose={() => setMobileSidebarOpen(false)}
          currentUser={user}
          onLogout={handleLogout}
          pendingOrdersCount={pendingOrdersCount}
          lowStockCount={lowStockCount}
          overdueOrdersCount={overdueCount}
        />

        {/* Content Viewport */}
        <div className="flex-1 lg:pl-64 flex flex-col min-w-0">
          <Header
            activeTab={activeTab}
            onOpenMobileMenu={() => setMobileSidebarOpen(true)}
            onNewOrder={() => setOrderModal({ isOpen: true, order: null })}
            onNewCustomer={() => setCustomerModal({ isOpen: true, customer: null })}
            overdueOrdersCount={overdueCount}
            lowStockCount={lowStockCount}
          />

          <main className="flex-1 p-4 sm:p-6 lg:p-8 max-w-7xl w-full mx-auto">
            {activeTab === 'dashboard' && (
              <DashboardPage
                customers={customers}
                orders={orders}
                inventory={inventory}
                setActiveTab={setActiveTab}
                onNewOrder={() => setOrderModal({ isOpen: true, order: null })}
                onNewCustomer={() => setCustomerModal({ isOpen: true, customer: null })}
                onViewOrder={(ord) => setInvoiceModal({ isOpen: true, order: ord })}
                onUpdateOrderStatus={handleUpdateOrderStatus}
              />
            )}

            {activeTab === 'customers' && (
              <CustomersPage
                customers={customers}
                orders={orders}
                measurements={measurements}
                onOpenCustomerModal={(cust) => setCustomerModal({ isOpen: true, customer: cust || null })}
                onOpenCustomerDetail={(cust) => setCustomerDetail({ isOpen: true, customer: cust })}
                onDeleteCustomer={handleDeleteCustomer}
                onNewOrderForCustomer={(cust) =>
                  setOrderModal({ isOpen: true, order: null, preselectedCustomerId: cust.id })
                }
                onNewMeasurementForCustomer={(cust) =>
                  setMeasurementModal({ isOpen: true, measurement: null, preselectedCustomerId: cust.id })
                }
              />
            )}

            {activeTab === 'measurements' && (
              <MeasurementsPage
                measurements={measurements}
                customers={customers}
                onOpenMeasurementModal={(m) => setMeasurementModal({ isOpen: true, measurement: m || null })}
                onDeleteMeasurement={handleDeleteMeasurement}
                onCreateOrderFromMeasurement={(m) => {
                  setOrderModal({
                    isOpen: true,
                    order: null,
                    preselectedCustomerId: m.customerId
                  });
                }}
              />
            )}

            {activeTab === 'orders' && (
              <OrdersPage
                orders={orders}
                onOpenOrderModal={(ord) => setOrderModal({ isOpen: true, order: ord || null })}
                onViewInvoice={(ord) => setInvoiceModal({ isOpen: true, order: ord })}
                onRecordPayment={(ord) => setPaymentModal({ isOpen: true, order: ord })}
                onUpdateStatus={handleUpdateOrderStatus}
                onDeleteOrder={handleDeleteOrder}
              />
            )}

            {activeTab === 'tracking' && (
              <TrackingPage
                orders={orders}
                onUpdateStatus={handleUpdateOrderStatus}
                onViewOrder={(ord) => setInvoiceModal({ isOpen: true, order: ord })}
              />
            )}

            {activeTab === 'billing' && (
              <BillingPage
                orders={orders}
                payments={payments}
                onViewInvoice={(ord) => setInvoiceModal({ isOpen: true, order: ord })}
                onRecordPayment={(ord) => setPaymentModal({ isOpen: true, order: ord })}
              />
            )}

            {activeTab === 'inventory' && (
              <InventoryPage
                inventory={inventory}
                onOpenInventoryModal={(item) => setInventoryModal({ isOpen: true, item: item || null })}
                onOpenStockAdjustModal={(item) => setStockAdjustModal({ isOpen: true, item })}
                onDeleteInventoryItem={handleDeleteInventory}
              />
            )}

            {activeTab === 'deliveries' && (
              <DeliverySchedulePage
                orders={orders}
                onViewOrder={(ord) => setInvoiceModal({ isOpen: true, order: ord })}
                onUpdateStatus={handleUpdateOrderStatus}
              />
            )}

            {activeTab === 'reports' && (
              <ReportsPage
                orders={orders}
                expenses={expenses}
                payments={payments}
                onOpenExpenseModal={(exp) => setExpenseModal({ isOpen: true, expense: exp || null })}
                onDeleteExpense={handleDeleteExpense}
              />
            )}

            {activeTab === 'settings' && (
              <SettingsPage
                settings={settings}
                onSaveSettings={handleSaveSettings}
                onResetDemoData={handleResetDemoData}
                onExportBackup={handleExportBackup}
                onImportBackup={handleImportBackup}
              />
            )}
          </main>
        </div>
      </div>
    </div>
  );
}
